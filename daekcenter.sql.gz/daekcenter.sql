-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2015 at 08:14 PM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `daekcenter`
--

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_assets`
--

CREATE TABLE IF NOT EXISTS `g2q6h_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=71 ;

--
-- Dumping data for table `g2q6h_assets`
--

INSERT INTO `g2q6h_assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES
(1, 0, 0, 135, 0, 'root.1', 'Root Asset', '{"core.login.site":{"6":1,"2":1},"core.login.admin":{"6":1},"core.login.offline":{"6":1},"core.admin":{"8":1},"core.manage":{"7":1},"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(2, 1, 1, 2, 1, 'com_admin', 'com_admin', '{}'),
(3, 1, 3, 6, 1, 'com_banners', 'com_banners', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(4, 1, 7, 8, 1, 'com_cache', 'com_cache', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(5, 1, 9, 10, 1, 'com_checkin', 'com_checkin', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(6, 1, 11, 12, 1, 'com_config', 'com_config', '{}'),
(7, 1, 13, 16, 1, 'com_contact', 'com_contact', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(8, 1, 17, 46, 1, 'com_content', 'com_content', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(9, 1, 47, 48, 1, 'com_cpanel', 'com_cpanel', '{}'),
(10, 1, 49, 50, 1, 'com_installer', 'com_installer', '{"core.admin":[],"core.manage":{"7":0},"core.delete":{"7":0},"core.edit.state":{"7":0}}'),
(11, 1, 51, 52, 1, 'com_languages', 'com_languages', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(12, 1, 53, 54, 1, 'com_login', 'com_login', '{}'),
(13, 1, 55, 56, 1, 'com_mailto', 'com_mailto', '{}'),
(14, 1, 57, 58, 1, 'com_massmail', 'com_massmail', '{}'),
(15, 1, 59, 60, 1, 'com_media', 'com_media', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":{"5":1}}'),
(16, 1, 61, 62, 1, 'com_menus', 'com_menus', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(17, 1, 63, 64, 1, 'com_messages', 'com_messages', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(18, 1, 65, 102, 1, 'com_modules', 'com_modules', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(19, 1, 103, 106, 1, 'com_newsfeeds', 'com_newsfeeds', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(20, 1, 107, 108, 1, 'com_plugins', 'com_plugins', '{"core.admin":{"7":1},"core.manage":[],"core.edit":[],"core.edit.state":[]}'),
(21, 1, 109, 110, 1, 'com_redirect', 'com_redirect', '{"core.admin":{"7":1},"core.manage":[]}'),
(22, 1, 111, 112, 1, 'com_search', 'com_search', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(23, 1, 113, 114, 1, 'com_templates', 'com_templates', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(24, 1, 115, 118, 1, 'com_users', 'com_users', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(26, 1, 119, 120, 1, 'com_wrapper', 'com_wrapper', '{}'),
(27, 8, 18, 39, 2, 'com_content.category.2', 'Information', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(28, 3, 4, 5, 2, 'com_banners.category.3', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(29, 7, 14, 15, 2, 'com_contact.category.4', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(30, 19, 104, 105, 2, 'com_newsfeeds.category.5', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(32, 24, 116, 117, 1, 'com_users.category.7', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(33, 1, 121, 122, 1, 'com_finder', 'com_finder', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(34, 1, 123, 124, 1, 'com_joomlaupdate', 'com_joomlaupdate', '{"core.admin":[],"core.manage":[],"core.delete":[],"core.edit.state":[]}'),
(35, 1, 125, 126, 1, 'com_tags', 'com_tags', '{"core.admin":[],"core.manage":[],"core.manage":[],"core.delete":[],"core.edit.state":[]}'),
(36, 1, 127, 128, 1, 'com_contenthistory', 'com_contenthistory', '{}'),
(37, 1, 129, 130, 1, 'com_ajax', 'com_ajax', '{}'),
(38, 1, 131, 132, 1, 'com_postinstall', 'com_postinstall', '{}'),
(39, 18, 66, 67, 2, 'com_modules.module.1', 'Main Menu', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"module.edit.frontend":[]}'),
(40, 18, 68, 69, 2, 'com_modules.module.2', 'Login', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(41, 18, 70, 71, 2, 'com_modules.module.3', 'Popular Articles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(42, 18, 72, 73, 2, 'com_modules.module.4', 'Recently Added Articles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(43, 18, 74, 75, 2, 'com_modules.module.8', 'Toolbar', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(44, 18, 76, 77, 2, 'com_modules.module.9', 'Quick Icons', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(45, 18, 78, 79, 2, 'com_modules.module.10', 'Logged-in Users', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(46, 18, 80, 81, 2, 'com_modules.module.12', 'Admin Menu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(47, 18, 82, 83, 2, 'com_modules.module.13', 'Admin Submenu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(48, 18, 84, 85, 2, 'com_modules.module.14', 'User Status', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(49, 18, 86, 87, 2, 'com_modules.module.15', 'Title', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(50, 18, 88, 89, 2, 'com_modules.module.16', 'Login Form', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(51, 18, 90, 91, 2, 'com_modules.module.17', 'Breadcrumbs', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"module.edit.frontend":[]}'),
(52, 18, 92, 93, 2, 'com_modules.module.79', 'Multilanguage status', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(53, 18, 94, 95, 2, 'com_modules.module.86', 'Joomla Version', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(54, 1, 133, 134, 1, 'com_geofactory', 'COM_GEOFACTORY', '{"core.admin":[],"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(55, 18, 96, 97, 2, 'com_modules.module.87', 'Geocode Factory 5 map module', ''),
(56, 18, 98, 99, 2, 'com_modules.module.88', 'Geocode Factory - Search module', ''),
(57, 27, 19, 20, 3, 'com_content.article.1', 'Homepage article', '{"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1}}'),
(58, 27, 21, 22, 3, 'com_content.article.2', 'Teknisk info – Dæk', '{"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1}}'),
(59, 18, 100, 101, 2, 'com_modules.module.89', 'Left Menu', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(60, 27, 23, 24, 3, 'com_content.article.3', 'Teknisk info – Fælge', '{"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1}}'),
(61, 27, 25, 26, 3, 'com_content.article.4', 'Teknisk info - Hjul', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(62, 27, 27, 28, 3, 'com_content.article.5', 'EU-mærkning af dæk', '{"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1}}'),
(63, 27, 29, 30, 3, 'com_content.article.6', 'Vedligeholdelsesguide Dæk', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(64, 27, 31, 32, 3, 'com_content.article.7', 'Udskiftning af dæk', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(65, 27, 33, 34, 3, 'com_content.article.8', 'Vinterdæk regler', '{"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1}}'),
(66, 27, 35, 36, 3, 'com_content.article.9', 'Bliv forhandler', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(67, 27, 37, 38, 3, 'com_content.article.10', 'FÅ KREDIT - RENTEFRIT', '{"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1}}'),
(68, 8, 40, 45, 2, 'com_content.category.8', 'Store', '{"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(69, 68, 41, 44, 3, 'com_content.category.9', 'JYLLAND', '{"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(70, 69, 42, 43, 4, 'com_content.article.11', 'Aalestrup', '{"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1}}');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_associations`
--

CREATE TABLE IF NOT EXISTS `g2q6h_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_banners`
--

CREATE TABLE IF NOT EXISTS `g2q6h_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_banner_clients`
--

CREATE TABLE IF NOT EXISTS `g2q6h_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_banner_tracks`
--

CREATE TABLE IF NOT EXISTS `g2q6h_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_categories`
--

CREATE TABLE IF NOT EXISTS `g2q6h_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `g2q6h_categories`
--

INSERT INTO `g2q6h_categories` (`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`, `version`) VALUES
(1, 0, 0, 0, 15, 0, '', 'system', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '{}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(2, 27, 1, 1, 2, 1, 'uncategorised', 'com_content', 'Information', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":"","image_alt":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 401, '2015-05-11 11:53:08', 0, '*', 1),
(3, 28, 1, 3, 4, 1, 'uncategorised', 'com_banners', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(4, 29, 1, 5, 6, 1, 'uncategorised', 'com_contact', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(5, 30, 1, 7, 8, 1, 'uncategorised', 'com_newsfeeds', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(7, 32, 1, 9, 10, 1, 'uncategorised', 'com_users', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(8, 68, 1, 11, 14, 1, 'store', 'com_content', 'Store', 'store', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":"","image_alt":""}', '', '', '{"author":"","robots":""}', 401, '2015-05-12 17:36:23', 0, '2015-05-12 17:36:23', 0, '*', 1),
(9, 69, 8, 12, 13, 2, 'store/jylland', 'com_content', 'JYLLAND', 'jylland', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":"","image_alt":""}', '', '', '{"author":"","robots":""}', 401, '2015-05-12 17:36:49', 0, '2015-05-12 17:36:49', 0, '*', 1);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_contact_details`
--

CREATE TABLE IF NOT EXISTS `g2q6h_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_content`
--

CREATE TABLE IF NOT EXISTS `g2q6h_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `g2q6h_content`
--

INSERT INTO `g2q6h_content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(1, 57, 'Homepage article', 'homepage-article', '<h2>HELE DANMARKS DÆKCENTER - <a href="index.php"><span class="highlite">WWW.DÆKCENTER.NU</span></a> SOMMERDÆK - VINTERDÆK - FÆLGE</h2>\r\n<p>Lorem ipsum dolor sit amet consectetuer adipiscing elit donec odio quisque volutpat mattis eros nullam malesuada erat ut turpis suspendisse urna nibh viverra non semper suscipit posuere a pede donec nec justo eget felis facilisis fermentum aliquam porttitor mauris sit amet orci aenean dignissim pellentesque felis morbi in sem quis dui placerat ornare pellentesque odio nisi, euismod in pharetra a ultricies in diam sed arcu cras consequat lorem ipsum dolor sit amet. Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing commodo quis gravida id, est sed lectus.</p>', '', 1, 2, '2015-05-11 09:55:56', 401, '', '2015-05-11 11:29:58', 401, 0, '0000-00-00 00:00:00', '2015-05-11 09:55:56', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 10, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(2, 58, 'Teknisk info – Dæk', 'teknisk-info-daek', '<h1>TEKNISK INFO - DÆK</h1>\r\n<p><img src="images/daekinfo.jpg" alt="daekinfo" width="300" height="297" /><br />Dæksidemærkning:<br /><br />Dækside mærkning på et dæk indeholder oplysninger om dækkets design og produktion.</p>\r\n<h3>1. Producent/mærke</h3>\r\n<p>Her står producentens navn, fx Michelin, Goodyear, Vredestein, Apollo, Nokian m.fl.</p>\r\n<h3>2. Dækmodel/mønster</h3>\r\n<p>Navn på model eller mønster. Fx. Sport, Pilot, Eagle m.fl.</p>\r\n<h3>3. Dækstørrelse</h3>\r\n<p>Dækstørrelsen er den vigtigste information som findes på dækket. Størrelsen er angivet som en serie tal og bogstaver, som fx. 205/55R16,</p>\r\n<p><b>205</b> = dækkets bredde i mm.<br /> <b>55</b> = dækkets højde i procent af bredden som her er 55% af 205mm,<br /> <b>R</b> = radialdæk, som er det mest almindelige dæk til almindelige biler i dag. <br /> <b>16"</b> = størrelsen på de fælge (i tommer) som passer til dækket</p>\r\n<h3>4. Belastningsindeks</h3>\r\n<p>Belastningsindekset er et indeks som angiver den maksimale vægt som dækket kan bære ved den hastighed, der svarer til hastighedsindekset. I dette eksempel 91, som svarer til 615 kg. pr dæk. Bemærk at den maksimale belastning er ved korrekt dæktryk.</p>\r\n<p><img src="images/10.png" alt="" width="732" height="789" /></p>\r\n<h3>4. Hastighedindeks</h3>\r\n<p>Hastigehdsindekset angiver den maksimale hastigehd, ved hvilken dækket kan bære en vis belastning (svarende til belastningsindekset). Tjek og følg altid bilens manual for at finde ud af hvilken hastighedskode der bedst passer til bilsen. Det er generelt en god idé at alle dæk har samme hastigehdskode. Det kan også være klogt at have dæk med samme hastighedskode som de dæk der oprindelig var monteret på bilen. Skal du have skiftet bare et enkelt dæk på bilen, er det vigtigt at købe dæk med mindst den samme tophastighed eller højere.</p>\r\n<p>Med hensyn til vinterdæk er det acceptabelt at sætte dæk med lavere hastighedskode på. Men det er dog på bekostning af din fart også bliver sat ned.</p>\r\n<p> </p>\r\n<p> <img src="images/11.png" alt="" width="417" height="363" /></p>\r\n<p>Vinterdæk har som regel lavere hastighedsindeks end hvad et sommerdæk har, og det er tildels fordi vinterdæk har et grovere mønser og er lavet af en blødere gummi, med det resultat at dækket bliver ustabilt ved høje hastigheder.</p>\r\n<h3>5. E-mærkning</h3>\r\n<p>Dækket skal også have en E-mærkning. ECE Regulativ 30, som indikerer at dækket lever op til de gældende Europæiske krav.</p>\r\n<h3>6. Godkendelses nummer for støjegenskaber</h3>\r\n<p>Det betyder, at dækket lever op til de Europæiske krav om begrænsning af støj fra dæk.</p>\r\n<h3>7. DOT nummer</h3>\r\n<p>DOT nummer for det amerikanske marked. Det har ingen betydning for Europa.</p>\r\n<h3>8. Produktionsdato</h3>\r\n<p>Produktionsdatoen kan let findes ved at undersøge serienummeret på dækkets sidevæg (8). Serienummeret er en alfanummerisk kode bestående af 11 tegn, der sædvanligvis, men ikke altid, følger efter akronymet "DOT" (se herover). De sidste fire cifre i dette nummer refererer til produktionsdatoen.</p>\r\n<p>De første to cifre angiver produktionsugen (inden for området 01 til 52), mens de sidste to cifre angiver produktionsåret fx. 4500 = uge 45 i 2000.</p>\r\n<p>For dæk produceret inden år 2000 angives produktionsåret med 1 tal i stedet for 2 (dvs. 189 angiver uge 18 i år 1999). I tiåret 1990-2000 blev nogle dæk mærket med en trekant, der pegede på de sidste cifre i serienummeret for at adskille dem fra dæk produceret i tidligere tiår.</p>\r\n<p>Produktionsdatoen er vigtig, fordi et dæk er sammensat af forskellige typer materiale og gummibalndinger med forskellige egenskaber, som forandres med tiden. For enkelte dæk afhænger denne forandring af mange elementer som fx vejret, opbevaringsforhold og anvendelsesbetingelser, som dækket udsættes for igennem sin levetid. Denne brugsrelaterede forandring varierer betydeligt, således at en nøjagtig prognose for levetiden på et bestemt dæk ikke er muligt på forhånd.</p>\r\n<p>Generelt gælder dog, at jo ældre et dæk er, jo større er risikoen imidlertid for, at der er behov for at få det udskiftet som følge af brugsrelateret forandring. Et dæk der har været i brug i 5 år eller mere bør inspiceres mindst en gang om året. De fleste dæk vil af naturlige årsager skulle udskiftes, inden de bliver 10 år gamle, og det anbefales, at alle dæk, som stadig er i brug mere end 10 år efter produktionsdatoen, herunder også dæk på reservehjul, udskiftes med nye dæk, som en simpel forebyggelse. Dæk må helst ikke være mere 6 år gamle.</p>\r\n<h3><br /> 9.  Amerikansk egenskabsmærkning</h3>\r\n<p>En særlig amerikansk mærkning om dækkets egenskaber. Det har ingen betydning for Europa.</p>\r\n<h3>10. Amerikansk belastningsmærkning</h3>\r\n<p>En særlig amerikansk mærkning om belastning. Det har ingen betydning for Europa. (For Europa se under pkt.4)</p>\r\n<h3>11. Max dæktryk</h3>\r\n<p>Fabrikantens max anbefalede dæktryk, har bla. betydning for køretøjer over ca. 2ton. Det er dette dæktryk som en camper skal have i dækkerne. </p>\r\n<h3>12. Slangeløst dæk</h3>\r\n<p>Et mærke der angiver at dækket er slangeløst.</p>\r\n<h3>13. Amerikansk dæktryk mærkning</h3>\r\n<p> En særlig amerikansk mærkning, der advarer om forkert dæktryk, og de følger det kan medføre. Det har ingen betydning for Europa.</p>\r\n<h3>14. Rotationsretning</h3>\r\n<p>Pilen angiver dækkets rotations retning.</p>\r\n<h3>15. Assymetriske dæk</h3>\r\n<p>Asymmetriske dæk har en mærkning, der angiver hvilken side der skal vende udad.</p>\r\n<h3>16. Forstærket</h3>\r\n<p>Angivelse der viser, at dækket kan tåle ekstra belastning (reinforced).</p>\r\n<h3>17. Slidbaneindikator</h3>\r\n<p>TWI er angivet 6 steder rundt på dækket og viser hvor slidindikatorerne findes i bunden af mønsteret.</p>\r\n<h3>18. Mud and snow</h3>\r\n<p>På dæksiden kan der yderligere være påført "M+S", hvilket står for "Mud and snow" eller på dansk "Mudder og sne". Dette indikerer at dækket er et vinterdæk eller et helårsdæk.</p>', '', 1, 2, '2015-05-11 11:56:09', 401, '', '2015-05-11 12:04:15', 401, 0, '0000-00-00 00:00:00', '2015-05-11 11:56:09', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 9, '', '', 1, 23, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(3, 60, 'Teknisk info – Fælge', 'teknisk-info-faelge', '<p>Der er to hovedtyper af fælge, stålfælge og letmetalsfælge (såkaldte alufælge). Ståfælgen er den mest almindelige og er monteret som standard på de fleste køretøjer. Letmetalsfælge er blevet meget almindelig idag, og er monteret som orginal på mange køretøjer. Ofte anvendes de til at opnå ærlige egenskaber, fordi de er lidt lettere og mere bæredygtige. Den mest almindelig årsag til at skifte til letmetalsfælge er imidlertid, det rent æstetiske. Du kan nemt bytte din stålfælg ud med en letmetalsfælg hvis du tager højde for fælgens ET og boltcirkel.</p>\r\n<h2>Fælgens indpresningsdybde, ET-mål</h2>\r\n<p>Fælgens indpresningsdybde, eller ET-mål, viser, hvor langt inde eller ude fælgen sidder i forhold til fælgens midtpunkt.</p>\r\n<p>Det er vigtigt at have den rigtige indpresningsdybde, da forkert indpresningsdybde kan få hjulet til at røre ved skærmens yderkant eller fjedre/støddæmpere. Hvilken indpræsningsdybde, du skal have, afhænger af hvor brede dine fælge er og hvor tore dækkene er, og naturligvis hvilken bil du har. Normalt står indpresningsdybden stemplet på fælgen. Jo højere mål, desto dybere sidder fælgen.</p>\r\n<h2>Boltcirkel</h2>\r\n<p>Boltcirklen handler om hvor mange bolthul fælgen har og dens diameter. Boltcirklen angives som fx 4x110, hvilket betyder 4 bolte med 110 mm cirkeldiameter. Cirkeldiameter er et mål mellem to bolte målt henover centerhullet (fremhævet med rødt). På en 4-bolt fælg måler du fra dit bolthuls yderkant til bolthullets inderste kant på tvær af centerhullet. Forskellige biler har forskellige boltcirkler, hviklet betyder at en fælg ikke passer til alle biler.</p>\r\n<p>På en 5-boltsfælg måler man boltcirklen ved følgende:</p>\r\n<ul>\r\n<li>Mål hele bolthullets diameter (A)</li>\r\n<li>Mål fra bolthullets kant til navhullets kant (B)</li>\r\n<li>Mål navhullets diameter (C)</li>\r\n</ul>\r\n<p>Boltcirklens diameter = A + Bx2 + C</p>\r\n<h2>Fælgdimensioner</h2>\r\n<p>Fælge findes i mange forskellige størrelser og varianter. Når man måler fælge gøre det i tommer. Her er et eksempel på hvordan det kan se ud:</p>\r\n<p>8Jx17</p>\r\n<ul>\r\n<li>8 står for fælgens bredde</li>\r\n<li>J er typen af fælghorn</li>\r\n<li>17 er fælgdiameter målt i tommer.</li>\r\n</ul>\r\n<p> </p>\r\n<p>Når man vælger alufælge, skal man tage stilling til flere forskellige ting. Et af de første er, om fælgene skal være større end de originale. Ved montering af fælge med større diameter, monterer man samtidig dæk med en lavere profil. Det vil sige, at når diameteren på fælgen bliver større, mindsker man højden på dæksiden tilsvarende. Derved bevarer man samme omkreds på hjulet.</p>\r\n<p>Generelt kan man sige, at jo større fælgene er, jo bedre ser det ud på bilen. Desværre er det også sådan, at prisen stiger sammen med fælgstørrelsen. Til en bestemt størrelse fælge, er det tit muligt at montere dæk med forskellig bredde. I valget af dækbredde indgår der flere overvejelser. F.eks. plads i hjulkassen, fælgbredde samt pris.</p>\r\n<p>Når man monterer alufælge på sin bil, skal man være opmærksom på, at der både er fordele og ulemper i forhold til almindelige stålfælge</p>\r\n<p><strong style="margin: 0px; padding: 0px;">Fordele ved alufælge</strong>:</p>\r\n<p>• Det ser godt ud. Langt de fleste køber alufælge for at give bilen et flottere udseende</p>\r\n<p>• Der er mulighed for at montere bredere dæk på bilen</p>\r\n<p>• Der er mulighed for at montere større fælge og dermed lavere dæk</p>\r\n<p><strong style="margin: 0px; padding: 0px;">Fordele ved stålfælge:</strong></p>\r\n<p>• Stålfælge kræver lidt mindre rengøring end alufælge</p>\r\n<p>• Med lavprofildæk kan der være fordele med stålfælge, idet alufælge kan betyde en større risiko for at skrabe fælgkanterne med kantsten</p>\r\n<p>Ved montering af alufælge, skal man huske at efterspænde dem efter 50 - 100 km. og igen efter 400 - 500 km. Dette er især vigtigt ved helt nye fælge, da det nye aluminium godt kan "arbejde" lidt. Hjulboltene skal spændes krydsvis med et moment på 100 nm. (gælder for de fleste biler). Har du købt alufælge hos os, kan du naturligvis bare komme forbi, så efterspænder vi hjulene.</p>\r\n<p>Når man monterer andre fælge på en bil, er der nogle krav, som skal være opfyldt, for at det er lovligt</p>\r\n<p>Sporvidde I Danmark er det lovligt, uden nogen form for dokumentation, at forøge en bil''s sporvidde med 20 mm (10 mm. pr. side). Man skal dog være opmærksom på, at man regner ud fra den mindste sporvidde, som er anført på bilens standardtypegodkendelsesattest. Dvs. at bilen kan være godkendt med flere forskellige fælge, som hver især giver bilen forskellige sporvidder. Her benytter man så fælgen med den mindste sporvidde som udgangspunkt. Hvis en given fælg giver en endnu større sporviddeforøgelse, eller hvis sporvidden formindskes, kan fælgen stadig godt være lovlig, hvis der foreligger en TÜV-attest som dokumentation.</p>\r\n<p>Udover sporvidden, skal de nye hjul også overholde skærmreglementet for at være lovlige. Det betyder, at hele hjulet skal være indenfor skærmen inkl. dæksidens runding. Hvis dette ikke er opfyldt, vil hjulet ikke være lovligt, uanset om de er lovlige med hensyn til sporvidde. Vores ekspedienter vil kunne vejlede dig omkring reglerne i forhold til netop din bil.</p>', '', 1, 2, '2015-05-12 13:49:56', 401, '', '2015-05-12 14:41:59', 401, 0, '0000-00-00 00:00:00', '2015-05-12 13:49:56', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 8, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(4, 61, 'Teknisk info - Hjul', 'teknisk-info-hjul', '<div class="article">\r\n<p>Dækket og fælgen bliver til hjul - en samlet enhed. Den rigtige fælg og det rigtige dæk er vigtigt for at give bilen de rigtige egenkaber.</p>\r\n<p align="left"> </p>\r\n<p>Dæk og fælgdimension kan erstattes hvis hjulet ikke rager ud over kærmen efter ændringen eller hvis den ikke rammer nogle chassisdel ved fuld uspension eller i noget drejningmoment. Ændringer, der gør væsentlige ændringer ved kørelsdynamikken gør ændringen ulovlig. Holder man sig til fælg og dæk dimensioner i nærheden af det der orginalt var monteret på køretøjet, bør ændringen ikke give nogle problemer.</p>\r\n<p align="left"> </p>\r\n<h2>Hjulet diameter</h2>\r\n<p align="left"> </p>\r\n<p>Sørg for at hjuldiameter ikke ændrer sig, når du skifter dæk/fælg. Med større hjul kan du ramme skærmkanter eller støddæmpere, fjerdre el.</p>\r\n<p align="left"> </p>\r\n<p>Hjulets højde er fælgens størrelse plus det dobbelte af dækprofilen.</p>\r\n<p align="left"> </p>\r\n<p>Fx: Dækstørrelse 225/45-17</p>\r\n<p align="left"> </p>\r\n<ul>\r\n<li>225 er dækket bredde i mm</li>\r\n<li>45 er højden på dækkets profil i % af bredden</li>\r\n<li>17 er dækkets størrelse (inderdiameter) i tommer</li>\r\n</ul>\r\n<p align="left"> </p>\r\n<p>Formularen for eksemplet herover bliver (17*25,4)+(2*0,45)), hvilket giver en diameter på 634 mm.</p>\r\n<p align="left"> </p>\r\n<h2>Rulningsomkreds</h2>\r\n<p align="left"> </p>\r\n<p>Rulningsomkredsen på dækket er lig med den strækning hjulet ruller på én rotation.Vi anbefaler ikke dæk eller fælg når rulningomkredsen forandres mere end ±5% sammenlignet med rulningsomkredsen på hjulet som bilen er godkendt til.</p>\r\n<p align="left"> </p>\r\n<p>Fx:</p>\r\n<p align="left"> </p>\r\n<ul>\r\n<li>Dækstørrelse 225/45-17</li>\r\n<li>Diameteren i eksemplet er 634 mm</li>\r\n<li>Rlningsomkredsen er 634 mm multipliceret med pi (3,141592) og får 1992 mm.</li>\r\n</ul>\r\n<p align="left"> </p>\r\n<p>Hvis 224/45-17 er den oprindelige størrelse, betyder dette at du kan skifte til andre dæk så længe rulningsomkredsen er indenfor ±5%, hvilket vil sige mindst 1892 mm og højst 2092.</p>\r\n<p align="left"> </p>\r\n<h2>Forøgelse af størrelse</h2>\r\n<p align="left"> </p>\r\n<p>Når der skiftes til større fælg end bilens orginale er det vigtigt at hjulets rulningsomkreds ikke øges. Dette kompenserer man ved at have en lavere profil på dækket.<span style="font-family: Arial; font-size: 10pt;"><br /></span><span style="font-family: Arial; font-size: 10pt;"><br /></span></p>\r\n</div>', '', 1, 2, '2015-05-12 14:44:10', 401, '', '2015-05-12 14:44:10', 0, 0, '0000-00-00 00:00:00', '2015-05-12 14:44:10', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 7, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(5, 62, 'EU-mærkning af dæk', 'eu-maerkning-af-daek', '<p>Der vil blive indført en ny dækmærkning i EU i 2012. Næsten alle dæk, der produceres efter juni 2012 og sælges fra november 2012 inden for EU skal bære et mærkat eller ledsages af et mærke i henhold til forordningen EC 1222/2009. Denne forordning vil, sammen med andre faktorer der normalt tages i betragtning, når man beslutter sig for et køb, give slutbrugeren mulighed for at fortage et bedre valg, når de køber nye dæk.</p>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top">\r\n<p><img src="images/eu_mærke.png" alt="eu mærke" width="280" height="411" /></p>\r\n</td>\r\n<td>\r\n<p>Et eksempel på det nye EU-mærkat kan ses til venstre. Dette mærkat svarer til den almindeligt brugte mærkning af husholdningsartikler, såsom vaskemaskiner og opvaskemaskiner.</p>\r\n<p>Målet med mærkningen er at gøre vejtransporten sikrere og øge dens økonomiske og miljømæssige effektivitet ved at fremme sikre og brandstofbesparende dæk med lave støjniveauer. Mærkningen opstiller også rammerne for formidling af harmoniserede oplysninger om nogle dækparametre i hele branchen.</p>\r\n<p>Mærkningen er obligatorisk for:</p>\r\n<ul>\r\n<li>Dæk til biler og SUV''er</li>\r\n<li>Dæk til lette erhvervskøretøjer</li>\r\n<li>Lastvognsdæk</li>\r\n</ul>\r\n<p>Mærkningen gælder dog ikke for:</p>\r\n<ul>\r\n<li>Regummiering</li>\r\n<li>Professionelle offroad dæk</li>\r\n<li>Dæk, der ikke er tilladte på offentlige veje, såsom racerdæk</li>\r\n<li>Type T reservedæk til midlertidig brug</li>\r\n<li>Dæk til veteranbiler</li>\r\n<li>Dæk, hvis hastighedskode er under 80 km/t</li>\r\n<li>Dæk med en nominel fælgdiameter på højst 254 mm eller på mindst 635 mm</li>\r\n<li>Dæk med funktioner, der forbedrer vejgrebet (såsom pigdæk)</li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2>Dækleverandørernes (producenter og importører) ansvar</h2>\r\n<p>Når dæk leveres til en kunde, skal de ledsages af et mærkat for hver dækstørrelse og type i leverancen svarende til det mærkat, der vises til venstre. Dette krav kan også opfyldes ved at sætte et mærkat på hvert dæk.</p>\r\n<p>Alt reklamemateriale og teknisk og teknisk materiale skal vise mærkatværdierne for hvert dæk på en forståelig måde. Producentens og forhandlerens hjemmesider skal ligeledes vise mærkatoplysninger for de dæk, der tilbydes.</p>\r\n<h2>Dækforhandlernes ansvar (dem der sælger dæk til slutbrugere)</h2>\r\n<p>De skal for dæk til personvogne og lette erhvervskøretøjer sikre, at hvert dæk bærer et mærkat på et klart synligt sted eller inden dækket sælges, forevise mærkatets oplsyninger for slutbrugeren, og et mærkat skal være klart synligt i umiddelbar nærhed af dækket.</p>\r\n<p>Mærkatets oplysninger skal ligeledes gives, når dæk, der udbydes til salg, ikke er synlig for kunden.</p>\r\n<p>Distributørerne skal for samtlige dæk (personbiler, lette erhvervskøretøjer, lastbiler og busser) sikre, at mærkatets værdier for samtlige købte dæk ligeledes er anført på kundens regning eller udleveres sammen med denne.</p>\r\n<h2>Hvordan aflæses mærkatet?</h2>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td><img src="images/eu_mærke_1.png" alt="eu mærke 1" width="250" height="208" /></td>\r\n<td>Effektiv udnyttelse af brændstoffet er vigtigt både for at reducere CO² udledningen og kørselsomkostningerne. Kategorierne er indelt fra A (grøn) til G(rød). Kategori D benyttes ikke her. Forskellen mellem hver kategori indikerer en besparelse eller øgning af brændstofforbruget på mellem 0,10 og 0,15 liter per 100 km for en bil der kører ca. 15 km/liter. Forskellen mellem klasse G og klasse A for et komplet dæksæt kan, afhængig af køretøj og kørselsforhold, reducere brændstofforbruget med op til 7,5%.</td>\r\n</tr>\r\n<tr>\r\n<td><img src="images/eu_mærke_2.png" alt="eu mærke 2" width="250" height="208" /></td>\r\n<td>\r\n<p>Vejgreb på våd vej er en afgørende faktor for sikkerheden, og indikerer dækkenes evne til at standse bilen hurtigt på våde veje, og kan forklares ved hjælp af bræmselængder. Kategorierne er A til G, hvor D og G ikke benyttes. Effekten kan variere afhængigt af køretøjet og kørselsforholdende, men forskellen mellem hver kategori svarer til en bremselængde på mellem en og to billængder (eller mellem 3 og 6 meter) når der bremses ved en hastighed på 80 km/t. Forskellen mellem klasse F og A for et sæt bestående af fire identiske dæk afkorte bremselængden med 30% (fx kan dette reducere bremselængden med 18 meter for en almindelig bil der kører 80 km/t.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td><img src="images/eu_mærke_3.png" alt="eu mærke 3" width="250" height="208" /></td>\r\n<td>\r\n<p>Her er der tale om støjniveauet fra dækkene udenfor kabinen. Det eksterne støjniveau inddeles i tre kategorier og måles i decibel (dB) sammenlignet med de nye europæiske niveauer for støj afgivet til omgivelserne, som skal introduceres frem til 2016.  Jo flere rammer, der er udfyldt med sort på mærkaten, jo mere støjer dækkene.</p>\r\n<ul>\r\n<li><b>1 sort lydbølge</b>: dæk med lav udvendig støj. 3 dB mindre end den kommende strammere europæiske grænse</li>\r\n<li><b>2 sorte lydbølger</b>: dæk med gennemsnitlig udvendig støj. Dækket opfylder allerede den kommende europæiske grænse.</li>\r\n<li><b>3 sorte lydbølger</b>: dæk med høj udvendig støj. Dækket opfylder den aktuelle europæiske grænse, med er højere end den kommende grænse.</li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '', 1, 2, '2015-05-12 14:51:28', 401, '', '2015-05-12 14:57:08', 401, 0, '0000-00-00 00:00:00', '2015-05-12 14:51:28', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 6, '', '', 1, 3, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(6, 63, 'Vedligeholdelsesguide Dæk', 'vedligeholdelsesguide-daek', '<p>Du kan forlænge levetiden på dæk, hvis du sørger for en passende vedligeholdelse. Der er mange faktorer, der påvirker holdbarheden af dæk og i nedenstående gennemgår vi følgende faktorer:</p>\r\n<ol>\r\n<li>Opbevaring af dæk</li>\r\n<li>Kontrol af dæktryk</li>\r\n<li>Dækslitage</li>\r\n<li>Monteringsregler</li>\r\n</ol>\r\n<h2>1. Opbevaring af dæk</h2>\r\n<p>Hvis dine dæk skal bevare deres egenskaber, skal de opbevares rigtigt.</p>\r\n<p>Før du skifter dine dæk, bør du markere retningen på dækket med et stykke kridt samt markere hvor dækkene har været monteret (f.eks. vf =venstre forhjul, hb =højre baghjul. Gør derefter dækkene rene, og fjern grus og lignende. Når du rengører din bil eller fælge skal du være opmærksom på, at dækkene ikke kan tåle "skrappe" rengøringsmidler eller silikone. Vask dine dæk med vand og almindelig bilshampoo.</p>\r\n<p>Når gummi ældes, bliver det hårdt og revner, hvis det ikke opbevares rigtigt. For at holde dækkene i god stand mellem to sæsoner, skal visse regler følges.</p>\r\n<h3>Temperatur</h3>\r\n<p>Temperaturen i det lokale dækkene opbevares , bør ikke overstige +25°. Lokalte skal helst være mørkt, og temperaturen skal helst ligge rundt de 15°. Hvis temperaturen er over +25° eller under 0°kan gummiets egenskaber egenskaber forandres, og dette kan forkorte dækkets levetid.</p>\r\n<h3>Fugtighed</h3>\r\n<p>Dæk bør ikke opbevares på alt for fugtige steder. Fugtigheden bør ikke være så høj, at dækkene ser fugtige ud. Dæk bør heller ikke ligge ude i regn.</p>\r\n<h3>Lys</h3>\r\n<p>Dæk bør beskyttes mod lys, specielt mod direkte sollys og mod stærkt lampelys med høj UV-faktor.</p>\r\n<h3>Kemikalier</h3>\r\n<p>Sørg for at dæk ikke kommer i nærheden af kemikalier, opløsningsmidler eller kulbrinter, som kan forringe dækkets egenskaber. I det rum, hvor dækkene opbevares, må der ikke opbevares apparater som genererer ozon, fx fluor- eller kviksølvdampe, højspændte elektriske apparate, el-motorer eller andre former for el-apparater som kan afgive gnister eller strømudladning. Dæk må specielt beskyttes mod kontakt med løsemidler, olie og fedt. Selv kortvarig kontakt med sådanne stoffer, kan give skade.</p>\r\n<h3>Formforandring</h3>\r\n<p>Om muligt bør dæk opbeares på en sådan måde, at de ikke ligger under pres, spænding eller vridning. Kraftige formforandringer under opbevaring kan medføre defekt, når man øger lufttrykket i dækket.</p>\r\n<h3>Dækhåndtering</h3>\r\n<p>Du må aldrig slippe dæk ned fra større højder en 1,5 meter, da dette kan skade dækket i bead-området. En typisk konsekvens kan være bøjet bead. Et dæk med bøjet bead, må ikke monteres på en fælg.</p>\r\n<p>Dæk på fælge skal aldrig opbevares stående på gulvet - de skal hænges op eller stakkes liggende (ideelt på en træpalle). Dæk uden fælge skal derimod opbevares stående. For at udgå at dækmærker opstår, bør de drejes lidt hver fjerde uge. De må ikke hænges op eller stakkes.</p>\r\n<p><img src="images/dækop.png" alt="dækop" width="336" height="293" /></p>\r\n<p>Før du sætter dækkene på igen, skal du altid kontrollere dem for beskadigelse samt slitage, og kontrollere resterende dækmønsterdybde og eventuel ubalance.</p>\r\n<h2>2. Dæktryk</h2>\r\n<p>Det er luften i dækkene som bærer bilen, og det er meget vigtigt at dækkene har det korrekte lufttryk for at opnå optimale styre- og bremseevner samt den bedste brændstoføkonomi.</p>\r\n<h3>Anbefalet dæktryk</h3>\r\n<p>Det  anbefalede dæktryk fremgår af bilens instruktionsbog og/elleren mærkat, der som regel er fatklæbet i venstre fordørsåbning, benzindækslet eller i handskerummet. Overhold dette tryk! Det er fremkommet efter en lang række tests udført af dækfabrikanten og bilproducenten. Bemærk at der kan være forskel mellem for- og bagdæk samt særlige krav til dæktryk ved kørsel med tungt læs, høj hastighed eller campingvogn.</p>\r\n<h3>Regelmæssigt tjek</h3>\r\n<p>Husk regelmæssigt at tjekke dæktrykket. Mindst hver én gang om måneden og altid inden længere rejser, især hvis du skal køre på motorvej. Trykket skal måles med kolde dæk (ikke lige efter kørsel med høj hastighed eller lang distance). Hvis du ikke kan vente, til de er kolde, lægges 0,3 bar til det anbefalede tryk. Luk aldrig luft ud af varme dæk.</p>\r\n<p>Lufttemperaturen påvirker trykket i dækkene. Jo lavere temperatur, jo lavere er det målte tryk. Derfor anbefales det at lægge 0,2 bar til referencetrykket om vinteren.</p>\r\n<p>På de fleste tankstationer findes dæktrykmålere, men en god ide er at investere i en dæktryksmåler og evt. kompressor, så man kan tjekke trykket derhjemme.</p>\r\n<p>Mister du en ventilhætte, eksempelvis når du tjekker dæktrykket, er det vigtigt at du snarest kører forbi et værksted og køber en ny. Hvis man kører uden ventilhætte, vil der sætte sig skidt fra vejen i ventilen som derved kan blive utæt når der næste gang tjekkes tryk i dækket.</p>\r\n<h3>Konsekvenser af forkert dæktryk</h3>\r\n<p>Udover dårlig vejkontakt og brændstoføkonomi vil forkert dæktryk også forårsage unormalt slid på dækket og vil medføre forkortet levetid. Ved kørsel med 1 bar for lavt tryk øges brændstofforbruget med helt op til 15 %. Desuden kan for lavt dæktryk halvere dækkets levetid!</p>\r\n<p><img src="images/dæktryk.png" alt="dæktryk" width="300" height="237" /></p>\r\n<h4>For højt tryk (+0,5 bar)</h4>\r\n<p>Hvis dækkene er pumpet for højt op, slides de hurtigere midt på, hvilket forkorter dækkets levetid. Desuden betyder en mindre kontaktflade med vejen et forringet vejgreb, som kan være farligt i sving eller under bremsning.</p>\r\n<h4>For lavt tryk (-0,5 til -1,5 bar)</h4>\r\n<p>Hvis dækkene er pumpet utilstrækkeligt op (-0,5 bar), slides hurtigere ved skuldrene, hvilket også forkorter dækkets levetid. Desuden øger det fladtrykkede dæk brændstofforbruget, og vandet ledes mindre effektivt væk. Hvis dækkene er pumpet helt utilstrækkeligt op (-1,5 bar), kan du køre galt. Dækkene bliver overophedet og risikerer at springe.</p>\r\n<h2>3. Dækslitage</h2>\r\n<p>Sørg for regelmæssigt at tjekke mønsterdybden på dine dæk og udskift dem, når de er slidte. Det garanterer maksimalt greb og forhindrer ubehagelige overraskelser. Udskift dien dæk, før mønsterdybden er slidt ned til den lovlige grænse. Den lovlige slidgrænse er fastsat til 1,6 mm mønsterdybde, men dækkets ydelse formindskes efterhånden som slidbanen slides. Du må derfor måle dækkenes slitage efter et vist antal kilometer. I almidelighed skal et dæk af god kvalitet skiftes for hver 40.000-50.000 km og af en mindre god kvalitet for hver 10.000 km. Du kan kontrollere dækkenes slitage ved at undersøge dine dæks slidindikator.</p>\r\n<p>Slidindikatoren er en lille 1,6 mm tyk gummiklods, som sidder i bunden af dækmønsteret eller - rillerne. Når slidbanen kommer ned i plan med indikatoren, er dækkene slidt til den lovlige grænse og skal skiftes. Hvis grænserne overskrides, er dækkene ulovlige.</p>\r\n<p>Der kan være mange forskellige årsager til, at dæk slides uens. Herunder kan man se en vejledning til, hvorfor dæk slides som de gør.</p>\r\n<p><img src="images/slid.png" alt="slid" width="527" height="711" /></p>\r\n<h3>Byt rundt på dækkene, så slides de mindre</h3>\r\n<p>Ved med jævne mellemrum at bytte rundt på dækkene, kan du opnå mange fordele, du kanbl.a. forsinke dækslitage og opnå forbedringer i hjulenes ydeevne. Vi anbefaler, at dækkene byttes om mellem hver kørte 10.000 til 15.000 km. Du kan med fordel bytte rundt på hjulene, når bilen er inde til service eller olieskift og alligevel er hejst op. Dette kan også være et godt tidspunkt til at afbalancere dine hjul.</p>\r\n<p>Selv om en bil er udstyret med 4 hjul, udfører for- og baghjul vidt forskellige opgaver. Der vil være forskellig grad og af slitage og forksellige slitage typer, alt efter hvilken af de fire positioner, hjulet sidder på. Du kan derfor forlænge hjulenes levetid, ved at bytte rundt på dækkene.</p>\r\n<p>Der er tre rotationsmønstre, som dækker de fleste kæretøjer, som er udstyret med ikke-retningsbestemte dæk og hjul af samme størrelse og offset. Det første (figur A) er "Bagudrettet kryds", det andet (figur B) er  "Forudrettet kryds" og det tredje (figur C) er "X-mønster". X-mønsteret kan bruges som et alternativ til A og C.</p>\r\n<p>Dagens performance dæk og hjultrends har betydet et behov for to ekstra rotationsmønstre. "For-til-bag" (figur D) mønster kan bruges til køretøjer som er udstyret med samme størrelse retningsbestemte dæk. Et "Side-til-side" (figur E) mønster kan bruges af køretøjer, som er udstyret med ikke-retningsbestemte dæk af forskellig størrelse på henholdvis for- og bagaksel.</p>\r\n<p>Hvis de to sidste rotation mønstre ikke giver jævn slitage vil afmontering, montering og rebalancering være nødvendigt for at rotere dækkene.</p>\r\n<p>Køretøjer, der bruger forskellige størrelser retningsbestemte hjul og dæk, og / eller hjul med forskellig offset foran og bag og retningsbestemte dæk vil kræver afmontering, montering og afbalancering i forbindelse med rotation af hjulene.</p>\r\n<h2>4. Monteringsregler</h2>\r\n<p>Der findes nogle grundlæggende regler, som du bør kende, hvis du skal montere et ny dæk på din bil.</p>\r\n<p>Generelt skal du sikre at bilproducentens anbefaling overholdes i forhold til opbygning, dækstørrelse (bredde, højde, diameter), hastigheds- og belastningsindeks. Derudover skal du sikre, at dækkene efterses indvendig og udvendig for eventuelle fejl. Endvidere skal fremgangsmåden for måntering overholdes - dvs. afmontering, afbalancering og oppumpning af dækket, udskiftning af ventil, overholdelse af monteringsanvisningerne på dækket (omløbsretning eller monteringsretning).</p>\r\n<p>Bland aldrig radialdæk og ikke-radialdæk på et køretøj. Hvis det er uundgåeligt at blande dæk, så bland aldrig radialdæk og ikke-radialdæk på samme aksel. Hvis to radialdæk og to ikke-radialdæk monteres på et køretøj, skal de to radialdæk monteres på bagakselen på bagakselen og de to ikke-radialdæk på forakselen.</p>\r\n<h3>Hvis du kun skifter et dæk</h3>\r\n<p>Hvis du kun skifter et dæk, skal du sikre, at dette dæk har samme slidbanemønster (fx retningsbestemt, asymmetrisk), samme mål og samme belastnings- og hastighedsindeks som, det dæk der udskiftes. Derudover skal du sikre dig, at forskellen i slitage i forhold til dækket på samme aksel er under 5 mm.</p>\r\n<h3>Hvis du skifter to dæk</h3>\r\n<p>Hvis du skifter to dæk, skal disse monteres på bagakselen. For selv om fordækkene slides hurtigere end bagdækkene, viser adskillelige test, at det er lettere at kontrollere forakselen end bagakselen. Hvis de nye dæk monteres på bagakselen, opnår du bedre køreegenskaber i kurver på vådt underlag og øget sikkerhed.</p>\r\n<p> </p>\r\n<p>Det er nemt at glemme, at dækkene er den eneste kontaktflade mellem køretøjet og vejbanen. Det er derfor, det er utrolig vigtigt at bevare dine dæks gode kvaliteter og egenskaber for at garantere både din sikkerhed og din mobilitet. For at gøre dette anbefaler vi, at du overholder følgende sikkerhedsanbefalinger.</p>\r\n<p class="section-heading first-child">1. Kontaktflade</p>\r\n<p><strong>ET STORT JOB FOR EN LILLE OVERFLADE<br /></strong>Den del af dit dæk, som rent faktisk er i kontakt med vejbanen, er ikke større end din hånd. Din sikkerhed, komfort og brændstoføkonomi afhænger også af denne meget lille overflade. Derfor skal du sikre dig, at du ikke bare vælger det rigtige dæk, men også regelmæssigt vedligeholde dem korrekt. Det er vigtigt, eftersom dine dæk:</p>\r\n<p> </p>\r\n<ul>\r\n<li class="first-child">Er den eneste forbindelse mellem dit køretøj og vejbanen</li>\r\n<li>Bærer hele bilens vægt, en belastning op til 50 gange dets egen vægt</li>\r\n<li>Reagerer på førerens krav såsom styring, acceleration og opbremsning</li>\r\n<li class="last-child">Absorberer hver eneste forhindring på vejen</li>\r\n</ul>\r\n<p> </p>\r\n<p> </p>\r\n<p class="section-heading">2. Mønsterdybde og slitage</p>\r\n<p><strong>EN HURTIG OG ENKEL SIKKERHEDSFORANSTALTNING</strong><br />Sørg for regelmæssigt at tjekke mønsterdybden på dine dæk og udskifte dem, når de er slidte. Det garanterer maksimalt greb og forhindrer ubehagelige overraskelser. Udskift dine dæk, før mønsterdybden er slidt ned til 1,6 mm. Michelins dæk har slidindikatorer, som sidder nede i bunden af dækmønsteret i en højde af cirka 1,6 mm. Din sikkerhed og mobilitet afhænger af en lovlig mønsterdybde eftersom:</p>\r\n<p> </p>\r\n<ul>\r\n<li class="first-child">Mønstersporene dræner vandet under dækkene væk, så du kan bevare kontrollen</li>\r\n<li>Jo mere mønsterdybde, der er tilbage på dine dæk, jo mere vand kan du dræne væk og dermed reducere risikoen for akvaplaning</li>\r\n<li>Korrekt lufttryk såvel som regelmæssig vedligeholdelse af køretøjet sikrer, at dine dæks præstationer er optimale i længst mulig tid</li>\r\n<li class="last-child">Dækmønsteret griber fat i vejen og har betydning for din bremselængde</li>\r\n</ul>\r\n<p> </p>\r\n<p> </p>\r\n<p class="section-heading">3. Lufttryk</p>\r\n<p><strong>KONTROLLÉR LUFTTRYKKET EN GANG OM MÅNEDEN</strong></p>\r\n<p>Korrekt lufttryk reducerer risikoen for at miste kontrollen over køretøjet. Det beskytter også dine dæk mod for tidlig slitage og uoprettelig indvendig skade. Lufttrykket kan falde på grund af små perforeringer, naturligt udslip af luft gennem dækkets bestanddele eller fra skiftende temperaturer. Kontrollér lufttrykket i dine dæk, inklusive reservehjulet, en gang om måneden og helst på kolde dæk (som ikke har kørt i mindst 2 timer, eller som kun har kørt meget en meget kort strækning ved lav hastighed). Hvis dækkene kontrolleres, når de er varme, skal der lægges 0,2 bar til det anbefalede lufttryk. Det er vigtigt at kontrollere lufttrykket en gang om måneden fordi:</p>\r\n<ul>\r\n<li class="last-child first-child">\r\n<p>Lavt lufttryk øger risikoen for skader på dækket</p>\r\n</li>\r\n<li class="first-child">\r\n<p>Et 20 % for højt lufttryk reducerer dækkets levetid med omkring 10.000 km.</p>\r\n</li>\r\n<li>\r\n<p>Korrekt lufttryk sparer brændstof</p>\r\n</li>\r\n<li>\r\n<p>Det anbefalede lufttryk er IKKE findes på dækket. Det lufttryk, som er angivet på dæksiden, er kun det maksimale lufttryk, dækket kan tåle. Det anbefalede lufttryk kan findes:</p>\r\n</li>\r\n<li>\r\n<p>I dit køretøjs instruktionsbog</p>\r\n</li>\r\n<li>\r\n<p>På mærkaterne på indersiden af fordøren i førerens side</p>\r\n</li>\r\n<li>\r\n<p>I opbevaringsrummet tæt ved førersædet</p>\r\n</li>\r\n<li class="last-child">\r\n<p>På indersiden af tankklappen</p>\r\n</li>\r\n</ul>', '', 1, 2, '2015-05-12 15:20:15', 401, '', '2015-05-12 15:20:15', 0, 0, '0000-00-00 00:00:00', '2015-05-12 15:20:15', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 5, '', '', 1, 4, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(7, 64, 'Udskiftning af dæk', 'udskiftning-af-daek', '<p>Det er ikke muligt at bestemme et dæks levetid, eftersom der er mange faktorer, som spiller ind, fx kørestil, vejr og opbevaring.</p>\r\n<p>Vi har herunder opstillet en liste over 6 grunde til at udskifte dine dæk.</p>\r\n<h2>1. Hvis du punkterer</h2>\r\n<p>Moderne dæk er meget robuste og kan klare de fleste ting. Punkteringer kan dog stadig ske. En specialist bør altid tjekke dine dæk efter en punktering for at opdage skjulte skader, som kan betyde, at dækket ikke kan repareres.</p>\r\n<h2>2. Hvis dækkene er slidt</h2>\r\n<p>Det er altid klogt at kontrollere dine dæks slitage regelmæssigt. Hvis dine dæk er slidt ned til lovens minimumskrav på 1,6 millimeter, skal dækkene skiftes. De fleste dæk har indstøbte slidindikatorer i bunden af dækkets dækmønster. Hvis mønsteret er slidt ned til det niveau, så du kan se et gummimærke på tværs af slidbanen, er det på tide at få skiftet dine dæk.</p>\r\n<h2>3. Hvis dine dæk viser tegn på ældning</h2>\r\n<p>Dæk har ikke en forudsigelig holdbarhed. Det betyder ikke noget, hvornår dækkene blev produceret. Dæk ældes, selv når de ikke bruges, eller hvis de kun bruges lejlighedsvis. Der er mange faktorer, som vil påvirke dækkets liv, herunder temperatur, vedligeholdelse, forhhold under opbevaring og brug, belastning, hastighed, lufttryk såvel som kørestil. Disse faktorer har stor indvirkning på længden af den brugstid, du kan forvente af dine dæk.</p>\r\n<p>Det er derfor vigtigt at du holder øje med dækkenes udvendige udseende for at opdage tydelige tegn på ældning eller trærhed. Det kan være krakeleringer i gummiet på mønsteret udvendigt, skulder og kant samt deformation mm. Udsædvanlig kraftig ældning af dæk kan føre til tab af greb.</p>\r\n<h2>4. Hvis dit dæk er beskadiget</h2>\r\n<p>Dit dæk kan blive alvorligt beskadiget, hvis det støder sammen med en solid genstand på vejen, fx en kantesten, et hul i vejen eller en skarp genstand. Alle synlige perforeringer, snit eller deformationer skal kontrolleres grundigt af en dækspecialist. Kun en fagmand kan sige, om dækket skal repareres, eller om det skal udskiftes. Husk alrdig at bruge beskadigede dælk, eller sæk som har kørt uden luft.</p>\r\n<h2>5. Hvis du identificerer unormal slitage</h2>\r\n<p>Unørmal, ujævn dækslitage, indikerer ofte et mekanisk problem såsom forkert hjulsporing eller et problem med afbalancering, hjulophæng eller gear. Det kan også skyldes at du kører med forkert dæktryk. Hvis du observerer unormal slitage, skal du kontakte en fagmand.</p>\r\n<p>For at undgå ujævn slitage skal du have hjulene sporet og afbalanceret hvert halve år. Det vil også forlænge slidbanens levetid og give dig en mere jævn kørsel. En anden måde at holde slidbanen jævn er ved regelmæssigt at rotere hjulene.</p>\r\n<h2>6. Hvis dækkene ikke egner sig til dit køretøj</h2>\r\n<p>For at opnå de bedste præstationer samlet sæt, bør du altid bruge de samme dæk på alle hjul. Dæk med forskellige dimensioner, opbygning og slidgrad kan påvirke køretøjets manøvrering og stabilitet.</p>\r\n<p>Du må heller ikke blande radial og ikke-radial dæk på et køretøj.</p>\r\n<p> </p>', '', 1, 2, '2015-05-12 15:21:57', 401, '', '2015-05-12 15:21:57', 0, 0, '0000-00-00 00:00:00', '2015-05-12 15:21:57', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 4, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');
INSERT INTO `g2q6h_content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(8, 65, 'Vinterdæk regler', 'europaeiske-vinterdaekregler', '<h1>Europæiske vinterdækregler</h1>\r\n<p><img src="images/vinter.png" alt="vinter" width="334" height="220" /><br /><br />Når vinteren og skiferien kommer tættere på, er det tid til at få styr på reglerne for vinterdæk og vinterudstyr i de lande, man skal besøge i løbeet af vinteren. Dækcenter.nu har derfor lavet en oversigt, hvor du kan se reglerne for de mest populære vinterferiedestinationer: Sverige, Norge, Tyskland, Østrig, Schweiz, Frankrig og Italien.</p>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><img src="images/sverige.gif" alt="sverige" width="164" height="101" /></td>\r\n<td>\r\n<h2><strong>Sverige - Vinterdæk regler Sverige</strong></h2>\r\n<p> </p>\r\n<h3>Vinterdæk</h3>\r\n<p>For køretøjer med en tilladt totalvægt på under 3500 kg er vinterdæk obligatorisk mellem 1. december og 31. marts i tilfælde af vintervej. Dvs. sne eller is på vejen eller en våd vejoverflade kombineret med temperaturer omkring eller under 0ºC. Dette gælder også for anhængere. Dækkene skal have en mønsterdybde på minimum 3 mm.</p>\r\n<p>Politiet tager den endelig beslutning om, hvornår der er tale om vintervejr på specifikke veje. Er der ikke tale om vintervejr på vejene, må man principielt gerne køre med sommerdæk i perioden mellem mellem 1. december og 31. marts, selvom dette dog ikke anbefales.</p>\r\n<p>Bøden for ikke at køre med vinterdæk i vintervejr er 1200 SEK.</p>\r\n<p>Reglerne for vinterdæk gælder ikke køretøjer med en totalvægt over 3500 kg. Sådanne køretøjer må selv i vintervejr køre med sommerdæk. I så fald skal dækkene være mindst 5 mm dybe.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Pigdæk er tilladt mellem 1. oktober og 15. april. Hvis vejr- og vejforholdene kræver det, er de også tilladt uden for denne periode. Dette vil oftest være tilfældet i den nordlige del af landet. Benyttes pigdæk, skal de monteres på alle 4 hjul. For biler med pigdæk, der trækker en anhænger, er det kun nødvendigt at montere pigdæk på anhængeren, såfremt man kører på sne- eller isdækkede veje. Bemærk, at der kan være enkelte lokale restriktioner for kørsel med pigdæk. F.eks. er pigdæk ikke tilladt på Hornsgatan i Stockholm.</p>\r\n<h3>Snekæder</h3>\r\n<p>Det er tilladt at benytte snekæder på alle typer biler i Sverige, hvis vejr- og vejforhold kræver det. Der er ingen særlige fartgrænser for køretøjer med snekæder. Det er ikke muligt at leje snekæder i Sverige, men de kan købes.</p>\r\n<h3>Andet udstyr</h3>\r\n<p>Det er nødvendigt, at bilen har sprinklervæske med antifrost, ligesom man skal medbringe en skovl til at fjerne sne. Det anbefales også at medbringe et reb, startkabler og sikkerhedsvest.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td style="text-align: justify;"><img src="images/norge.gif" alt="norge" width="165" height="120" /></td>\r\n<td>\r\n<h2><strong>Norge - Vinterdæk regler Norge</strong></h2>\r\n<p> </p>\r\n<h3>Vinterdæk</h3>\r\n<p>I den norske færdselslov står der: "Når føret gør det nødvendigt, må et motorkøretøj ikke bruges, uden at hjulene er sikret tilstrækkeligt vejgreb ved hjælp af pigge, snekæder eller lignende". Det betyder i praksis, at man om vinteren skal køre med vinterdæk eller pigdæk. Vinterdæk skal monteres på alle 4 hjul og have en minimumdybde på 3 mm.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Det er tilladt at køre med pigdæk fra 1. nov. til første søndag i den følgende påske. I de nordlige provinser (Nordland, Troms og Finnmark) er det dog tilladt at køre med pigdæk fra 15. okt. til 1. april. Pigdæk skal monteres på alle fire hjul, når de benyttes. Nogle byer har indført afgift for at køre med pigdæk.</p>\r\n<h3>Snekæder</h3>\r\n<p>Man skal medbringe snekæder ved kørsel i Norge, da man kan komme i situationer, hvor vinterdæk ikke er nok, og da vil lovgivningen kræve, at man benytter snekæder.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><img src="images/Tyskland.gif" alt="Tyskland" width="165" height="99" /></td>\r\n<td>\r\n<h2><strong>Tyskland - Vinterdæk regler Tyskland</strong> </h2>\r\n<p> </p>\r\n<h3>Vinterdæk</h3>\r\n<p>Ifølge loven skal biler i Tyskland være udstyret med vinterdæk, når der er sne, snesjap, frost eller is på vejene. Dækkene skal være vinterdæk mærket med M+S og et snefnugssymbol eller være helårsdæk mærket M+S. Derudover skal man sørge for, at sprinklervæsken er med antifrost. Er bilen ikke udstyret med dæk, der passer til vejrforholdene, kan man få en bøde på 40 euro. Hindrer bilen trafikken, fordi den ikke er udstyret med de rigtige dæk, kan bøden være 80 euro. Der er ikke særskilt krav om vinterdæk på anhængere, men det anbefales.</p>\r\n<p> </p>\r\n<h3>Pigdæk</h3>\r\n<p>Det er ikke tilladt at køre med pigdæk i Tyskland.</p>\r\n<h3>Snekæder</h3>\r\n<p>Det er tilladt at benytte snekæder. I så fald er der en fartgrænse på 50 km/t. I bjergområder vil der i vintervejr være skilte, hvis snekæder er påkrævet.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td><img src="images/oestrig.gif" alt="oestrig" width="166" height="111" /></td>\r\n<td>\r\n<h2><strong>Østrig - Vinterdæk regler Østrig</strong></h2>\r\n<p> </p>\r\n<h3>Vinterdæk</h3>\r\n<p>Fra den 1. november til den 15. april skal der være vinterdæk på bilen, når det er vinterføre. Det vil sige, når vejene er dækket af sne, slud eller is. Vinterdækkene skal monteres på alle 4 hjul, og de skal være mærket med M+S og have en dybde på minimum 4 mm. Kørsel med sommerdæk kan dog accepteres, såfremt man har monteret snekæder på de trækkende hjul. I så fald er den anbefalede makshastighed 50 km/t. Det er i øvrigt førerens ansvar, at bilen er udstyret med det nødvendige vinterudstyr. Hvis man lejer en bil, skal man derfor selv huske at tjekke, om det påkrævede vinterudstyr forefindes.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Pigdæk er tilladt fra 1. oktober til 31. maj, dog kun på køretøjer op til 3.500 kg. Der skal i så fald være pigdæk på alle 4 hjul samt på en evt. anhænger. Maks. hastighed med pigdæk er på motorvej 100 km/t og på landevej 80 km/t.<br />Når man kører med pigdæk, skal der desuden i bagruden påsættes en "pigdæksmærkat". Denne kan købes hos FDMs søsterklub <a class="  " href="http://www.oeamtc.at/" target="_blank">ÖAMTC</a>, på tankstationer mv.</p>\r\n<h3>Snekæder</h3>\r\n<p>Snekæder er tilladt i Østrig. Kører man med snekæder, er den anbefalede maksimumhastighed 50 km/t. Kæder skal have godkendelsen ÖNORM V 5117 for mindre køretøjer og ÖNORM V 5119 for større køretøjer.            </p>\r\n<p>Man kan købe eller låne snekæder på <a class="  " href="http://www.oeamtc.at/" target="_blank">ÖAMTCs</a> kontorer, eller man man leje dem ved alle større grænseovergange.</p>\r\n<p> </p>\r\n<h3>Specielt for tunge køretøjer</h3>\r\n<p>Fra 15. november til 15. marts skal alle køretøjer over 3500 kg køre med vinterdæk på mindst en af køreakslerne og medbringe snekæder - uanset om der er sne på vejen eller ej. Vinterdækkene skal være mærket M+S, og radialdæk skal være mindst 5 mm dybe, mens diagonaldæk skal være mindst 6 mm dybe. Det er obligatorisk at køre med snekæder, når skiltningen indikerer det.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><img src="images/schweiz.gif" alt="schweiz" width="165" height="165" /></td>\r\n<td>\r\n<h2><strong>Schweiz - Vinterdæk regler Schweiz</strong></h2>\r\n<p> </p>\r\n<h3>Vinterdæk</h3>\r\n<p>Vinterdæk er ikke påbudt, men køretøjer, der ikke er udrustet til at køre i vintervejr, kan idømmes bøder. I praksis betyder det, at man skal køre med vinterdæk og medbringe snekæder.</p>\r\n<p> </p>\r\n<h3>Pigdæk</h3>\r\n<p>Pigdæk er tilladt i perioden fra 1. november til 30. april på køretøjer under 7500 kg samt på evt. anhængere. Piggene på maks være 1,5 mm. Det er dog forbudt at køre med pigdæk på motor- og motortrafikveje med undtagelse af San Bernardino- og St. Gotthard-vejtunnelerne, hvor pigdæk er tilladt. Køretøjer med pigdæk må maks køre 80 km/t, hvilket skal angives på bilen i form af et fartklistermærke.</p>\r\n<h3>Snekæder</h3>\r\n<p>Snekæder er obligatoriske i områder, hvor der er skiltet med det. Snekæder monteres som minimum på de trækkende hjul.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td><img src="images/frankrig.gif" alt="frankrig" width="165" height="110" /></td>\r\n<td>\r\n<h2><strong>Frankrig - Vinterdæk regler Frankrig</strong></h2>\r\n<p> </p>\r\n<h3>Vinterdæk</h3>\r\n<p>Det er ikke obligatorisk at køre med vinterdæk i Frankrig, men det anbefales, når der er sne eller is på vejene. Dækmønsteret skal minimum være 3,5 mm.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Brugen af pigdæk er tilladt fra lørdagen før 1. november til den sidste søndag i marts på biler under 3500 kg samt kommercielle passagerkøretøjer. Max hastighed ved kørsel med pigdæk er 90 km/t. Hvis vejrforholdene kræver det, kan myndighederne udvide perioden for brug af pigdæk.</p>\r\n<h3>Snekæder</h3>\r\n<p>Snekæder skal benyttes, når skiltningen indikerer det. Der kan udstedes bøde, hvis man ikke overholder dette. Køretøjer med snekæder må ikke køre hurtigere end 50 km/t.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><img src="images/italie.gif" alt="italie" width="164" height="110" /></td>\r\n<td>\r\n<h2><strong>Italien - Vinterdæk regler Italien</strong></h2>\r\n<p> </p>\r\n<h3>Vinterdæk</h3>\r\n<p>I Aostadalen skal bilen være udstyret med vinterdæk, eller man skal medbringe snekæder i perioden 15/10 til 15/4.</p>\r\n<h3>Pigdæk</h3>\r\n<p>Pigdæk er tilladt fra 15/11 til 15/3 for køretøjer under 3500 kg. Makshastighed på motorvej er 120 km/t, på landevej 90 km/t. Kører man med pigdæk skal alle køretøjets hjul være udstyret med pigdæk - også en evt. anhænger. Desuden anbefales stænklapper.</p>\r\n<h3>Snekæder</h3>\r\n<p>Ved skiltning omkring snekæder accepteres både kørsel med snekæder og med vinterdæk. Biler udstyret med snekæder må maks køre 50 km/t.</p>\r\n<h3> </h3>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '', 1, 2, '2015-05-12 15:27:55', 401, '', '2015-05-12 15:29:07', 401, 0, '0000-00-00 00:00:00', '2015-05-12 15:27:55', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 3, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(9, 66, 'Bliv forhandler', 'bliv-forhandler', '<h1>VI HAR ET PAR SPØRGSMÅL DER KAN ÆNDRE DIN BUTIK...</h1>\r\n<ul>\r\n<li>Sælger du dæk, men kunne du tænke dig at sælge mange dæk ?</li>\r\n<li>Og kunne du tænke dig et system, som gør det nemt, enkelt og ensartet hver gang ?</li>\r\n<li>Vil du have adgang til en af Danmarks største dæk leverandører med mere end 40 dækmærker ? se alle mærker <a href="../index.php?option=com_content&amp;view=category&amp;layout=daek-faelge&amp;id=11&amp;Itemid=27">HER</a></li>\r\n<li>Og samtidig blive synlig for dine kunder ?</li>\r\n<li>Intet gebyr, ingen binding, ingen risiko.</li>\r\n<li>Kick Back på dit års køb</li>\r\n</ul>\r\n<h2>Noget af det vi tit hører i dækbranchen er:</h2>\r\n<ul>\r\n<li>Vi skal altid regne tilbud ud til kunder... – DET TAGER TID!!!!</li>\r\n<li>Vores kunder kan ikke se hvilke dæk mærker vi har på lager...</li>\r\n<li>For at få en god rabat, skal vi købe et stort dæk lager hjem... Kapital binding!!!!</li>\r\n<li>Vi har ikke plads til et dæk lager...</li>\r\n<li>Vi har ikke tid til at lave en lagerstyring, og vedligeholde den...</li>\r\n<li>Vi er ikke synlige som dækcenter...</li>\r\n<li>Er vi med i en dækkæde, skal andre bestemme vores pris...</li>\r\n</ul>\r\n<p>Kunne du tænke dig at blive DÆKCENTER, med de fordele vi kan tilbyde, og helt selv kunne bestemme over dit ”DÆKCENTER” ?</p>\r\n<p>Vel og mærke uden at skulle bruge penge på opstart, køb af system, bruge tid på vedligeholdelse – blot bruge kræfterne på at sælge dæk, og derved få nye og flere kunder i butikken ?</p>\r\n<p>Hvis du siger ja til dette, så er DÆKCENTER noget for dig! Kontakt os på <a href="mailto:info@daekcenter.nu">info@daekcenter.nu</a></p>', '', 1, 2, '2015-05-12 17:17:46', 401, '', '2015-05-12 17:17:46', 0, 0, '0000-00-00 00:00:00', '2015-05-12 17:17:46', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 2, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(10, 67, 'FÅ KREDIT - RENTEFRIT', 'fa-kredit-rentefrit', '<img class="mt20" src="images/Dækcenter_kort.jpg" alt="" width="667" height="422" />\r\n<h3>MED ET DÆKCENTER KORT HAR DU ALTID LØBENDE MÅNED +30 DAGES OMKOSTNINGSFRI KREDIT OG MULIGHED FOR OP TIL 12 MÅNEDERS RENTEFRI KREDIT</h3>\r\n<h4>TILBUD FRA 7/4 - 31/5 - KØB NU OG BETAL 1. SEPTEMBER 2015 - SEND PENGEPUNGEN PÅ FERIE OG VENT MED AT BETALE DIN REGNING - SØG ONLINE</h4>\r\n<p>DÆKCENTER tilbyder - i samarbejde med Resurs Bank - muligheden for et DÆKCENTER KORT - SOM KAN BRUGES TIL ALT - DÆK-FÆLGE-SERVICE-REPARATION MM</p>\r\n<p>DÆKCENTER KORT er et fleksibelt alternativ til dig, som selv ønsker at bestemme, hvordan du vil betale. Med DÆKCENTER KORT har du altid løbende måned + 30 dages kredit på dine køb, og først derefter beslutter du dig for, hvorvidt du ønsker at indbetale hele saldoen eller om du vil dele betalingen yderligere op. Med valg af løbetid op til 12 måneder tilskrives der ingen renter. Dine muligheder for betaling oplyses sammen med det første indbetalingskort, som du modtager måneden efter dit køb. Vælger du at indbetale hele beløbet, tillægges der ingen renter eller gebyrer.</p>\r\n<a class="btn btnCredit" href="https://apponline.resurs.com/form/dk29500" target="_blank">SØG RENTEFRI KREDIT</a> <a class="btn btnCredit" href="https://secure.resurs.se/priceinfo/prisskyltning.html?countryCode=DK&amp;representativeId=29500&amp;authorizedBankproductId=DC155069&amp;creditAmount=10000" target="_blank">Beregn hvad det koster</a>\r\n<p class="mt20">I tabellen herunder kan du se eksempler på, hvad de månedlige omkostninger bliver med forskellige betalingsperioder. Den månedlige mindstebetaling skal dog minimum altid udgøre kr. 150,00</p>\r\n<div class="table-responsive">\r\n<table class="table table-bordered table3">\r\n<tbody>\r\n<tr>\r\n<td>Omkostninger</td>\r\n<td>Løbende md.<br /><br />+ 1 md.</td>\r\n<td>6 mdr.</td>\r\n<td>12 mdr.</td>\r\n<td>24 mdr.</td>\r\n<td>36 mdr.</td>\r\n<td>48 mdr.</td>\r\n</tr>\r\n<tr>\r\n<td>Debitorrente</td>\r\n<td>0 %</td>\r\n<td>0 %</td>\r\n<td>0 %</td>\r\n<td>9,96 %</td>\r\n<td>12,96 %</td>\r\n<td>16,96 %</td>\r\n</tr>\r\n<tr>\r\n<td>Adm. afgift/md</td>\r\n<td>Kr. 0,00</td>\r\n<td>Kr. 35,00</td>\r\n<td>Kr. 35,00</td>\r\n<td>Kr. 35,00</td>\r\n<td>Kr. 35,00</td>\r\n<td>Kr. 35,00</td>\r\n</tr>\r\n<tr>\r\n<td>Oprettelse</td>\r\n<td>Kr. 0,00</td>\r\n<td>Kr. 195,00</td>\r\n<td>Kr. 395,00</td>\r\n<td>Kr. 395,00</td>\r\n<td>Kr. 395,00</td>\r\n<td>Kr. 395,00</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n<p>Kreditramme kr. 1.000 - kr. 40.000<br /> Evt. oprettelsesgebyr tilskrives saldoen i måned 2 efter valg af betalingsperiode.</p>\r\n<p>Repræsentativt eksempel<br /> Kreditbeløb: kr. 15 000,-<br /> Kredittid og afdragsperiode: 24 mdr.</p>\r\n<div class="table-responsive">\r\n<table class="table table3 table-bordered">\r\n<thead>\r\n<tr><th>Debitorrente</th><th>Samlet kreditbeløb</th><th>ÅOP</th><th>Kreditomkostninger</th><th>Månedlig ydelse</th><th>Totalbeløb.</th></tr>\r\n</thead>\r\n<tbody>\r\n<tr>\r\n<td>9,96 %</td>\r\n<td>Kr. 15.000</td>\r\n<td>17,2 %</td>\r\n<td>Kr. 2.724</td>\r\n<td>Kr. 745</td>\r\n<td>Kr. 17.724</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n<p>Spørgsmål vedr. finansiering?<br /> Kontakt Resurs Banks kundeservice på telefon 33 32 43 60 eller <a href="mailto:kundservice@resurs.dk">kundservice@resurs.dk</a><br /> Standardiserede europæiske forbrugerkreditoplysning (SEF), tryk <a class="underline" href="https://documenthandler.resurs.com/Dokument.pdf?kedja=29500&amp;land=DK&amp;language=da&amp;bankprodukt=DC155069">her</a><br /> Almindelige kontobetingelser, tryk <a class="underline" href="https://secure.resurs.se/documenthandler/Dokument.pdf?customerType=natural&amp;docType=commonTerms&amp;land=DK&amp;language=da">her</a></p>', '', 1, 2, '2015-05-12 17:24:36', 401, '', '2015-05-12 17:25:48', 401, 0, '0000-00-00 00:00:00', '2015-05-12 17:24:36', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 1, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(11, 70, 'Aalestrup', 'aalestrup', '<h3>3S Biler</h3>\r\n<p>Elmegårdsvej 1 <br />9620 Aalestrup<br /> Tlf. 98 64 23 33<br /> <a href="http://www.3s-biler.dk/">www.3s-biler.dk/</a></p>\r\n', 'Åbningstider:\r\n<p>Mandag - torsdag: 8.00 - 16.30 <br />Fredag: 8.00 - 14.45</p>', 1, 9, '2015-05-12 17:43:31', 401, '', '2015-05-12 17:48:27', 401, 0, '0000-00-00 00:00:00', '2015-05-12 17:43:31', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 0, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_contentitem_tag_map`
--

CREATE TABLE IF NOT EXISTS `g2q6h_contentitem_tag_map` (
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table',
  UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  KEY `idx_tag_type` (`tag_id`,`type_id`),
  KEY `idx_date_id` (`tag_date`,`tag_id`),
  KEY `idx_tag` (`tag_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_core_content_id` (`core_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maps items from content tables to tags';

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `g2q6h_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_content_rating`
--

CREATE TABLE IF NOT EXISTS `g2q6h_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_content_types`
--

CREATE TABLE IF NOT EXISTS `g2q6h_content_types` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `table` varchar(255) NOT NULL DEFAULT '',
  `rules` text NOT NULL,
  `field_mappings` text NOT NULL,
  `router` varchar(255) NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) DEFAULT NULL COMMENT 'JSON string for com_contenthistory options',
  PRIMARY KEY (`type_id`),
  KEY `idx_alias` (`type_alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `g2q6h_content_types`
--

INSERT INTO `g2q6h_content_types` (`type_id`, `type_title`, `type_alias`, `table`, `rules`, `field_mappings`, `router`, `content_history_options`) VALUES
(1, 'Article', 'com_content.article', '{"special":{"dbtable":"#__content","key":"id","type":"Content","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"state","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"introtext", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"attribs", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"asset_id"}, "special":{"fulltext":"fulltext"}}', 'ContentHelperRoute::getArticleRoute', '{"formFile":"administrator\\/components\\/com_content\\/models\\/forms\\/article.xml", "hideFields":["asset_id","checked_out","checked_out_time","version"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(2, 'Contact', 'com_contact.contact', '{"special":{"dbtable":"#__contact_details","key":"id","type":"Contact","prefix":"ContactTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"address", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"image", "core_urls":"webpage", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{"con_position":"con_position","suburb":"suburb","state":"state","country":"country","postcode":"postcode","telephone":"telephone","fax":"fax","misc":"misc","email_to":"email_to","default_con":"default_con","user_id":"user_id","mobile":"mobile","sortname1":"sortname1","sortname2":"sortname2","sortname3":"sortname3"}}', 'ContactHelperRoute::getContactRoute', '{"formFile":"administrator\\/components\\/com_contact\\/models\\/forms\\/contact.xml","hideFields":["default_con","checked_out","checked_out_time","version","xreference"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"], "displayLookup":[ {"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ] }'),
(3, 'Newsfeed', 'com_newsfeeds.newsfeed', '{"special":{"dbtable":"#__newsfeeds","key":"id","type":"Newsfeed","prefix":"NewsfeedsTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{"numarticles":"numarticles","cache_time":"cache_time","rtl":"rtl"}}', 'NewsfeedsHelperRoute::getNewsfeedRoute', '{"formFile":"administrator\\/components\\/com_newsfeeds\\/models\\/forms\\/newsfeed.xml","hideFields":["asset_id","checked_out","checked_out_time","version"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(4, 'User', 'com_users.user', '{"special":{"dbtable":"#__users","key":"id","type":"User","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"null","core_alias":"username","core_created_time":"registerdate","core_modified_time":"lastvisitDate","core_body":"null", "core_hits":"null","core_publish_up":"null","core_publish_down":"null","access":"null", "core_params":"params", "core_featured":"null", "core_metadata":"null", "core_language":"null", "core_images":"null", "core_urls":"null", "core_version":"null", "core_ordering":"null", "core_metakey":"null", "core_metadesc":"null", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}, "special":{}}', 'UsersHelperRoute::getUserRoute', ''),
(5, 'Article Category', 'com_content.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'ContentHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(6, 'Contact Category', 'com_contact.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'ContactHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(7, 'Newsfeeds Category', 'com_newsfeeds.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'NewsfeedsHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(8, 'Tag', 'com_tags.tag', '{"special":{"dbtable":"#__tags","key":"tag_id","type":"Tag","prefix":"TagsTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path"}}', 'TagsHelperRoute::getTagRoute', '{"formFile":"administrator\\/components\\/com_tags\\/models\\/forms\\/tag.xml", "hideFields":["checked_out","checked_out_time","version", "lft", "rgt", "level", "path", "urls", "publish_up", "publish_down"],"ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}'),
(9, 'Banner', 'com_banners.banner', '{"special":{"dbtable":"#__banners","key":"id","type":"Banner","prefix":"BannersTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"null","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"null", "asset_id":"null"}, "special":{"imptotal":"imptotal", "impmade":"impmade", "clicks":"clicks", "clickurl":"clickurl", "custombannercode":"custombannercode", "cid":"cid", "purchase_type":"purchase_type", "track_impressions":"track_impressions", "track_clicks":"track_clicks"}}', '', '{"formFile":"administrator\\/components\\/com_banners\\/models\\/forms\\/banner.xml", "hideFields":["checked_out","checked_out_time","version", "reset"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "imptotal", "impmade", "reset"], "convertToInt":["publish_up", "publish_down", "ordering"], "displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"cid","targetTable":"#__banner_clients","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(10, 'Banners Category', 'com_banners.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special": {"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', '', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(11, 'Banner Client', 'com_banners.client', '{"special":{"dbtable":"#__banner_clients","key":"id","type":"Client","prefix":"BannersTable"}}', '', '', '', '{"formFile":"administrator\\/components\\/com_banners\\/models\\/forms\\/client.xml", "hideFields":["checked_out","checked_out_time"], "ignoreChanges":["checked_out", "checked_out_time"], "convertToInt":[], "displayLookup":[]}'),
(12, 'User Notes', 'com_users.note', '{"special":{"dbtable":"#__user_notes","key":"id","type":"Note","prefix":"UsersTable"}}', '', '', '', '{"formFile":"administrator\\/components\\/com_users\\/models\\/forms\\/note.xml", "hideFields":["checked_out","checked_out_time", "publish_up", "publish_down"],"ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time"], "convertToInt":["publish_up", "publish_down"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}'),
(13, 'User Notes Category', 'com_users.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', '', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `g2q6h_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_extensions`
--

CREATE TABLE IF NOT EXISTS `g2q6h_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10014 ;

--
-- Dumping data for table `g2q6h_extensions`
--

INSERT INTO `g2q6h_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(1, 'com_mailto', 'component', 'com_mailto', '', 0, 1, 1, 1, '{"name":"com_mailto","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MAILTO_XML_DESCRIPTION","group":"","filename":"mailto"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(2, 'com_wrapper', 'component', 'com_wrapper', '', 0, 1, 1, 1, '{"name":"com_wrapper","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_WRAPPER_XML_DESCRIPTION","group":"","filename":"wrapper"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(3, 'com_admin', 'component', 'com_admin', '', 1, 1, 1, 1, '{"name":"com_admin","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_ADMIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(4, 'com_banners', 'component', 'com_banners', '', 1, 1, 1, 0, '{"name":"com_banners","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_BANNERS_XML_DESCRIPTION","group":"","filename":"banners"}', '{"purchase_type":"3","track_impressions":"0","track_clicks":"0","metakey_prefix":"","save_history":"1","history_limit":10}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(5, 'com_cache', 'component', 'com_cache', '', 1, 1, 1, 1, '{"name":"com_cache","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CACHE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(6, 'com_categories', 'component', 'com_categories', '', 1, 1, 1, 1, '{"name":"com_categories","type":"component","creationDate":"December 2007","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(7, 'com_checkin', 'component', 'com_checkin', '', 1, 1, 1, 1, '{"name":"com_checkin","type":"component","creationDate":"Unknown","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CHECKIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(8, 'com_contact', 'component', 'com_contact', '', 1, 1, 1, 0, '{"name":"com_contact","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONTACT_XML_DESCRIPTION","group":"","filename":"contact"}', '{"show_contact_category":"hide","save_history":"1","history_limit":10,"show_contact_list":"0","presentation_style":"sliders","show_name":"1","show_position":"1","show_email":"0","show_street_address":"1","show_suburb":"1","show_state":"1","show_postcode":"1","show_country":"1","show_telephone":"1","show_mobile":"1","show_fax":"1","show_webpage":"1","show_misc":"1","show_image":"1","image":"","allow_vcard":"0","show_articles":"0","show_profile":"0","show_links":"0","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","contact_icons":"0","icon_address":"","icon_email":"","icon_telephone":"","icon_mobile":"","icon_fax":"","icon_misc":"","show_headings":"1","show_position_headings":"1","show_email_headings":"0","show_telephone_headings":"1","show_mobile_headings":"0","show_fax_headings":"0","allow_vcard_headings":"0","show_suburb_headings":"1","show_state_headings":"1","show_country_headings":"1","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"1","custom_reply":"0","redirect":"","show_category_crumb":"0","metakey":"","metadesc":"","robots":"","author":"","rights":"","xreference":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(9, 'com_cpanel', 'component', 'com_cpanel', '', 1, 1, 1, 1, '{"name":"com_cpanel","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CPANEL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10, 'com_installer', 'component', 'com_installer', '', 1, 1, 1, 1, '{"name":"com_installer","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_INSTALLER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(11, 'com_languages', 'component', 'com_languages', '', 1, 1, 1, 1, '{"name":"com_languages","type":"component","creationDate":"2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_LANGUAGES_XML_DESCRIPTION","group":""}', '{"administrator":"en-GB","site":"en-GB"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(12, 'com_login', 'component', 'com_login', '', 1, 1, 1, 1, '{"name":"com_login","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(13, 'com_media', 'component', 'com_media', '', 1, 1, 0, 1, '{"name":"com_media","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MEDIA_XML_DESCRIPTION","group":"","filename":"media"}', '{"upload_extensions":"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS","upload_maxsize":"10","file_path":"images","image_path":"images","restrict_uploads":"1","allowed_media_usergroup":"3","check_mime":"1","image_extensions":"bmp,gif,jpg,png","ignore_extensions":"","upload_mime":"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip","upload_mime_illegal":"text\\/html"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(14, 'com_menus', 'component', 'com_menus', '', 1, 1, 1, 1, '{"name":"com_menus","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MENUS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(15, 'com_messages', 'component', 'com_messages', '', 1, 1, 1, 1, '{"name":"com_messages","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MESSAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(16, 'com_modules', 'component', 'com_modules', '', 1, 1, 1, 1, '{"name":"com_modules","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MODULES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(17, 'com_newsfeeds', 'component', 'com_newsfeeds', '', 1, 1, 1, 0, '{"name":"com_newsfeeds","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_NEWSFEEDS_XML_DESCRIPTION","group":"","filename":"newsfeeds"}', '{"newsfeed_layout":"_:default","save_history":"1","history_limit":5,"show_feed_image":"1","show_feed_description":"1","show_item_description":"1","feed_character_count":"0","feed_display_order":"des","float_first":"right","float_second":"right","show_tags":"1","category_layout":"_:default","show_category_title":"1","show_description":"1","show_description_image":"1","maxLevel":"-1","show_empty_categories":"0","show_subcat_desc":"1","show_cat_items":"1","show_cat_tags":"1","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_items_cat":"1","filter_field":"1","show_pagination_limit":"1","show_headings":"1","show_articles":"0","show_link":"1","show_pagination":"1","show_pagination_results":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(18, 'com_plugins', 'component', 'com_plugins', '', 1, 1, 1, 1, '{"name":"com_plugins","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_PLUGINS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(19, 'com_search', 'component', 'com_search', '', 1, 1, 1, 0, '{"name":"com_search","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_SEARCH_XML_DESCRIPTION","group":"","filename":"search"}', '{"enabled":"0","show_date":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(20, 'com_templates', 'component', 'com_templates', '', 1, 1, 1, 1, '{"name":"com_templates","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_TEMPLATES_XML_DESCRIPTION","group":""}', '{"template_positions_display":"0","upload_limit":"2","image_formats":"gif,bmp,jpg,jpeg,png","source_formats":"txt,less,ini,xml,js,php,css","font_formats":"woff,ttf,otf","compressed_formats":"zip"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(22, 'com_content', 'component', 'com_content', '', 1, 1, 0, 1, '{"name":"com_content","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONTENT_XML_DESCRIPTION","group":"","filename":"content"}', '{"article_layout":"_:default","show_title":"1","link_titles":"1","show_intro":"1","show_category":"1","link_category":"1","show_parent_category":"0","link_parent_category":"0","show_author":"1","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"1","show_item_navigation":"1","show_vote":"0","show_readmore":"1","show_readmore_title":"1","readmore_limit":"100","show_icons":"1","show_print_icon":"1","show_email_icon":"1","show_hits":"1","show_noauth":"0","show_publishing_options":"1","show_article_options":"1","save_history":"1","history_limit":10,"show_urls_images_frontend":"0","show_urls_images_backend":"1","targeta":0,"targetb":0,"targetc":0,"float_intro":"left","float_fulltext":"left","category_layout":"_:blog","show_category_title":"0","show_description":"0","show_description_image":"0","maxLevel":"1","show_empty_categories":"0","show_no_articles":"1","show_subcat_desc":"1","show_cat_num_articles":"0","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_articles_cat":"1","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"0","show_subcategory_content":"0","show_pagination_limit":"1","filter_field":"hide","show_headings":"1","list_show_date":"0","date_format":"","list_show_hits":"1","list_show_author":"1","orderby_pri":"order","orderby_sec":"rdate","order_date":"published","show_pagination":"2","show_pagination_results":"1","show_feed_link":"1","feed_summary":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(23, 'com_config', 'component', 'com_config', '', 1, 1, 0, 1, '{"name":"com_config","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONFIG_XML_DESCRIPTION","group":""}', '{"filters":{"1":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"9":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"6":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"7":{"filter_type":"NONE","filter_tags":"","filter_attributes":""},"2":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"3":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"4":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"5":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"8":{"filter_type":"NONE","filter_tags":"","filter_attributes":""}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(24, 'com_redirect', 'component', 'com_redirect', '', 1, 1, 0, 1, '{"name":"com_redirect","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_REDIRECT_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(25, 'com_users', 'component', 'com_users', '', 1, 1, 0, 1, '{"name":"com_users","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_USERS_XML_DESCRIPTION","group":"","filename":"users"}', '{"allowUserRegistration":"0","new_usertype":"2","guest_usergroup":"9","sendpassword":"1","useractivation":"1","mail_to_admin":"0","captcha":"","frontend_userparams":"1","site_language":"0","change_login_name":"0","reset_count":"10","reset_time":"1","minimum_length":"4","minimum_integers":"0","minimum_symbols":"0","minimum_uppercase":"0","save_history":"1","history_limit":5,"mailSubjectPrefix":"","mailBodySuffix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(27, 'com_finder', 'component', 'com_finder', '', 1, 1, 0, 0, '{"name":"com_finder","type":"component","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_FINDER_XML_DESCRIPTION","group":"","filename":"finder"}', '{"show_description":"1","description_length":255,"allow_empty_query":"0","show_url":"1","show_advanced":"1","expand_advanced":"0","show_date_filters":"0","highlight_terms":"1","opensearch_name":"","opensearch_description":"","batch_size":"50","memory_table_limit":30000,"title_multiplier":"1.7","text_multiplier":"0.7","meta_multiplier":"1.2","path_multiplier":"2.0","misc_multiplier":"0.3","stemmer":"snowball"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(28, 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', 1, 1, 0, 1, '{"name":"com_joomlaupdate","type":"component","creationDate":"February 2012","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(29, 'com_tags', 'component', 'com_tags', '', 1, 1, 1, 1, '{"name":"com_tags","type":"component","creationDate":"December 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"COM_TAGS_XML_DESCRIPTION","group":"","filename":"tags"}', '{"tag_layout":"_:default","save_history":"1","history_limit":5,"show_tag_title":"0","tag_list_show_tag_image":"0","tag_list_show_tag_description":"0","tag_list_image":"","show_tag_num_items":"0","tag_list_orderby":"title","tag_list_orderby_direction":"ASC","show_headings":"0","tag_list_show_date":"0","tag_list_show_item_image":"0","tag_list_show_item_description":"0","tag_list_item_maximum_characters":0,"return_any_or_all":"1","include_children":"0","maximum":200,"tag_list_language_filter":"all","tags_layout":"_:default","all_tags_orderby":"title","all_tags_orderby_direction":"ASC","all_tags_show_tag_image":"0","all_tags_show_tag_descripion":"0","all_tags_tag_maximum_characters":20,"all_tags_show_tag_hits":"0","filter_field":"1","show_pagination_limit":"1","show_pagination":"2","show_pagination_results":"1","tag_field_ajax_mode":"1","show_feed_link":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(30, 'com_contenthistory', 'component', 'com_contenthistory', '', 1, 1, 1, 0, '{"name":"com_contenthistory","type":"component","creationDate":"May 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_CONTENTHISTORY_XML_DESCRIPTION","group":"","filename":"contenthistory"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(31, 'com_ajax', 'component', 'com_ajax', '', 1, 1, 1, 0, '{"name":"com_ajax","type":"component","creationDate":"August 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_AJAX_XML_DESCRIPTION","group":"","filename":"ajax"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(32, 'com_postinstall', 'component', 'com_postinstall', '', 1, 1, 1, 1, '{"name":"com_postinstall","type":"component","creationDate":"September 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_POSTINSTALL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(101, 'SimplePie', 'library', 'simplepie', '', 0, 1, 1, 1, '{"name":"SimplePie","type":"library","creationDate":"2004","author":"SimplePie","copyright":"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon","authorEmail":"","authorUrl":"http:\\/\\/simplepie.org\\/","version":"1.2","description":"LIB_SIMPLEPIE_XML_DESCRIPTION","group":"","filename":"simplepie"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(102, 'phputf8', 'library', 'phputf8', '', 0, 1, 1, 1, '{"name":"phputf8","type":"library","creationDate":"2006","author":"Harry Fuecks","copyright":"Copyright various authors","authorEmail":"hfuecks@gmail.com","authorUrl":"http:\\/\\/sourceforge.net\\/projects\\/phputf8","version":"0.5","description":"LIB_PHPUTF8_XML_DESCRIPTION","group":"","filename":"phputf8"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(103, 'Joomla! Platform', 'library', 'joomla', '', 0, 1, 1, 1, '{"name":"Joomla! Platform","type":"library","creationDate":"2008","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"13.1","description":"LIB_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '{"mediaversion":"539274d362edb751499c0325223fea22"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(104, 'IDNA Convert', 'library', 'idna_convert', '', 0, 1, 1, 1, '{"name":"IDNA Convert","type":"library","creationDate":"2004","author":"phlyLabs","copyright":"2004-2011 phlyLabs Berlin, http:\\/\\/phlylabs.de","authorEmail":"phlymail@phlylabs.de","authorUrl":"http:\\/\\/phlylabs.de","version":"0.8.0","description":"LIB_IDNA_XML_DESCRIPTION","group":"","filename":"idna_convert"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(105, 'FOF', 'library', 'fof', '', 0, 1, 1, 1, '{"name":"FOF","type":"library","creationDate":"2015-03-11 11:59:00","author":"Nicholas K. Dionysopoulos \\/ Akeeba Ltd","copyright":"(C)2011-2015 Nicholas K. Dionysopoulos","authorEmail":"nicholas@akeebabackup.com","authorUrl":"https:\\/\\/www.akeebabackup.com","version":"2.4.2","description":"LIB_FOF_XML_DESCRIPTION","group":"","filename":"fof"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(106, 'PHPass', 'library', 'phpass', '', 0, 1, 1, 1, '{"name":"PHPass","type":"library","creationDate":"2004-2006","author":"Solar Designer","copyright":"","authorEmail":"solar@openwall.com","authorUrl":"http:\\/\\/www.openwall.com\\/phpass\\/","version":"0.3","description":"LIB_PHPASS_XML_DESCRIPTION","group":"","filename":"phpass"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(200, 'mod_articles_archive', 'module', 'mod_articles_archive', '', 0, 1, 1, 0, '{"name":"mod_articles_archive","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION","group":"","filename":"mod_articles_archive"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(201, 'mod_articles_latest', 'module', 'mod_articles_latest', '', 0, 1, 1, 0, '{"name":"mod_articles_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LATEST_NEWS_XML_DESCRIPTION","group":"","filename":"mod_articles_latest"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(202, 'mod_articles_popular', 'module', 'mod_articles_popular', '', 0, 1, 1, 0, '{"name":"mod_articles_popular","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":"","filename":"mod_articles_popular"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(203, 'mod_banners', 'module', 'mod_banners', '', 0, 1, 1, 0, '{"name":"mod_banners","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_BANNERS_XML_DESCRIPTION","group":"","filename":"mod_banners"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(204, 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', 0, 1, 1, 1, '{"name":"mod_breadcrumbs","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_BREADCRUMBS_XML_DESCRIPTION","group":"","filename":"mod_breadcrumbs"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(205, 'mod_custom', 'module', 'mod_custom', '', 0, 1, 1, 1, '{"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":"","filename":"mod_custom"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(206, 'mod_feed', 'module', 'mod_feed', '', 0, 1, 1, 0, '{"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FEED_XML_DESCRIPTION","group":"","filename":"mod_feed"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(207, 'mod_footer', 'module', 'mod_footer', '', 0, 1, 1, 0, '{"name":"mod_footer","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FOOTER_XML_DESCRIPTION","group":"","filename":"mod_footer"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(208, 'mod_login', 'module', 'mod_login', '', 0, 1, 1, 1, '{"name":"mod_login","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":"","filename":"mod_login"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(209, 'mod_menu', 'module', 'mod_menu', '', 0, 1, 1, 1, '{"name":"mod_menu","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MENU_XML_DESCRIPTION","group":"","filename":"mod_menu"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(210, 'mod_articles_news', 'module', 'mod_articles_news', '', 0, 1, 1, 0, '{"name":"mod_articles_news","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_NEWS_XML_DESCRIPTION","group":"","filename":"mod_articles_news"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(211, 'mod_random_image', 'module', 'mod_random_image', '', 0, 1, 1, 0, '{"name":"mod_random_image","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_RANDOM_IMAGE_XML_DESCRIPTION","group":"","filename":"mod_random_image"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(212, 'mod_related_items', 'module', 'mod_related_items', '', 0, 1, 1, 0, '{"name":"mod_related_items","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_RELATED_XML_DESCRIPTION","group":"","filename":"mod_related_items"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(213, 'mod_search', 'module', 'mod_search', '', 0, 1, 1, 0, '{"name":"mod_search","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SEARCH_XML_DESCRIPTION","group":"","filename":"mod_search"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(214, 'mod_stats', 'module', 'mod_stats', '', 0, 1, 1, 0, '{"name":"mod_stats","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":"","filename":"mod_stats"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(215, 'mod_syndicate', 'module', 'mod_syndicate', '', 0, 1, 1, 1, '{"name":"mod_syndicate","type":"module","creationDate":"May 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SYNDICATE_XML_DESCRIPTION","group":"","filename":"mod_syndicate"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(216, 'mod_users_latest', 'module', 'mod_users_latest', '', 0, 1, 1, 0, '{"name":"mod_users_latest","type":"module","creationDate":"December 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_USERS_LATEST_XML_DESCRIPTION","group":"","filename":"mod_users_latest"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(218, 'mod_whosonline', 'module', 'mod_whosonline', '', 0, 1, 1, 0, '{"name":"mod_whosonline","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WHOSONLINE_XML_DESCRIPTION","group":"","filename":"mod_whosonline"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(219, 'mod_wrapper', 'module', 'mod_wrapper', '', 0, 1, 1, 0, '{"name":"mod_wrapper","type":"module","creationDate":"October 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WRAPPER_XML_DESCRIPTION","group":"","filename":"mod_wrapper"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(220, 'mod_articles_category', 'module', 'mod_articles_category', '', 0, 1, 1, 0, '{"name":"mod_articles_category","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION","group":"","filename":"mod_articles_category"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(221, 'mod_articles_categories', 'module', 'mod_articles_categories', '', 0, 1, 1, 0, '{"name":"mod_articles_categories","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION","group":"","filename":"mod_articles_categories"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(222, 'mod_languages', 'module', 'mod_languages', '', 0, 1, 1, 1, '{"name":"mod_languages","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LANGUAGES_XML_DESCRIPTION","group":"","filename":"mod_languages"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(223, 'mod_finder', 'module', 'mod_finder', '', 0, 1, 0, 0, '{"name":"mod_finder","type":"module","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FINDER_XML_DESCRIPTION","group":"","filename":"mod_finder"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(300, 'mod_custom', 'module', 'mod_custom', '', 1, 1, 1, 1, '{"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":"","filename":"mod_custom"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(301, 'mod_feed', 'module', 'mod_feed', '', 1, 1, 1, 0, '{"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FEED_XML_DESCRIPTION","group":"","filename":"mod_feed"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(302, 'mod_latest', 'module', 'mod_latest', '', 1, 1, 1, 0, '{"name":"mod_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LATEST_XML_DESCRIPTION","group":"","filename":"mod_latest"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(303, 'mod_logged', 'module', 'mod_logged', '', 1, 1, 1, 0, '{"name":"mod_logged","type":"module","creationDate":"January 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGGED_XML_DESCRIPTION","group":"","filename":"mod_logged"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(304, 'mod_login', 'module', 'mod_login', '', 1, 1, 1, 1, '{"name":"mod_login","type":"module","creationDate":"March 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":"","filename":"mod_login"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(305, 'mod_menu', 'module', 'mod_menu', '', 1, 1, 1, 0, '{"name":"mod_menu","type":"module","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MENU_XML_DESCRIPTION","group":"","filename":"mod_menu"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(307, 'mod_popular', 'module', 'mod_popular', '', 1, 1, 1, 0, '{"name":"mod_popular","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":"","filename":"mod_popular"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(308, 'mod_quickicon', 'module', 'mod_quickicon', '', 1, 1, 1, 1, '{"name":"mod_quickicon","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_QUICKICON_XML_DESCRIPTION","group":"","filename":"mod_quickicon"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(309, 'mod_status', 'module', 'mod_status', '', 1, 1, 1, 0, '{"name":"mod_status","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATUS_XML_DESCRIPTION","group":"","filename":"mod_status"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(310, 'mod_submenu', 'module', 'mod_submenu', '', 1, 1, 1, 0, '{"name":"mod_submenu","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SUBMENU_XML_DESCRIPTION","group":"","filename":"mod_submenu"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(311, 'mod_title', 'module', 'mod_title', '', 1, 1, 1, 0, '{"name":"mod_title","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_TITLE_XML_DESCRIPTION","group":"","filename":"mod_title"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(312, 'mod_toolbar', 'module', 'mod_toolbar', '', 1, 1, 1, 1, '{"name":"mod_toolbar","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_TOOLBAR_XML_DESCRIPTION","group":"","filename":"mod_toolbar"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(313, 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', 1, 1, 1, 0, '{"name":"mod_multilangstatus","type":"module","creationDate":"September 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MULTILANGSTATUS_XML_DESCRIPTION","group":"","filename":"mod_multilangstatus"}', '{"cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(314, 'mod_version', 'module', 'mod_version', '', 1, 1, 1, 0, '{"name":"mod_version","type":"module","creationDate":"January 2012","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_VERSION_XML_DESCRIPTION","group":"","filename":"mod_version"}', '{"format":"short","product":"1","cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(315, 'mod_stats_admin', 'module', 'mod_stats_admin', '', 1, 1, 1, 0, '{"name":"mod_stats_admin","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":"","filename":"mod_stats_admin"}', '{"serverinfo":"0","siteinfo":"0","counter":"0","increase":"0","cache":"1","cache_time":"900","cachemode":"static"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(316, 'mod_tags_popular', 'module', 'mod_tags_popular', '', 0, 1, 1, 0, '{"name":"mod_tags_popular","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_POPULAR_XML_DESCRIPTION","group":"","filename":"mod_tags_popular"}', '{"maximum":"5","timeframe":"alltime","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(317, 'mod_tags_similar', 'module', 'mod_tags_similar', '', 0, 1, 1, 0, '{"name":"mod_tags_similar","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_SIMILAR_XML_DESCRIPTION","group":"","filename":"mod_tags_similar"}', '{"maximum":"5","matchtype":"any","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(400, 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', 0, 0, 1, 0, '{"name":"plg_authentication_gmail","type":"plugin","creationDate":"February 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_GMAIL_XML_DESCRIPTION","group":"","filename":"gmail"}', '{"applysuffix":"0","suffix":"","verifypeer":"1","user_blacklist":""}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(401, 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', 0, 1, 1, 1, '{"name":"plg_authentication_joomla","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_AUTH_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(402, 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', 0, 0, 1, 0, '{"name":"plg_authentication_ldap","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LDAP_XML_DESCRIPTION","group":"","filename":"ldap"}', '{"host":"","port":"389","use_ldapV3":"0","negotiate_tls":"0","no_referrals":"0","auth_method":"bind","base_dn":"","search_string":"","users_dn":"","username":"admin","password":"bobby7","ldap_fullname":"fullName","ldap_email":"mail","ldap_uid":"uid"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(403, 'plg_content_contact', 'plugin', 'contact', 'content', 0, 1, 1, 0, '{"name":"plg_content_contact","type":"plugin","creationDate":"January 2014","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.2","description":"PLG_CONTENT_CONTACT_XML_DESCRIPTION","group":"","filename":"contact"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(404, 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', 0, 1, 1, 0, '{"name":"plg_content_emailcloak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION","group":"","filename":"emailcloak"}', '{"mode":"1"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(406, 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', 0, 1, 1, 0, '{"name":"plg_content_loadmodule","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LOADMODULE_XML_DESCRIPTION","group":"","filename":"loadmodule"}', '{"style":"xhtml"}', '', '', 0, '2011-09-18 15:22:50', 0, 0),
(407, 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', 0, 1, 1, 0, '{"name":"plg_content_pagebreak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION","group":"","filename":"pagebreak"}', '{"title":"1","multipage_toc":"1","showall":"1"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(408, 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', 0, 1, 1, 0, '{"name":"plg_content_pagenavigation","type":"plugin","creationDate":"January 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_PAGENAVIGATION_XML_DESCRIPTION","group":"","filename":"pagenavigation"}', '{"position":"1"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(409, 'plg_content_vote', 'plugin', 'vote', 'content', 0, 1, 1, 0, '{"name":"plg_content_vote","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_VOTE_XML_DESCRIPTION","group":"","filename":"vote"}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(410, 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', 0, 1, 1, 1, '{"name":"plg_editors_codemirror","type":"plugin","creationDate":"28 March 2011","author":"Marijn Haverbeke","copyright":"Copyright (C) 2014 by Marijn Haverbeke <marijnh@gmail.com> and others","authorEmail":"marijnh@gmail.com","authorUrl":"http:\\/\\/codemirror.net\\/","version":"5.0","description":"PLG_CODEMIRROR_XML_DESCRIPTION","group":"","filename":"codemirror"}', '{"lineNumbers":"1","lineWrapping":"1","matchTags":"1","matchBrackets":"1","marker-gutter":"1","autoCloseTags":"1","autoCloseBrackets":"1","autoFocus":"1","theme":"default","tabmode":"indent"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(411, 'plg_editors_none', 'plugin', 'none', 'editors', 0, 1, 1, 1, '{"name":"plg_editors_none","type":"plugin","creationDate":"September 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_NONE_XML_DESCRIPTION","group":"","filename":"none"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(412, 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', 0, 1, 1, 0, '{"name":"plg_editors_tinymce","type":"plugin","creationDate":"2005-2014","author":"Moxiecode Systems AB","copyright":"Moxiecode Systems AB","authorEmail":"N\\/A","authorUrl":"tinymce.moxiecode.com","version":"4.1.7","description":"PLG_TINY_XML_DESCRIPTION","group":"","filename":"tinymce"}', '{"skin":"0","skin_admin":"0","mode":"1","mobile":"0","entity_encoding":"raw","lang_mode":"1","text_direction":"ltr","content_css":"1","content_css_custom":"","relative_urls":"1","newlines":"1","invalid_elements":"script,applet,iframe","valid_elements":"","extended_elements":"","html_height":"550","html_width":"750","resizing":"1","resize_horizontal":"1","element_path":"1","fonts":"1","paste":"1","searchreplace":"1","insertdate":"1","colors":"1","table":"1","smilies":"1","hr":"1","link":"1","media":"1","print":"1","directionality":"1","fullscreen":"1","alignment":"1","visualchars":"1","visualblocks":"1","nonbreaking":"1","template":"1","blockquote":"1","wordcount":"1","image_advtab":"1","advlist":"1","autosave":"1","contextmenu":"1","inlinepopups":"1","custom_plugin":"","custom_button":""}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(413, 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_article","type":"plugin","creationDate":"October 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_ARTICLE_XML_DESCRIPTION","group":"","filename":"article"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(414, 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_image","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_IMAGE_XML_DESCRIPTION","group":"","filename":"image"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(415, 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_pagebreak","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION","group":"","filename":"pagebreak"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(416, 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_readmore","type":"plugin","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_READMORE_XML_DESCRIPTION","group":"","filename":"readmore"}', '', '', '', 0, '0000-00-00 00:00:00', 4, 0);
INSERT INTO `g2q6h_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(417, 'plg_search_categories', 'plugin', 'categories', 'search', 0, 1, 1, 0, '{"name":"plg_search_categories","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION","group":"","filename":"categories"}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(418, 'plg_search_contacts', 'plugin', 'contacts', 'search', 0, 1, 1, 0, '{"name":"plg_search_contacts","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CONTACTS_XML_DESCRIPTION","group":"","filename":"contacts"}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(419, 'plg_search_content', 'plugin', 'content', 'search', 0, 1, 1, 0, '{"name":"plg_search_content","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CONTENT_XML_DESCRIPTION","group":"","filename":"content"}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(420, 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', 0, 1, 1, 0, '{"name":"plg_search_newsfeeds","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION","group":"","filename":"newsfeeds"}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(422, 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', 0, 0, 1, 1, '{"name":"plg_system_languagefilter","type":"plugin","creationDate":"July 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION","group":"","filename":"languagefilter"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(423, 'plg_system_p3p', 'plugin', 'p3p', 'system', 0, 0, 1, 0, '{"name":"plg_system_p3p","type":"plugin","creationDate":"September 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_P3P_XML_DESCRIPTION","group":"","filename":"p3p"}', '{"headers":"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(424, 'plg_system_cache', 'plugin', 'cache', 'system', 0, 0, 1, 1, '{"name":"plg_system_cache","type":"plugin","creationDate":"February 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CACHE_XML_DESCRIPTION","group":"","filename":"cache"}', '{"browsercache":"0","cachetime":"15"}', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(425, 'plg_system_debug', 'plugin', 'debug', 'system', 0, 1, 1, 0, '{"name":"plg_system_debug","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_DEBUG_XML_DESCRIPTION","group":"","filename":"debug"}', '{"profile":"1","queries":"1","memory":"1","language_files":"1","language_strings":"1","strip-first":"1","strip-prefix":"","strip-suffix":""}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(426, 'plg_system_log', 'plugin', 'log', 'system', 0, 1, 1, 1, '{"name":"plg_system_log","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LOG_XML_DESCRIPTION","group":"","filename":"log"}', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(427, 'plg_system_redirect', 'plugin', 'redirect', 'system', 0, 0, 1, 1, '{"name":"plg_system_redirect","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_REDIRECT_XML_DESCRIPTION","group":"","filename":"redirect"}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(428, 'plg_system_remember', 'plugin', 'remember', 'system', 0, 1, 1, 1, '{"name":"plg_system_remember","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_REMEMBER_XML_DESCRIPTION","group":"","filename":"remember"}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(429, 'plg_system_sef', 'plugin', 'sef', 'system', 0, 1, 1, 0, '{"name":"plg_system_sef","type":"plugin","creationDate":"December 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEF_XML_DESCRIPTION","group":"","filename":"sef"}', '', '', '', 0, '0000-00-00 00:00:00', 8, 0),
(430, 'plg_system_logout', 'plugin', 'logout', 'system', 0, 1, 1, 1, '{"name":"plg_system_logout","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION","group":"","filename":"logout"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(431, 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', 0, 0, 1, 0, '{"name":"plg_user_contactcreator","type":"plugin","creationDate":"August 2009","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTACTCREATOR_XML_DESCRIPTION","group":"","filename":"contactcreator"}', '{"autowebpage":"","category":"34","autopublish":"0"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(432, 'plg_user_joomla', 'plugin', 'joomla', 'user', 0, 1, 1, 0, '{"name":"plg_user_joomla","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_USER_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '{"autoregister":"1","mail_to_user":"1","forceLogout":"1"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(433, 'plg_user_profile', 'plugin', 'profile', 'user', 0, 0, 1, 0, '{"name":"plg_user_profile","type":"plugin","creationDate":"January 2008","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_USER_PROFILE_XML_DESCRIPTION","group":"","filename":"profile"}', '{"register-require_address1":"1","register-require_address2":"1","register-require_city":"1","register-require_region":"1","register-require_country":"1","register-require_postal_code":"1","register-require_phone":"1","register-require_website":"1","register-require_favoritebook":"1","register-require_aboutme":"1","register-require_tos":"1","register-require_dob":"1","profile-require_address1":"1","profile-require_address2":"1","profile-require_city":"1","profile-require_region":"1","profile-require_country":"1","profile-require_postal_code":"1","profile-require_phone":"1","profile-require_website":"1","profile-require_favoritebook":"1","profile-require_aboutme":"1","profile-require_tos":"1","profile-require_dob":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(434, 'plg_extension_joomla', 'plugin', 'joomla', 'extension', 0, 1, 1, 1, '{"name":"plg_extension_joomla","type":"plugin","creationDate":"May 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(435, 'plg_content_joomla', 'plugin', 'joomla', 'content', 0, 1, 1, 0, '{"name":"plg_content_joomla","type":"plugin","creationDate":"November 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(436, 'plg_system_languagecode', 'plugin', 'languagecode', 'system', 0, 0, 1, 0, '{"name":"plg_system_languagecode","type":"plugin","creationDate":"November 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION","group":"","filename":"languagecode"}', '', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(437, 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', 0, 1, 1, 1, '{"name":"plg_quickicon_joomlaupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION","group":"","filename":"joomlaupdate"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(438, 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', 0, 1, 1, 1, '{"name":"plg_quickicon_extensionupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION","group":"","filename":"extensionupdate"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(439, 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', 0, 0, 1, 0, '{"name":"plg_captcha_recaptcha","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.4.0","description":"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION","group":"","filename":"recaptcha"}', '{"public_key":"","private_key":"","theme":"clean"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(440, 'plg_system_highlight', 'plugin', 'highlight', 'system', 0, 1, 1, 0, '{"name":"plg_system_highlight","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION","group":"","filename":"highlight"}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(441, 'plg_content_finder', 'plugin', 'finder', 'content', 0, 0, 1, 0, '{"name":"plg_content_finder","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_FINDER_XML_DESCRIPTION","group":"","filename":"finder"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(442, 'plg_finder_categories', 'plugin', 'categories', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_categories","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CATEGORIES_XML_DESCRIPTION","group":"","filename":"categories"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(443, 'plg_finder_contacts', 'plugin', 'contacts', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_contacts","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CONTACTS_XML_DESCRIPTION","group":"","filename":"contacts"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(444, 'plg_finder_content', 'plugin', 'content', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_content","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CONTENT_XML_DESCRIPTION","group":"","filename":"content"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(445, 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_newsfeeds","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION","group":"","filename":"newsfeeds"}', '', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(447, 'plg_finder_tags', 'plugin', 'tags', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_tags","type":"plugin","creationDate":"February 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_TAGS_XML_DESCRIPTION","group":"","filename":"tags"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(448, 'plg_twofactorauth_totp', 'plugin', 'totp', 'twofactorauth', 0, 0, 1, 0, '{"name":"plg_twofactorauth_totp","type":"plugin","creationDate":"August 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"PLG_TWOFACTORAUTH_TOTP_XML_DESCRIPTION","group":"","filename":"totp"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(449, 'plg_authentication_cookie', 'plugin', 'cookie', 'authentication', 0, 1, 1, 0, '{"name":"plg_authentication_cookie","type":"plugin","creationDate":"July 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_AUTH_COOKIE_XML_DESCRIPTION","group":"","filename":"cookie"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(450, 'plg_twofactorauth_yubikey', 'plugin', 'yubikey', 'twofactorauth', 0, 0, 1, 0, '{"name":"plg_twofactorauth_yubikey","type":"plugin","creationDate":"September 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"PLG_TWOFACTORAUTH_YUBIKEY_XML_DESCRIPTION","group":"","filename":"yubikey"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(451, 'plg_search_tags', 'plugin', 'tags', 'search', 0, 1, 1, 0, '{"name":"plg_search_tags","type":"plugin","creationDate":"March 2014","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_TAGS_XML_DESCRIPTION","group":"","filename":"tags"}', '{"search_limit":"50","show_tagged_items":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(503, 'beez3', 'template', 'beez3', '', 0, 1, 1, 0, '{"name":"beez3","type":"template","creationDate":"25 November 2009","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"3.1.0","description":"TPL_BEEZ3_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(504, 'hathor', 'template', 'hathor', '', 1, 1, 1, 0, '{"name":"hathor","type":"template","creationDate":"May 2010","author":"Andrea Tarr","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"hathor@tarrconsulting.com","authorUrl":"http:\\/\\/www.tarrconsulting.com","version":"3.0.0","description":"TPL_HATHOR_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{"showSiteName":"0","colourChoice":"0","boldText":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(506, 'protostar', 'template', 'protostar', '', 0, 1, 1, 0, '{"name":"protostar","type":"template","creationDate":"4\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_PROTOSTAR_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(507, 'isis', 'template', 'isis', '', 1, 1, 1, 0, '{"name":"isis","type":"template","creationDate":"3\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_ISIS_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{"templateColor":"","logoFile":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(600, 'English (en-GB)', 'language', 'en-GB', '', 0, 1, 1, 1, '{"name":"English (en-GB)","type":"language","creationDate":"2013-03-07","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.4.1","description":"en-GB site language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(601, 'English (en-GB)', 'language', 'en-GB', '', 1, 1, 1, 1, '{"name":"English (en-GB)","type":"language","creationDate":"2013-03-07","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.4.1","description":"en-GB administrator language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(700, 'files_joomla', 'file', 'joomla', '', 0, 1, 1, 1, '{"name":"files_joomla","type":"file","creationDate":"March 2015","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.4.1","description":"FILES_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10000, 'PLG_SYSTEM_NNFRAMEWORK', 'plugin', 'nnframework', 'system', 0, 1, 1, 0, '{"name":"PLG_SYSTEM_NNFRAMEWORK","type":"plugin","creationDate":"April 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"http:\\/\\/www.nonumber.nl","version":"15.4.3","description":"PLG_SYSTEM_NNFRAMEWORK_DESC","group":"","filename":"nnframework"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10001, 'PLG_SYSTEM_MODULESANYWHERE', 'plugin', 'modulesanywhere', 'system', 0, 1, 1, 0, '{"name":"PLG_SYSTEM_MODULESANYWHERE","type":"plugin","creationDate":"April 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"http:\\/\\/www.nonumber.nl","version":"3.6.5FREE","description":"PLG_SYSTEM_MODULESANYWHERE_DESC","group":"","filename":"modulesanywhere"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10002, 'PLG_EDITORS-XTD_MODULESANYWHERE', 'plugin', 'modulesanywhere', 'editors-xtd', 0, 1, 1, 0, '{"name":"PLG_EDITORS-XTD_MODULESANYWHERE","type":"plugin","creationDate":"April 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"http:\\/\\/www.nonumber.nl","version":"3.6.5FREE","description":"PLG_EDITORS-XTD_MODULESANYWHERE_DESC","group":"","filename":"modulesanywhere"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10003, 'PLG_SYSTEM_ARTICLESANYWHERE', 'plugin', 'articlesanywhere', 'system', 0, 1, 1, 0, '{"name":"PLG_SYSTEM_ARTICLESANYWHERE","type":"plugin","creationDate":"April 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"http:\\/\\/www.nonumber.nl","version":"3.9.1FREE","description":"PLG_SYSTEM_ARTICLESANYWHERE_DESC","group":"","filename":"articlesanywhere"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10004, 'PLG_EDITORS-XTD_ARTICLESANYWHERE', 'plugin', 'articlesanywhere', 'editors-xtd', 0, 1, 1, 0, '{"name":"PLG_EDITORS-XTD_ARTICLESANYWHERE","type":"plugin","creationDate":"April 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"http:\\/\\/www.nonumber.nl","version":"3.9.1FREE","description":"PLG_EDITORS-XTD_ARTICLESANYWHERE_DESC","group":"","filename":"articlesanywhere"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10005, 'COM_GEOFACTORY', 'component', 'com_geofactory', '', 1, 1, 0, 0, '{"name":"COM_GEOFACTORY","type":"component","creationDate":"2013","author":"C\\u00e9dric Pelloquin","copyright":"Copyright \\u00a9 2009-2014 - myJoom.com - All rights reserved.","authorEmail":"info@myJoom.com","authorUrl":"http:\\/\\/www.myJoom.com","version":"5.15.0430","description":"COM_GEOFACTORY_DESCRIPTION","group":"","filename":"geofactory"}', '{"subsEnd":"","useAllFields":"0","ggApikey":"","mapLang":"da","msOrdering":"0","isBasic":"0","isDebug":"0","sidemode":"2","largeMarkers":"64","useBigSelect":"1","hideNote":"1","showTerms":"0","ggRegion":"","iPauseGeo":"2000000","showMinimap":"1","geocodeClient":"0","geocodeLog":"0","ggSeparator":"+","jqMode":"2","jqUiTheme":"base","parseplugin":"0","waysearchBtn":"1","colorRadius":"#00a1ff","colorSalesArea":"Green","prefix_old":"old-map_","import-driver":"mysqli","import-host":"localhost","import-user":"","import-password":"","import-database":"","import-prefix":"jos_"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10006, 'MOD_GEOFACTORY_MAP', 'module', 'mod_geofactory_map', '', 0, 1, 0, 0, '{"name":"MOD_GEOFACTORY_MAP","type":"module","creationDate":"2013","author":"C\\u00e9dric Pelloquin","copyright":"Copyright \\u00a9 2009-2014 - myJoom.com - All rights reserved.","authorEmail":"info@myJoom.com","authorUrl":"http:\\/\\/www.myJoom.com","version":"5.15.0430","description":"MOD_GEOFACTORY_MAP_DESCRIPTION","group":"","filename":"mod_geofactory_map"}', '{"zoom":"0","taskToIgnore":"task=viewlink,pid=?,view=details,task=userProfile,view=profile","taskToForce":"-","usetab_id":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10007, 'MOD_GEOFACTORY_SEARCH', 'module', 'mod_geofactory_search', '', 0, 1, 0, 0, '{"name":"MOD_GEOFACTORY_SEARCH","type":"module","creationDate":"February 2012","author":"C\\u00e9dric Pelloquin","copyright":"Copyright (C) 2009-2014 myJoom.com","authorEmail":"info@myjoom.com","authorUrl":"http:\\/\\/www.myjoom.com\\/","version":"5.15.0430","description":"MOD_GEOFACTORY_SEARCH_DESC","group":"","filename":"mod_geofactory_search"}', '{"moduleclass_sfx":"","sMapUrl":"","bRadius":"1","vRadius":"","iUnit":"1","bLocateMe":"0","sLabInput":"","sLabSelect":"","sLabSearch":"","sLabReset":"","placeholder":"","bSidebar":"1","bSidelists":"1","sIntro":"","sCountryLimit":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10008, 'Geocode Factory 5 - Button - Joomla content', 'plugin', 'plg_geofactory_btn_jc30', 'editors-xtd', 0, 1, 1, 0, '{"name":"Geocode Factory 5 - Button - Joomla content","type":"plugin","creationDate":"2014","author":"C\\u00e9dric Pelloquin","copyright":"Copyright \\u00a9 2009-2014 - All rights reserved.","authorEmail":"info@myJoom.com","authorUrl":"http:\\/\\/www.myJoom.com","version":"5.15.0415","description":"Geocode Factory 5 - Editor button to geocode your Joomla articles","group":"","filename":"plg_geofactory_btn_jc30"}', '{"defLat":"","defLng":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10009, 'PLG_GEOFACTORY_CONTENT_JC30', 'plugin', 'plg_geofactory_content_jc30', 'content', 0, 1, 1, 0, '{"name":"PLG_GEOFACTORY_CONTENT_JC30","type":"plugin","creationDate":"2013","author":"C\\u00e9dric Pelloquin","copyright":"Copyright \\u00a9 2009-2014 - All rights reserved.","authorEmail":"info@myJoom.com","authorUrl":"http:\\/\\/www.myJoom.com","version":"5.15.0415","description":"PLG_GEOFACTORY_CONTENT_JC30_DESCRIPTION","group":"","filename":"plg_geofactory_content_jc30"}', '{"idMap":"","showMap":"1","staticZoom":"0","staticWidth":"200","staticHeight":"200"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10010, 'PLG_GEOFACTORY_GW_JC30', 'plugin', 'plg_geofactory_gw_jc30', 'geocodefactory', 0, 1, 1, 0, '{"name":"PLG_GEOFACTORY_GW_JC30","type":"plugin","creationDate":"2013","author":"C\\u00e9dric Pelloquin","copyright":"Copyright \\u00a9 2009-2014 - All rights reserved.","authorEmail":"info@myJoom.com","authorUrl":"http:\\/\\/www.myJoom.com","version":"5.15.0415","description":"PLG_GEOFACTORY_GW_JC30_DESCRIPTION","group":"","filename":"plg_geofactory_gw_jc30"}', '{"linesOwners":"red"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10011, 'PLG_GEOFACTORY_LOAD_MAP', 'plugin', 'plg_geofactory_load_map', 'content', 0, 0, 1, 0, '{"name":"PLG_GEOFACTORY_LOAD_MAP","type":"plugin","creationDate":"2014","author":"C\\u00e9dric Pelloquin","copyright":"Copyright \\u00a9 2009-2014 - All rights reserved.","authorEmail":"info@myJoom.com","authorUrl":"http:\\/\\/www.myJoom.com","version":"5.15.0415","description":"PLG_GEOFACTORY_LOAD_MAP_DESCRIPTION","group":"","filename":"plg_geofactory_load_map"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10012, 'Geocode Factory Package', 'package', 'pkg_geofactory', '', 0, 1, 1, 0, '{"name":"Geocode Factory Package","type":"package","creationDate":"2014","author":"C\\u00e9dric Pelloquin","copyright":"","authorEmail":"","authorUrl":"","version":"5.15.0415","description":"Geocode Factory<br \\/>version 5 pakage<br \\/><br \\/><img src=''components\\/com_geofactory\\/assets\\/logo.png'' style=''float: none'' \\/><br \\/><br \\/>Display your joomla content on maps<br\\/><br \\/><a href=''http:\\/\\/www.myjoom.com'' target=''_blank''>Get support and documentation<\\/a> about the Geocode Factory.<br \\/>Please post a review in the <a href=''http:\\/\\/extensions.joomla.org\\/extensions\\/maps-a-weather\\/geotagging\\/27041'' target=''_blank''>Joomla! Extensions Directory<\\/a>.<br \\/><br \\/>Rick and the team @ <a href=''http:\\/\\/www.myjoom.com'' target=''_blank''>myJoom.com<\\/a><br \\/><br \\/><a class=''btn btn-primary btn-large'' href=''index.php?option=com_geofactory''>Go to Geocode Factory !<\\/a><br \\/><br \\/>","group":"","filename":"pkg_geofactory"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10013, 'daekcenter', 'template', 'daekcenter', '', 0, 1, 1, 0, '{"name":"daekcenter","type":"template","creationDate":"10 May 2015","author":"T.Trung","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"nttrung211@gmail.com","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"3.1.0","description":"Daekcenter","group":"","filename":"templateDetails"}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature","backgroundcolor":"#eee"}', '', '', 0, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_filters`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms0`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms1`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms2`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms3`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms4`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms5`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms6`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms7`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms8`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_terms9`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_termsa`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_termsb`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_termsc`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_termsd`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_termse`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_links_termsf`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_taxonomy`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `g2q6h_finder_taxonomy`
--

INSERT INTO `g2q6h_finder_taxonomy` (`id`, `parent_id`, `title`, `state`, `access`, `ordering`) VALUES
(1, 0, 'ROOT', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_taxonomy_map`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_terms`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_terms_common`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `g2q6h_finder_terms_common`
--

INSERT INTO `g2q6h_finder_terms_common` (`term`, `language`) VALUES
('a', 'en'),
('about', 'en'),
('after', 'en'),
('ago', 'en'),
('all', 'en'),
('am', 'en'),
('an', 'en'),
('and', 'en'),
('ani', 'en'),
('any', 'en'),
('are', 'en'),
('aren''t', 'en'),
('as', 'en'),
('at', 'en'),
('be', 'en'),
('but', 'en'),
('by', 'en'),
('for', 'en'),
('from', 'en'),
('get', 'en'),
('go', 'en'),
('how', 'en'),
('if', 'en'),
('in', 'en'),
('into', 'en'),
('is', 'en'),
('isn''t', 'en'),
('it', 'en'),
('its', 'en'),
('me', 'en'),
('more', 'en'),
('most', 'en'),
('must', 'en'),
('my', 'en'),
('new', 'en'),
('no', 'en'),
('none', 'en'),
('not', 'en'),
('noth', 'en'),
('nothing', 'en'),
('of', 'en'),
('off', 'en'),
('often', 'en'),
('old', 'en'),
('on', 'en'),
('onc', 'en'),
('once', 'en'),
('onli', 'en'),
('only', 'en'),
('or', 'en'),
('other', 'en'),
('our', 'en'),
('ours', 'en'),
('out', 'en'),
('over', 'en'),
('page', 'en'),
('she', 'en'),
('should', 'en'),
('small', 'en'),
('so', 'en'),
('some', 'en'),
('than', 'en'),
('thank', 'en'),
('that', 'en'),
('the', 'en'),
('their', 'en'),
('theirs', 'en'),
('them', 'en'),
('then', 'en'),
('there', 'en'),
('these', 'en'),
('they', 'en'),
('this', 'en'),
('those', 'en'),
('thus', 'en'),
('time', 'en'),
('times', 'en'),
('to', 'en'),
('too', 'en'),
('true', 'en'),
('under', 'en'),
('until', 'en'),
('up', 'en'),
('upon', 'en'),
('use', 'en'),
('user', 'en'),
('users', 'en'),
('veri', 'en'),
('version', 'en'),
('very', 'en'),
('via', 'en'),
('want', 'en'),
('was', 'en'),
('way', 'en'),
('were', 'en'),
('what', 'en'),
('when', 'en'),
('where', 'en'),
('whi', 'en'),
('which', 'en'),
('who', 'en'),
('whom', 'en'),
('whose', 'en'),
('why', 'en'),
('wide', 'en'),
('will', 'en'),
('with', 'en'),
('within', 'en'),
('without', 'en'),
('would', 'en'),
('yes', 'en'),
('yet', 'en'),
('you', 'en'),
('your', 'en'),
('yours', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_tokens`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT '',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_tokens_aggregate`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  `language` char(3) NOT NULL DEFAULT '',
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_finder_types`
--

CREATE TABLE IF NOT EXISTS `g2q6h_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_geofactory_assignation`
--

CREATE TABLE IF NOT EXISTS `g2q6h_geofactory_assignation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `typeList` varchar(33) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `field_latitude` varchar(255) NOT NULL DEFAULT '',
  `field_longitude` varchar(255) NOT NULL DEFAULT '',
  `field_street` varchar(255) NOT NULL DEFAULT '',
  `field_postal` varchar(255) NOT NULL DEFAULT '',
  `field_city` varchar(255) NOT NULL DEFAULT '',
  `field_county` varchar(255) NOT NULL DEFAULT '',
  `field_state` varchar(255) NOT NULL DEFAULT '',
  `field_country` varchar(255) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `g2q6h_geofactory_assignation`
--

INSERT INTO `g2q6h_geofactory_assignation` (`id`, `name`, `typeList`, `extrainfo`, `field_latitude`, `field_longitude`, `field_street`, `field_postal`, `field_city`, `field_county`, `field_state`, `field_country`, `state`, `checked_out`, `checked_out_time`) VALUES
(1, 'Default - Joomla Content 3.0', 'MS_JC', 'Default fields assignation for : Joomla Content 3.0', '', '', '', '', '', '', '', '', 1, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_geofactory_contents`
--

CREATE TABLE IF NOT EXISTS `g2q6h_geofactory_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL DEFAULT '',
  `id_content` int(11) NOT NULL,
  `address` text,
  `latitude` varchar(255) NOT NULL DEFAULT '',
  `longitude` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `g2q6h_geofactory_contents`
--

INSERT INTO `g2q6h_geofactory_contents` (`id`, `type`, `id_content`, `address`, `latitude`, `longitude`) VALUES
(2, 'com_content', 11, '', '56.698183032862', '9.4912657680511');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_geofactory_ggmaps`
--

CREATE TABLE IF NOT EXISTS `g2q6h_geofactory_ggmaps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `template` text NOT NULL,
  `extrainfo` text NOT NULL,
  `mapwidth` varchar(75) NOT NULL DEFAULT 'px',
  `mapheight` varchar(75) NOT NULL DEFAULT 'px',
  `totalmarkers` int(11) NOT NULL DEFAULT '0',
  `centerlat` varchar(33) NOT NULL DEFAULT '45.543',
  `centerlng` varchar(33) NOT NULL DEFAULT '-73.604',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `language` varchar(255) NOT NULL DEFAULT '*',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params_map_cluster` text NOT NULL,
  `params_map_radius` text NOT NULL,
  `params_additional_data` text NOT NULL,
  `params_map_types` text NOT NULL,
  `params_map_controls` text NOT NULL,
  `params_map_settings` text NOT NULL,
  `params_map_mouse` text NOT NULL,
  `params_extra` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `g2q6h_geofactory_ggmaps`
--

INSERT INTO `g2q6h_geofactory_ggmaps` (`id`, `name`, `alias`, `template`, `extrainfo`, `mapwidth`, `mapheight`, `totalmarkers`, `centerlat`, `centerlng`, `state`, `language`, `checked_out`, `checked_out_time`, `params_map_cluster`, `params_map_radius`, `params_additional_data`, `params_map_types`, `params_map_controls`, `params_map_settings`, `params_map_mouse`, `params_extra`) VALUES
(1, 'Daekcenter Map', 'daekcenter-map', '', '', 'width: 480 px', 'height: 500 px', 0, '56.119589723330925', '11.513649600000008', 1, '*', 0, '0000-00-00 00:00:00', '{"useCluster":"0","clusterZoom":"10","gridSize":"","imagePath":"","imageSizes":"","minimumClusterSize":""}', '{"drawCircle":"1","dynRadDistMax":"","frontDistSelect":"1,5,10,20,50,100","fe_rad_unit":"0","radFormMode":"0","radFormSnipet":"Search from [input_center][distance_sel][search_btn]","acCountry":"","acTypes":"0","useBrowserRadLoad":"0"}', '{"kml_file":"","level1":"","level2":"","level3":"","level4":"","level5":"","level6":""}', '{"mapControl":"1","mapTypeBar":"DEFAULT","mapTypeOnStart":"ROADMAP","tiles":""}', '{"templateAuto":"0","centerUser":"3","mapsZoom":"6","minZoom":"1","maxZoom":"18","mapTypeControl":"DEFAULT","pegman":"1","scaleControl":"1","rotateControl":"1","overviewMapControl":"1"}', '{"allowDbl":"2","randomMarkers":"0","cleanLoad":"0","useRoutePlaner":"0","useTabs":"0","cacheTime":"0","mapStyle":"","cssMap":""}', '{"doubleClickZoom":"1","wheelZoom":"1","bubbleOnOver":"0","clickRadius":"0","salesRadMode":"0","trackOnOver":"0","trackZoom":"1"}', '');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_geofactory_link_map_ms`
--

CREATE TABLE IF NOT EXISTS `g2q6h_geofactory_link_map_ms` (
  `id_map` int(11) NOT NULL DEFAULT '0',
  `id_ms` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `g2q6h_geofactory_link_map_ms`
--

INSERT INTO `g2q6h_geofactory_link_map_ms` (`id_map`, `id_ms`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_geofactory_markersets`
--

CREATE TABLE IF NOT EXISTS `g2q6h_geofactory_markersets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `template_bubble` text NOT NULL,
  `template_sidebar` text NOT NULL,
  `typeList` varchar(33) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `language` varchar(255) NOT NULL DEFAULT '*',
  `mslevel` int(11) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params_markerset_settings` text NOT NULL,
  `params_markerset_radius` text NOT NULL,
  `params_markerset_icon` text NOT NULL,
  `params_markerset_type_setting` text NOT NULL,
  `params_extra` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `g2q6h_geofactory_markersets`
--

INSERT INTO `g2q6h_geofactory_markersets` (`id`, `name`, `extrainfo`, `template_bubble`, `template_sidebar`, `typeList`, `ordering`, `state`, `language`, `mslevel`, `checked_out`, `checked_out_time`, `params_markerset_settings`, `params_markerset_radius`, `params_markerset_icon`, `params_markerset_type_setting`, `params_extra`) VALUES
(1, 'Daekcenter Markers', '', '<p>{introtext}</p>\r\n<p>{fulltext}</p>', '', 'MS_JC', 1, 1, '*', 0, 401, '2015-05-12 17:49:44', '{"field_assignation":"1","allow_groups":[""],"accuracy":"0","bubblewidth":"","cssMs":"","checked_loading":"1"}', '{"rad_distance":"","rad_unit":"0","rad_mode":"1","current_view_center_pattern":"1","rad_allms":"0"}', '{"markerIconType":"0","customimage":"","avatarSizeW":"","avatarSizeH":"","mapicon":"-1"}', '{"filter":"","childCats":"0","onlyPublished":"0","linesOwners":"0","catAuto":"0","maxmarkers":"0"}', '');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_languages`
--

CREATE TABLE IF NOT EXISTS `g2q6h_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `g2q6h_languages`
--

INSERT INTO `g2q6h_languages` (`lang_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES
(1, 'en-GB', 'English (UK)', 'English (UK)', 'en', 'en', '', '', '', '', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_menu`
--

CREATE TABLE IF NOT EXISTS `g2q6h_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_path` (`path`(255)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=119 ;

--
-- Dumping data for table `g2q6h_menu`
--

INSERT INTO `g2q6h_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(1, '', 'Menu_Item_Root', 'root', '', '', '', '', 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, '', 0, '', 0, 77, 0, '*', 0),
(2, 'menu', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', 0, 1, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 1, 10, 0, '*', 1),
(3, 'menu', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 2, 3, 0, '*', 1),
(4, 'menu', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', 0, 2, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-cat', 0, '', 4, 5, 0, '*', 1),
(5, 'menu', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-clients', 0, '', 6, 7, 0, '*', 1),
(6, 'menu', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-tracks', 0, '', 8, 9, 0, '*', 1),
(7, 'menu', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', 0, 1, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 11, 16, 0, '*', 1),
(8, 'menu', 'com_contact', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', 0, 7, 2, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 12, 13, 0, '*', 1),
(9, 'menu', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', 0, 7, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact-cat', 0, '', 14, 15, 0, '*', 1),
(10, 'menu', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', 0, 1, 1, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages', 0, '', 17, 22, 0, '*', 1),
(11, 'menu', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-add', 0, '', 18, 19, 0, '*', 1),
(12, 'menu', 'com_messages_read', 'Read Private Message', '', 'Messaging/Read Private Message', 'index.php?option=com_messages', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-read', 0, '', 20, 21, 0, '*', 1),
(13, 'menu', 'com_newsfeeds', 'News Feeds', '', 'News Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 1, 1, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 23, 28, 0, '*', 1),
(14, 'menu', 'com_newsfeeds_feeds', 'Feeds', '', 'News Feeds/Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 13, 2, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 24, 25, 0, '*', 1),
(15, 'menu', 'com_newsfeeds_categories', 'Categories', '', 'News Feeds/Categories', 'index.php?option=com_categories&extension=com_newsfeeds', 'component', 0, 13, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds-cat', 0, '', 26, 27, 0, '*', 1),
(16, 'menu', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', 0, 1, 1, 24, 0, '0000-00-00 00:00:00', 0, 0, 'class:redirect', 0, '', 29, 30, 0, '*', 1),
(17, 'menu', 'com_search', 'Basic Search', '', 'Basic Search', 'index.php?option=com_search', 'component', 0, 1, 1, 19, 0, '0000-00-00 00:00:00', 0, 0, 'class:search', 0, '', 31, 32, 0, '*', 1),
(18, 'menu', 'com_finder', 'Smart Search', '', 'Smart Search', 'index.php?option=com_finder', 'component', 0, 1, 1, 27, 0, '0000-00-00 00:00:00', 0, 0, 'class:finder', 0, '', 33, 34, 0, '*', 1),
(19, 'menu', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', 1, 1, 1, 28, 0, '0000-00-00 00:00:00', 0, 0, 'class:joomlaupdate', 0, '', 35, 36, 0, '*', 1),
(20, 'main', 'com_tags', 'Tags', '', 'Tags', 'index.php?option=com_tags', 'component', 0, 1, 1, 29, 0, '0000-00-00 00:00:00', 0, 1, 'class:tags', 0, '', 37, 38, 0, '', 1),
(21, 'main', 'com_postinstall', 'Post-installation messages', '', 'Post-installation messages', 'index.php?option=com_postinstall', 'component', 0, 1, 1, 32, 0, '0000-00-00 00:00:00', 0, 1, 'class:postinstall', 0, '', 39, 40, 0, '*', 1),
(101, 'mainmenu', 'DANMARKSKORT', 'home', '', 'home', 'index.php?option=com_geofactory&view=map&id=1', 'component', 1, 1, 1, 10005, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"0","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 41, 42, 1, '*', 0),
(102, 'main', 'COM_GEOFACTORY_XML_TOP_MENU', 'com-geofactory-xml-top-menu', '', 'com-geofactory-xml-top-menu', 'index.php?option=com_geofactory', 'component', 0, 1, 1, 10005, 0, '0000-00-00 00:00:00', 0, 1, 'class:geofactory', 0, '', 43, 54, 0, '', 1),
(103, 'main', 'COM_GEOFACTORY_XML_MENU_CPANEL', 'com-geofactory-xml-menu-cpanel', '', 'com-geofactory-xml-top-menu/com-geofactory-xml-menu-cpanel', 'index.php?option=com_geofactory', 'component', 0, 102, 2, 10005, 0, '0000-00-00 00:00:00', 0, 1, 'class:geofactory', 0, '', 44, 45, 0, '', 1),
(104, 'main', 'COM_GEOFACTORY_XML_MENU_MAPS', 'com-geofactory-xml-menu-maps', '', 'com-geofactory-xml-top-menu/com-geofactory-xml-menu-maps', 'index.php?option=com_geofactory&view=ggmaps', 'component', 0, 102, 2, 10005, 0, '0000-00-00 00:00:00', 0, 1, 'class:geofactory-maps', 0, '', 46, 47, 0, '', 1),
(105, 'main', 'COM_GEOFACTORY_XML_MENU_MARKERSET', 'com-geofactory-xml-menu-markerset', '', 'com-geofactory-xml-top-menu/com-geofactory-xml-menu-markerset', 'index.php?option=com_geofactory&view=markersets', 'component', 0, 102, 2, 10005, 0, '0000-00-00 00:00:00', 0, 1, 'class:geofactory-ms', 0, '', 48, 49, 0, '', 1),
(106, 'main', 'COM_GEOFACTORY_XML_MENU_PATTERN', 'com-geofactory-xml-menu-pattern', '', 'com-geofactory-xml-top-menu/com-geofactory-xml-menu-pattern', 'index.php?option=com_geofactory&view=assigns', 'component', 0, 102, 2, 10005, 0, '0000-00-00 00:00:00', 0, 1, 'class:geofactory-assign', 0, '', 50, 51, 0, '', 1),
(107, 'main', 'COM_GEOFACTORY_XML_MENU_GEOCODE', 'com-geofactory-xml-menu-geocode', '', 'com-geofactory-xml-top-menu/com-geofactory-xml-menu-geocode', 'index.php?option=com_geofactory&view=geocodes', 'component', 0, 102, 2, 10005, 0, '0000-00-00 00:00:00', 0, 1, 'class:geofactory-geocodes', 0, '', 52, 53, 0, '', 1),
(108, 'mainmenu', 'AFDELINGER', '2015-05-11-07-32-12', '', '2015-05-11-07-32-12', '#', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1}', 55, 56, 0, '*', 0),
(109, 'mainmenu', 'DÆK- OG FÆLG INFO', 'daek-og-faelg-info', '', 'daek-og-faelg-info', '#', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1}', 57, 74, 0, '*', 0),
(110, 'mainmenu', 'Teknisk info – Dæk', 'teknisk-info-daek', '', 'daek-og-faelg-info/teknisk-info-daek', 'index.php?option=com_content&view=article&layout=default2&id=2', 'component', 1, 109, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 58, 59, 0, '*', 0),
(111, 'mainmenu', 'Teknisk info – Fælge', 'teknisk-info-faelge', '', 'daek-og-faelg-info/teknisk-info-faelge', 'index.php?option=com_content&view=article&layout=default2&id=3', 'component', 1, 109, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 60, 61, 0, '*', 0),
(112, 'mainmenu', 'Teknisk info – Hjul', 'teknisk-info-hjul', '', 'daek-og-faelg-info/teknisk-info-hjul', 'index.php?option=com_content&view=article&layout=default2&id=4', 'component', 1, 109, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 62, 63, 0, '*', 0),
(113, 'mainmenu', 'EU-mærkning af dæk', 'eu-maerkning-af-daek', '', 'daek-og-faelg-info/eu-maerkning-af-daek', 'index.php?option=com_content&view=article&layout=default2&id=5', 'component', 1, 109, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 64, 65, 0, '*', 0),
(114, 'mainmenu', 'Vedligeholdelsesguide dæk', 'vedligeholdelsesguide-daek', '', 'daek-og-faelg-info/vedligeholdelsesguide-daek', 'index.php?option=com_content&view=article&layout=default2&id=6', 'component', 1, 109, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 66, 67, 0, '*', 0),
(115, 'mainmenu', 'Udskiftning af dæk', 'udskiftning-af-daek', '', 'daek-og-faelg-info/udskiftning-af-daek', 'index.php?option=com_content&view=article&layout=default2&id=7', 'component', 1, 109, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 68, 69, 0, '*', 0),
(116, 'mainmenu', 'Vinterdæk regler', 'vinterdaek-regler', '', 'daek-og-faelg-info/vinterdaek-regler', 'index.php?option=com_content&view=article&layout=default2&id=8', 'component', 1, 109, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 70, 71, 0, '*', 0),
(117, 'mainmenu', 'Bliv forhandler', 'bliv-forhandler', '', 'daek-og-faelg-info/bliv-forhandler', 'index.php?option=com_content&view=article&layout=default2&id=9', 'component', 1, 109, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 72, 73, 0, '*', 0),
(118, 'mainmenu', 'FÅ KREDIT - RENTEFRIT', 'fa-kredit-rentefrit', '', 'fa-kredit-rentefrit', 'index.php?option=com_content&view=article&id=10', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 75, 76, 0, '*', 0);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_menu_types`
--

CREATE TABLE IF NOT EXISTS `g2q6h_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `g2q6h_menu_types`
--

INSERT INTO `g2q6h_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_messages`
--

CREATE TABLE IF NOT EXISTS `g2q6h_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `g2q6h_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_modules`
--

CREATE TABLE IF NOT EXISTS `g2q6h_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=90 ;

--
-- Dumping data for table `g2q6h_modules`
--

INSERT INTO `g2q6h_modules` (`id`, `asset_id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(1, 39, 'Main Menu', '', '', 1, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"mainmenu","base":"","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"_menu","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(2, 40, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 41, 'Popular Articles', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{"count":"5","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(4, 42, 'Recently Added Articles', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{"count":"5","ordering":"c_dsc","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(8, 43, 'Toolbar', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 44, 'Quick Icons', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 45, 'Logged-in Users', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{"count":"5","name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(12, 46, 'Admin Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{"layout":"","moduleclass_sfx":"","shownew":"1","showhelp":"1","cache":"0"}', 1, '*'),
(13, 47, 'Admin Submenu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 48, 'User Status', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 49, 'Title', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(16, 50, 'Login Form', '', '', 7, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{"greeting":"1","name":"0"}', 0, '*'),
(17, 51, 'Breadcrumbs', '', '', 1, 'position-2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{"showHere":"0","showHome":"0","homeText":"","showLast":"1","separator":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(79, 52, 'Multilanguage status', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(86, 53, 'Joomla Version', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{"format":"short","product":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(87, 55, 'Geocode Factory 5 map module', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_geofactory_map', 1, 1, '', 0, '*'),
(88, 56, 'Geocode Factory - Search module', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_geofactory_search', 1, 1, '', 0, '*'),
(89, 59, 'Left Menu', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"mainmenu","base":"109","startLevel":"2","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"daekcenter:left","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_modules_menu`
--

CREATE TABLE IF NOT EXISTS `g2q6h_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `g2q6h_modules_menu`
--

INSERT INTO `g2q6h_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(79, 0),
(86, 0),
(89, 109),
(89, 110),
(89, 111),
(89, 112),
(89, 113),
(89, 114),
(89, 115),
(89, 116),
(89, 117);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_newsfeeds`
--

CREATE TABLE IF NOT EXISTS `g2q6h_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `link` varchar(200) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `images` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_overrider`
--

CREATE TABLE IF NOT EXISTS `g2q6h_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_postinstall_messages`
--

CREATE TABLE IF NOT EXISTS `g2q6h_postinstall_messages` (
  `postinstall_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) NOT NULL DEFAULT '',
  `language_extension` varchar(255) NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`postinstall_message_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `g2q6h_postinstall_messages`
--

INSERT INTO `g2q6h_postinstall_messages` (`postinstall_message_id`, `extension_id`, `title_key`, `description_key`, `action_key`, `language_extension`, `language_client_id`, `type`, `action_file`, `action`, `condition_file`, `condition_method`, `version_introduced`, `enabled`) VALUES
(1, 700, 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_TITLE', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_BODY', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_ACTION', 'plg_twofactorauth_totp', 1, 'action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_condition', '3.2.0', 1),
(2, 700, 'COM_CPANEL_WELCOME_BEGINNERS_TITLE', 'COM_CPANEL_WELCOME_BEGINNERS_MESSAGE', '', 'com_cpanel', 1, 'message', '', '', '', '', '3.2.0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_redirect_links`
--

CREATE TABLE IF NOT EXISTS `g2q6h_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) NOT NULL,
  `new_url` varchar(255) DEFAULT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `header` smallint(3) NOT NULL DEFAULT '301',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_link_old` (`old_url`),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_schemas`
--

CREATE TABLE IF NOT EXISTS `g2q6h_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `g2q6h_schemas`
--

INSERT INTO `g2q6h_schemas` (`extension_id`, `version_id`) VALUES
(700, '3.4.0-2015-02-26');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_session`
--

CREATE TABLE IF NOT EXISTS `g2q6h_session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `g2q6h_session`
--

INSERT INTO `g2q6h_session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`) VALUES
('ck70c1sv19mka5lh7lhim3qbi0', 0, 1, '1431453564', '__default|a:7:{s:15:"session.counter";i:81;s:19:"session.timer.start";i:1431407984;s:18:"session.timer.last";i:1431453564;s:17:"session.timer.now";i:1431453564;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0";s:8:"registry";O:24:"Joomla\\Registry\\Registry":2:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}s:9:"separator";s:1:".";}s:4:"user";O:5:"JUser":26:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;s:1:"9";}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:12:"requireReset";N;s:10:"\\0\\0\\0_params";O:24:"Joomla\\Registry\\Registry":2:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}s:9:"separator";s:1:".";}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:9;}s:14:"\\0\\0\\0_authLevels";a:3:{i:0;i:1;i:1;i:1;i:2;i:5;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:13:"\\0\\0\\0userHelper";O:18:"JUserWrapperHelper":0:{}s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;}}', 0, ''),
('gb900d36h4o9cciu0l568bcf87', 1, 0, '1431452985', '__default|a:8:{s:15:"session.counter";i:269;s:19:"session.timer.start";i:1431430624;s:18:"session.timer.last";i:1431452984;s:17:"session.timer.now";i:1431452985;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0";s:8:"registry";O:24:"Joomla\\Registry\\Registry":2:{s:7:"\\0\\0\\0data";O:8:"stdClass":7:{s:11:"application";O:8:"stdClass":1:{s:4:"lang";s:5:"en-GB";}s:11:"com_modules";O:8:"stdClass":3:{s:7:"modules";O:8:"stdClass":1:{s:6:"filter";O:8:"stdClass":1:{s:18:"client_id_previous";i:0;}}s:4:"edit";O:8:"stdClass":1:{s:6:"module";O:8:"stdClass":2:{s:4:"data";N;s:2:"id";a:0:{}}}s:3:"add";O:8:"stdClass":1:{s:6:"module";O:8:"stdClass":2:{s:12:"extension_id";N;s:6:"params";N;}}}s:9:"com_menus";O:8:"stdClass":2:{s:5:"items";O:8:"stdClass":3:{s:8:"menutype";s:8:"mainmenu";s:10:"limitstart";i:0;s:4:"list";a:4:{s:9:"direction";s:3:"asc";s:5:"limit";s:2:"20";s:8:"ordering";s:5:"a.lft";s:5:"start";d:0;}}s:4:"edit";O:8:"stdClass":1:{s:4:"item";O:8:"stdClass":4:{s:2:"id";a:0:{}s:4:"data";N;s:4:"type";N;s:4:"link";N;}}}s:11:"com_content";O:8:"stdClass":1:{s:4:"edit";O:8:"stdClass":1:{s:7:"article";O:8:"stdClass":2:{s:4:"data";N;s:2:"id";a:0:{}}}}s:4:"item";O:8:"stdClass":1:{s:6:"filter";O:8:"stdClass":1:{s:8:"menutype";s:8:"mainmenu";}}s:14:"com_geofactory";O:8:"stdClass":1:{s:4:"edit";O:8:"stdClass":2:{s:5:"ggmap";O:8:"stdClass":2:{s:4:"data";N;s:2:"id";a:0:{}}s:9:"markerset";O:8:"stdClass":2:{s:4:"data";N;s:2:"id";a:1:{i:0;i:1;}}}}s:14:"com_categories";O:8:"stdClass":2:{s:10:"categories";O:8:"stdClass":1:{s:6:"filter";O:8:"stdClass":1:{s:9:"extension";s:11:"com_content";}}s:4:"edit";O:8:"stdClass":1:{s:8:"category";O:8:"stdClass":1:{s:4:"data";N;}}}}s:9:"separator";s:1:".";}s:4:"user";O:5:"JUser":28:{s:9:"\\0\\0\\0isRoot";b:1;s:2:"id";s:3:"401";s:4:"name";s:10:"Super User";s:8:"username";s:5:"admin";s:5:"email";s:16:"trung@istamps.dk";s:8:"password";s:60:"$2y$10$n4EErWdvX.GtXBp98jq3t.bArhW.4etBb12fFCUTU77HNOaa2083O";s:14:"password_clear";s:0:"";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"1";s:12:"registerDate";s:19:"2015-05-08 04:07:14";s:13:"lastvisitDate";s:19:"2015-05-12 05:19:36";s:10:"activation";s:1:"0";s:6:"params";s:0:"";s:6:"groups";a:1:{i:8;s:1:"8";}s:5:"guest";i:0;s:13:"lastResetTime";s:19:"0000-00-00 00:00:00";s:10:"resetCount";s:1:"0";s:12:"requireReset";s:1:"0";s:10:"\\0\\0\\0_params";O:24:"Joomla\\Registry\\Registry":2:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}s:9:"separator";s:1:".";}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:8;}s:14:"\\0\\0\\0_authLevels";a:5:{i:0;i:1;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:6;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:13:"\\0\\0\\0userHelper";O:18:"JUserWrapperHelper":0:{}s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;s:6:"otpKey";s:0:"";s:4:"otep";s:0:"";}s:13:"session.token";s:32:"a7421b50415e72cab5382e56a637dee1";}', 401, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_tags`
--

CREATE TABLE IF NOT EXISTS `g2q6h_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tag_idx` (`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `g2q6h_tags`
--

INSERT INTO `g2q6h_tags` (`id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `created_by_alias`, `modified_user_id`, `modified_time`, `images`, `urls`, `hits`, `language`, `version`, `publish_up`, `publish_down`) VALUES
(1, 0, 0, 1, 0, '', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '', '', '', '', 0, '2011-01-01 00:00:01', '', 0, '0000-00-00 00:00:00', '', '', 0, '*', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_template_styles`
--

CREATE TABLE IF NOT EXISTS `g2q6h_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `g2q6h_template_styles`
--

INSERT INTO `g2q6h_template_styles` (`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES
(4, 'beez3', 0, '0', 'Beez3 - Default', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/joomla_black.gif","sitetitle":"Joomla!","sitedescription":"Open Source Content Management","navposition":"left","templatecolor":"personal","html5":"0"}'),
(5, 'hathor', 1, '0', 'Hathor - Default', '{"showSiteName":"0","colourChoice":"","boldText":"0"}'),
(7, 'protostar', 0, '0', 'protostar - Default', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}'),
(8, 'isis', 1, '1', 'isis - Default', '{"templateColor":"","logoFile":""}'),
(9, 'daekcenter', 0, '1', 'daekcenter - Default', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature","backgroundcolor":"#eee"}');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_ucm_base`
--

CREATE TABLE IF NOT EXISTS `g2q6h_ucm_base` (
  `ucm_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL,
  PRIMARY KEY (`ucm_id`),
  KEY `idx_ucm_item_id` (`ucm_item_id`),
  KEY `idx_ucm_type_id` (`ucm_type_id`),
  KEY `idx_ucm_language_id` (`ucm_language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_ucm_content`
--

CREATE TABLE IF NOT EXISTS `g2q6h_ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(255) NOT NULL,
  `core_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `core_body` mediumtext NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` text NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` text NOT NULL,
  `core_urls` text NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text NOT NULL,
  `core_metadesc` text NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_alias` (`core_alias`),
  KEY `idx_language` (`core_language`),
  KEY `idx_title` (`core_title`),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_content_type` (`core_type_alias`),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Contains core content data in name spaced fields' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_ucm_history`
--

CREATE TABLE IF NOT EXISTS `g2q6h_ucm_history` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` mediumtext NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep',
  PRIMARY KEY (`version_id`),
  KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  KEY `idx_save_date` (`save_date`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `g2q6h_ucm_history`
--

INSERT INTO `g2q6h_ucm_history` (`version_id`, `ucm_item_id`, `ucm_type_id`, `version_note`, `save_date`, `editor_user_id`, `character_count`, `sha1_hash`, `version_data`, `keep_forever`) VALUES
(1, 1, 1, '', '2015-05-11 09:55:56', 401, 2491, '9912d72e8f4e9b5b6b1b988e6cd830d38bd8292a', '{"id":1,"asset_id":57,"title":"Homepage article","alias":"homepage-article","introtext":"<h2>HELE DANMARKS D\\u00c6KCENTER - <a><span class=\\"highlite\\">WWW.D\\u00c6KCENTER.NU<\\/span><\\/a> SOMMERD\\u00c6K - VINTERD\\u00c6K - F\\u00c6LGE<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet consectetuer adipiscing elit donec odio quisque volutpat mattis eros nullam malesuada erat ut turpis suspendisse urna nibh viverra non semper suscipit posuere a pede donec nec justo eget felis facilisis fermentum aliquam porttitor mauris sit amet orci aenean dignissim pellentesque felis morbi in sem quis dui placerat ornare pellentesque odio nisi, euismod in pharetra a ultricies in diam sed arcu cras consequat lorem ipsum dolor sit amet.<\\/p>\\r\\n<p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing commodo quis gravida id, est sed lectus.<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-11 09:55:56","created_by":"401","created_by_alias":"","modified":"2015-05-11 09:55:56","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-11 09:55:56","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(2, 1, 1, '', '2015-05-11 10:00:39', 401, 2445, 'b81479f4c30999224a415153ed4d5d12e13f8316', '{"id":1,"asset_id":"57","title":"Homepage article","alias":"homepage-article","introtext":"HELE DANMARKS D\\u00c6KCENTER - <a>WWW.D\\u00c6KCENTER.NU<\\/a> SOMMERD\\u00c6K - VINTERD\\u00c6K - F\\u00c6LGE Lorem ipsum dolor sit amet consectetuer adipiscing elit donec odio quisque volutpat mattis eros nullam malesuada erat ut turpis suspendisse urna nibh viverra non semper suscipit posuere a pede donec nec justo eget felis facilisis fermentum aliquam porttitor mauris sit amet orci aenean dignissim pellentesque felis morbi in sem quis dui placerat ornare pellentesque odio nisi, euismod in pharetra a ultricies in diam sed arcu cras consequat lorem ipsum dolor sit amet. Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing commodo quis gravida id, est sed lectus.","fulltext":"","state":1,"catid":"2","created":"2015-05-11 09:55:56","created_by":"401","created_by_alias":"","modified":"2015-05-11 10:00:39","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-11 09:59:32","publish_up":"2015-05-11 09:55:56","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(3, 1, 1, '', '2015-05-11 11:28:39', 401, 2485, 'c4b8ffaddd8956c834dd4e6327c7fd1229cc93af', '{"id":1,"asset_id":"57","title":"Homepage article","alias":"homepage-article","introtext":"<h2>HELE DANMARKS D\\u00c6KCENTER - <a href=\\"index.php\\">WWW.D\\u00c6KCENTER.NU<\\/a> SOMMERD\\u00c6K - VINTERD\\u00c6K - F\\u00c6LGE<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet consectetuer adipiscing elit donec odio quisque volutpat mattis eros nullam malesuada erat ut turpis suspendisse urna nibh viverra non semper suscipit posuere a pede donec nec justo eget felis facilisis fermentum aliquam porttitor mauris sit amet orci aenean dignissim pellentesque felis morbi in sem quis dui placerat ornare pellentesque odio nisi, euismod in pharetra a ultricies in diam sed arcu cras consequat lorem ipsum dolor sit amet. Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing commodo quis gravida id, est sed lectus.<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-11 09:55:56","created_by":"401","created_by_alias":"","modified":"2015-05-11 11:28:39","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-11 11:22:34","publish_up":"2015-05-11 09:55:56","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":3,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(4, 1, 1, '', '2015-05-11 11:29:58', 401, 2518, 'e4ff63cc8870923f67167638149833b0c44dafe3', '{"id":1,"asset_id":"57","title":"Homepage article","alias":"homepage-article","introtext":"<h2>HELE DANMARKS D\\u00c6KCENTER - <a href=\\"index.php\\"><span class=\\"highlite\\">WWW.D\\u00c6KCENTER.NU<\\/span><\\/a> SOMMERD\\u00c6K - VINTERD\\u00c6K - F\\u00c6LGE<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet consectetuer adipiscing elit donec odio quisque volutpat mattis eros nullam malesuada erat ut turpis suspendisse urna nibh viverra non semper suscipit posuere a pede donec nec justo eget felis facilisis fermentum aliquam porttitor mauris sit amet orci aenean dignissim pellentesque felis morbi in sem quis dui placerat ornare pellentesque odio nisi, euismod in pharetra a ultricies in diam sed arcu cras consequat lorem ipsum dolor sit amet. Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing commodo quis gravida id, est sed lectus.<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-11 09:55:56","created_by":"401","created_by_alias":"","modified":"2015-05-11 11:29:58","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-11 11:28:39","publish_up":"2015-05-11 09:55:56","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":4,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(5, 2, 5, '', '2015-05-11 11:53:08', 401, 593, 'eb779bda40cc6d103cf93c55e27bc4745d7052c0', '{"id":2,"asset_id":"27","parent_id":"1","lft":"1","rgt":"2","level":"1","path":"uncategorised","extension":"com_content","title":"Information","alias":"uncategorised","note":"","description":"","published":"1","checked_out":"401","checked_out_time":"2015-05-11 11:52:57","access":"1","params":"{\\"category_layout\\":\\"\\",\\"image\\":\\"\\",\\"image_alt\\":\\"\\"}","metadesc":"","metakey":"","metadata":"{\\"author\\":\\"\\",\\"robots\\":\\"\\"}","created_user_id":"42","created_time":"2011-01-01 00:00:01","modified_user_id":"401","modified_time":"2015-05-11 11:53:08","hits":"0","language":"*","version":"1"}', 0),
(6, 2, 1, '', '2015-05-11 11:56:09', 401, 8754, '18205e5de6ed95980ad2c0c1ff8728095d29c296', '{"id":2,"asset_id":58,"title":"Teknisk info \\u2013 D\\u00e6k","alias":"teknisk-info-daek","introtext":"<h1>TEKNISK INFO - D\\u00c6K<\\/h1>\\r\\n<p><img src=\\"..\\/images\\/banners\\/daekinfo.jpg\\" alt=\\"daekinfo\\" width=\\"300\\" height=\\"297\\" \\/><br \\/>D\\u00e6ksidem\\u00e6rkning:<br \\/><br \\/>D\\u00e6kside m\\u00e6rkning p\\u00e5 et d\\u00e6k indeholder oplysninger om d\\u00e6kkets design og produktion.<\\/p>\\r\\n<h3>1. Producent\\/m\\u00e6rke<\\/h3>\\r\\n<p>Her st\\u00e5r producentens navn, fx Michelin, Goodyear, Vredestein, Apollo, Nokian m.fl.<\\/p>\\r\\n<h3>2. D\\u00e6kmodel\\/m\\u00f8nster<\\/h3>\\r\\n<p>Navn p\\u00e5 model eller m\\u00f8nster. Fx. Sport, Pilot, Eagle m.fl.<\\/p>\\r\\n<h3>3. D\\u00e6kst\\u00f8rrelse<\\/h3>\\r\\n<p>D\\u00e6kst\\u00f8rrelsen er den vigtigste information som findes p\\u00e5 d\\u00e6kket. St\\u00f8rrelsen er angivet som en serie tal og bogstaver, som fx. 205\\/55R16,<\\/p>\\r\\n<p><b>205<\\/b> = d\\u00e6kkets bredde i mm.<br \\/> <b>55<\\/b> = d\\u00e6kkets h\\u00f8jde i procent af bredden som her er 55% af 205mm,<br \\/> <b>R<\\/b> = radiald\\u00e6k, som er det mest almindelige d\\u00e6k til almindelige biler i dag. <br \\/> <b>16\\"<\\/b> = st\\u00f8rrelsen p\\u00e5 de f\\u00e6lge (i tommer) som passer til d\\u00e6kket<\\/p>\\r\\n<h3>4. Belastningsindeks<\\/h3>\\r\\n<p>Belastningsindekset er et indeks som angiver den maksimale v\\u00e6gt som d\\u00e6kket kan b\\u00e6re ved den hastighed, der svarer til hastighedsindekset. I dette eksempel 91, som svarer til 615 kg. pr d\\u00e6k. Bem\\u00e6rk at den maksimale belastning er ved korrekt d\\u00e6ktryk.<\\/p>\\r\\n<p><img src=\\"..\\/images\\/stories\\/10.png\\" alt=\\"\\" \\/><\\/p>\\r\\n<h3>4. Hastighedindeks<\\/h3>\\r\\n<p>Hastigehdsindekset angiver den maksimale hastigehd, ved hvilken d\\u00e6kket kan b\\u00e6re en vis belastning (svarende til belastningsindekset). Tjek og f\\u00f8lg altid bilens manual for at finde ud af hvilken hastighedskode der bedst passer til bilsen. Det er generelt en god id\\u00e9 at alle d\\u00e6k har samme hastigehdskode. Det kan ogs\\u00e5 v\\u00e6re klogt at have d\\u00e6k med samme hastighedskode som de d\\u00e6k der oprindelig var monteret p\\u00e5 bilen. Skal du have skiftet bare et enkelt d\\u00e6k p\\u00e5 bilen, er det vigtigt at k\\u00f8be d\\u00e6k med mindst den samme tophastighed eller h\\u00f8jere.<\\/p>\\r\\n<p>Med hensyn til vinterd\\u00e6k er det acceptabelt at s\\u00e6tte d\\u00e6k med lavere hastighedskode p\\u00e5. Men det er dog p\\u00e5 bekostning af din fart ogs\\u00e5 bliver sat ned.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p>\\u00a0<img src=\\"..\\/images\\/stories\\/11.png\\" alt=\\"\\" \\/><\\/p>\\r\\n<p>Vinterd\\u00e6k har som regel lavere hastighedsindeks end hvad et sommerd\\u00e6k har, og det er tildels fordi vinterd\\u00e6k har et grovere m\\u00f8nser og er lavet af en bl\\u00f8dere gummi, med det resultat at d\\u00e6kket bliver ustabilt ved h\\u00f8je hastigheder.<\\/p>\\r\\n<h3>5. E-m\\u00e6rkning<\\/h3>\\r\\n<p>D\\u00e6kket skal ogs\\u00e5 have en E-m\\u00e6rkning. ECE Regulativ 30, som indikerer at d\\u00e6kket lever op til de g\\u00e6ldende Europ\\u00e6iske krav.<\\/p>\\r\\n<h3>6. Godkendelses nummer for st\\u00f8jegenskaber<\\/h3>\\r\\n<p>Det betyder, at d\\u00e6kket lever op til de Europ\\u00e6iske krav om begr\\u00e6nsning af st\\u00f8j fra d\\u00e6k.<\\/p>\\r\\n<h3>7. DOT nummer<\\/h3>\\r\\n<p>DOT nummer for det amerikanske marked. Det har ingen betydning for Europa.<\\/p>\\r\\n<h3>8. Produktionsdato<\\/h3>\\r\\n<p>Produktionsdatoen kan let findes ved at unders\\u00f8ge serienummeret p\\u00e5 d\\u00e6kkets sidev\\u00e6g (8).\\u00a0Serienummeret er en alfanummerisk kode best\\u00e5ende af 11 tegn, der s\\u00e6dvanligvis, men ikke altid, f\\u00f8lger efter akronymet \\"DOT\\" (se herover). De sidste fire cifre i dette nummer refererer til produktionsdatoen.<\\/p>\\r\\n<p>De f\\u00f8rste\\u00a0to cifre angiver produktionsugen (inden for omr\\u00e5det 01 til 52), mens de sidste to cifre angiver produktions\\u00e5ret\\u00a0fx. 4500 = uge 45 i 2000.<\\/p>\\r\\n<p>For d\\u00e6k produceret inden \\u00e5r 2000 angives produktions\\u00e5ret med 1 tal i stedet for 2 (dvs. 189 angiver uge 18 i \\u00e5r 1999). I ti\\u00e5ret 1990-2000 blev nogle d\\u00e6k m\\u00e6rket med en trekant, der pegede p\\u00e5 de sidste cifre i serienummeret for at adskille dem fra d\\u00e6k\\u00a0produceret i tidligere ti\\u00e5r.<\\/p>\\r\\n<p>Produktionsdatoen er vigtig, fordi et d\\u00e6k er sammensat af forskellige typer materiale og gummibalndinger med forskellige egenskaber, som forandres med tiden. For enkelte d\\u00e6k afh\\u00e6nger denne forandring af mange elementer som fx vejret, opbevaringsforhold og anvendelsesbetingelser, som d\\u00e6kket uds\\u00e6ttes for igennem sin levetid. Denne brugsrelaterede forandring varierer betydeligt, s\\u00e5ledes at en n\\u00f8jagtig prognose for levetiden p\\u00e5 et bestemt d\\u00e6k ikke er muligt p\\u00e5 forh\\u00e5nd.<\\/p>\\r\\n<p>Generelt g\\u00e6lder dog, at jo \\u00e6ldre et d\\u00e6k er, jo st\\u00f8rre er risikoen imidlertid for, at der er behov for at f\\u00e5 det udskiftet som f\\u00f8lge af brugsrelateret forandring. Et d\\u00e6k der har v\\u00e6ret i brug i 5 \\u00e5r eller mere b\\u00f8r inspiceres mindst en gang om \\u00e5ret. De fleste d\\u00e6k vil af naturlige \\u00e5rsager skulle udskiftes, inden de bliver 10 \\u00e5r gamle, og det anbefales, at alle d\\u00e6k, som stadig er i brug mere end 10 \\u00e5r efter produktionsdatoen, herunder ogs\\u00e5 d\\u00e6k p\\u00e5 reservehjul, udskiftes med nye d\\u00e6k, som en simpel forebyggelse. D\\u00e6k m\\u00e5 helst ikke v\\u00e6re mere 6 \\u00e5r gamle.<\\/p>\\r\\n<h3><br \\/> 9.\\u00a0\\u00a0Amerikansk egenskabsm\\u00e6rkning<\\/h3>\\r\\n<p>En s\\u00e6rlig\\u00a0amerikansk m\\u00e6rkning om d\\u00e6kkets egenskaber. Det har ingen betydning for Europa.<\\/p>\\r\\n<h3>10. Amerikansk belastningsm\\u00e6rkning<\\/h3>\\r\\n<p>En s\\u00e6rlig\\u00a0amerikansk m\\u00e6rkning om belastning. Det har ingen betydning for Europa. (For Europa se under pkt.4)<\\/p>\\r\\n<h3>11. Max d\\u00e6ktryk<\\/h3>\\r\\n<p>Fabrikantens max anbefalede d\\u00e6ktryk, har bla. betydning for k\\u00f8ret\\u00f8jer over ca. 2ton. Det er dette d\\u00e6ktryk som en camper skal have i d\\u00e6kkerne.\\u00a0<\\/p>\\r\\n<h3>12. Slangel\\u00f8st d\\u00e6k<\\/h3>\\r\\n<p>Et m\\u00e6rke der angiver at d\\u00e6kket er slangel\\u00f8st.<\\/p>\\r\\n<h3>13. Amerikansk d\\u00e6ktryk m\\u00e6rkning<\\/h3>\\r\\n<p>\\u00a0En s\\u00e6rlig\\u00a0amerikansk m\\u00e6rkning, der advarer om forkert d\\u00e6ktryk, og de f\\u00f8lger det kan medf\\u00f8re. Det har ingen betydning for Europa.<\\/p>\\r\\n<h3>14. Rotationsretning<\\/h3>\\r\\n<p>Pilen angiver d\\u00e6kkets rotations retning.<\\/p>\\r\\n<h3>15. Assymetriske d\\u00e6k<\\/h3>\\r\\n<p>Asymmetriske d\\u00e6k har en m\\u00e6rkning, der angiver hvilken side der skal vende udad.<\\/p>\\r\\n<h3>16. Forst\\u00e6rket<\\/h3>\\r\\n<p>Angivelse der viser, at d\\u00e6kket kan t\\u00e5le ekstra belastning (reinforced).<\\/p>\\r\\n<h3>17.\\u00a0Slidbaneindikator<\\/h3>\\r\\n<p>TWI er angivet 6 steder rundt p\\u00e5 d\\u00e6kket og viser hvor slidindikatorerne findes i bunden af m\\u00f8nsteret.<\\/p>\\r\\n<h3>18. Mud and snow<\\/h3>\\r\\n<p>P\\u00e5 d\\u00e6ksiden kan der yderligere v\\u00e6re p\\u00e5f\\u00f8rt \\"M+S\\", hvilket st\\u00e5r for \\"Mud and snow\\" eller p\\u00e5 dansk \\"Mudder og sne\\". Dette indikerer at d\\u00e6kket er et vinterd\\u00e6k eller et hel\\u00e5rsd\\u00e6k.<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-11 11:56:09","created_by":"401","created_by_alias":"","modified":"2015-05-11 11:56:09","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-11 11:56:09","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(7, 2, 1, '', '2015-05-11 12:04:15', 401, 8792, '33d6ff16155ec343445d8d6480deb3e04a54e40a', '{"id":2,"asset_id":"58","title":"Teknisk info \\u2013 D\\u00e6k","alias":"teknisk-info-daek","introtext":"<h1>TEKNISK INFO - D\\u00c6K<\\/h1>\\r\\n<p><img src=\\"images\\/daekinfo.jpg\\" alt=\\"daekinfo\\" width=\\"300\\" height=\\"297\\" \\/><br \\/>D\\u00e6ksidem\\u00e6rkning:<br \\/><br \\/>D\\u00e6kside m\\u00e6rkning p\\u00e5 et d\\u00e6k indeholder oplysninger om d\\u00e6kkets design og produktion.<\\/p>\\r\\n<h3>1. Producent\\/m\\u00e6rke<\\/h3>\\r\\n<p>Her st\\u00e5r producentens navn, fx Michelin, Goodyear, Vredestein, Apollo, Nokian m.fl.<\\/p>\\r\\n<h3>2. D\\u00e6kmodel\\/m\\u00f8nster<\\/h3>\\r\\n<p>Navn p\\u00e5 model eller m\\u00f8nster. Fx. Sport, Pilot, Eagle m.fl.<\\/p>\\r\\n<h3>3. D\\u00e6kst\\u00f8rrelse<\\/h3>\\r\\n<p>D\\u00e6kst\\u00f8rrelsen er den vigtigste information som findes p\\u00e5 d\\u00e6kket. St\\u00f8rrelsen er angivet som en serie tal og bogstaver, som fx. 205\\/55R16,<\\/p>\\r\\n<p><b>205<\\/b> = d\\u00e6kkets bredde i mm.<br \\/> <b>55<\\/b> = d\\u00e6kkets h\\u00f8jde i procent af bredden som her er 55% af 205mm,<br \\/> <b>R<\\/b> = radiald\\u00e6k, som er det mest almindelige d\\u00e6k til almindelige biler i dag. <br \\/> <b>16\\"<\\/b> = st\\u00f8rrelsen p\\u00e5 de f\\u00e6lge (i tommer) som passer til d\\u00e6kket<\\/p>\\r\\n<h3>4. Belastningsindeks<\\/h3>\\r\\n<p>Belastningsindekset er et indeks som angiver den maksimale v\\u00e6gt som d\\u00e6kket kan b\\u00e6re ved den hastighed, der svarer til hastighedsindekset. I dette eksempel 91, som svarer til 615 kg. pr d\\u00e6k. Bem\\u00e6rk at den maksimale belastning er ved korrekt d\\u00e6ktryk.<\\/p>\\r\\n<p><img src=\\"images\\/10.png\\" alt=\\"\\" width=\\"732\\" height=\\"789\\" \\/><\\/p>\\r\\n<h3>4. Hastighedindeks<\\/h3>\\r\\n<p>Hastigehdsindekset angiver den maksimale hastigehd, ved hvilken d\\u00e6kket kan b\\u00e6re en vis belastning (svarende til belastningsindekset). Tjek og f\\u00f8lg altid bilens manual for at finde ud af hvilken hastighedskode der bedst passer til bilsen. Det er generelt en god id\\u00e9 at alle d\\u00e6k har samme hastigehdskode. Det kan ogs\\u00e5 v\\u00e6re klogt at have d\\u00e6k med samme hastighedskode som de d\\u00e6k der oprindelig var monteret p\\u00e5 bilen. Skal du have skiftet bare et enkelt d\\u00e6k p\\u00e5 bilen, er det vigtigt at k\\u00f8be d\\u00e6k med mindst den samme tophastighed eller h\\u00f8jere.<\\/p>\\r\\n<p>Med hensyn til vinterd\\u00e6k er det acceptabelt at s\\u00e6tte d\\u00e6k med lavere hastighedskode p\\u00e5. Men det er dog p\\u00e5 bekostning af din fart ogs\\u00e5 bliver sat ned.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p>\\u00a0<img src=\\"images\\/11.png\\" alt=\\"\\" width=\\"417\\" height=\\"363\\" \\/><\\/p>\\r\\n<p>Vinterd\\u00e6k har som regel lavere hastighedsindeks end hvad et sommerd\\u00e6k har, og det er tildels fordi vinterd\\u00e6k har et grovere m\\u00f8nser og er lavet af en bl\\u00f8dere gummi, med det resultat at d\\u00e6kket bliver ustabilt ved h\\u00f8je hastigheder.<\\/p>\\r\\n<h3>5. E-m\\u00e6rkning<\\/h3>\\r\\n<p>D\\u00e6kket skal ogs\\u00e5 have en E-m\\u00e6rkning. ECE Regulativ 30, som indikerer at d\\u00e6kket lever op til de g\\u00e6ldende Europ\\u00e6iske krav.<\\/p>\\r\\n<h3>6. Godkendelses nummer for st\\u00f8jegenskaber<\\/h3>\\r\\n<p>Det betyder, at d\\u00e6kket lever op til de Europ\\u00e6iske krav om begr\\u00e6nsning af st\\u00f8j fra d\\u00e6k.<\\/p>\\r\\n<h3>7. DOT nummer<\\/h3>\\r\\n<p>DOT nummer for det amerikanske marked. Det har ingen betydning for Europa.<\\/p>\\r\\n<h3>8. Produktionsdato<\\/h3>\\r\\n<p>Produktionsdatoen kan let findes ved at unders\\u00f8ge serienummeret p\\u00e5 d\\u00e6kkets sidev\\u00e6g (8).\\u00a0Serienummeret er en alfanummerisk kode best\\u00e5ende af 11 tegn, der s\\u00e6dvanligvis, men ikke altid, f\\u00f8lger efter akronymet \\"DOT\\" (se herover). De sidste fire cifre i dette nummer refererer til produktionsdatoen.<\\/p>\\r\\n<p>De f\\u00f8rste\\u00a0to cifre angiver produktionsugen (inden for omr\\u00e5det 01 til 52), mens de sidste to cifre angiver produktions\\u00e5ret\\u00a0fx. 4500 = uge 45 i 2000.<\\/p>\\r\\n<p>For d\\u00e6k produceret inden \\u00e5r 2000 angives produktions\\u00e5ret med 1 tal i stedet for 2 (dvs. 189 angiver uge 18 i \\u00e5r 1999). I ti\\u00e5ret 1990-2000 blev nogle d\\u00e6k m\\u00e6rket med en trekant, der pegede p\\u00e5 de sidste cifre i serienummeret for at adskille dem fra d\\u00e6k\\u00a0produceret i tidligere ti\\u00e5r.<\\/p>\\r\\n<p>Produktionsdatoen er vigtig, fordi et d\\u00e6k er sammensat af forskellige typer materiale og gummibalndinger med forskellige egenskaber, som forandres med tiden. For enkelte d\\u00e6k afh\\u00e6nger denne forandring af mange elementer som fx vejret, opbevaringsforhold og anvendelsesbetingelser, som d\\u00e6kket uds\\u00e6ttes for igennem sin levetid. Denne brugsrelaterede forandring varierer betydeligt, s\\u00e5ledes at en n\\u00f8jagtig prognose for levetiden p\\u00e5 et bestemt d\\u00e6k ikke er muligt p\\u00e5 forh\\u00e5nd.<\\/p>\\r\\n<p>Generelt g\\u00e6lder dog, at jo \\u00e6ldre et d\\u00e6k er, jo st\\u00f8rre er risikoen imidlertid for, at der er behov for at f\\u00e5 det udskiftet som f\\u00f8lge af brugsrelateret forandring. Et d\\u00e6k der har v\\u00e6ret i brug i 5 \\u00e5r eller mere b\\u00f8r inspiceres mindst en gang om \\u00e5ret. De fleste d\\u00e6k vil af naturlige \\u00e5rsager skulle udskiftes, inden de bliver 10 \\u00e5r gamle, og det anbefales, at alle d\\u00e6k, som stadig er i brug mere end 10 \\u00e5r efter produktionsdatoen, herunder ogs\\u00e5 d\\u00e6k p\\u00e5 reservehjul, udskiftes med nye d\\u00e6k, som en simpel forebyggelse. D\\u00e6k m\\u00e5 helst ikke v\\u00e6re mere 6 \\u00e5r gamle.<\\/p>\\r\\n<h3><br \\/> 9.\\u00a0\\u00a0Amerikansk egenskabsm\\u00e6rkning<\\/h3>\\r\\n<p>En s\\u00e6rlig\\u00a0amerikansk m\\u00e6rkning om d\\u00e6kkets egenskaber. Det har ingen betydning for Europa.<\\/p>\\r\\n<h3>10. Amerikansk belastningsm\\u00e6rkning<\\/h3>\\r\\n<p>En s\\u00e6rlig\\u00a0amerikansk m\\u00e6rkning om belastning. Det har ingen betydning for Europa. (For Europa se under pkt.4)<\\/p>\\r\\n<h3>11. Max d\\u00e6ktryk<\\/h3>\\r\\n<p>Fabrikantens max anbefalede d\\u00e6ktryk, har bla. betydning for k\\u00f8ret\\u00f8jer over ca. 2ton. Det er dette d\\u00e6ktryk som en camper skal have i d\\u00e6kkerne.\\u00a0<\\/p>\\r\\n<h3>12. Slangel\\u00f8st d\\u00e6k<\\/h3>\\r\\n<p>Et m\\u00e6rke der angiver at d\\u00e6kket er slangel\\u00f8st.<\\/p>\\r\\n<h3>13. Amerikansk d\\u00e6ktryk m\\u00e6rkning<\\/h3>\\r\\n<p>\\u00a0En s\\u00e6rlig\\u00a0amerikansk m\\u00e6rkning, der advarer om forkert d\\u00e6ktryk, og de f\\u00f8lger det kan medf\\u00f8re. Det har ingen betydning for Europa.<\\/p>\\r\\n<h3>14. Rotationsretning<\\/h3>\\r\\n<p>Pilen angiver d\\u00e6kkets rotations retning.<\\/p>\\r\\n<h3>15. Assymetriske d\\u00e6k<\\/h3>\\r\\n<p>Asymmetriske d\\u00e6k har en m\\u00e6rkning, der angiver hvilken side der skal vende udad.<\\/p>\\r\\n<h3>16. Forst\\u00e6rket<\\/h3>\\r\\n<p>Angivelse der viser, at d\\u00e6kket kan t\\u00e5le ekstra belastning (reinforced).<\\/p>\\r\\n<h3>17.\\u00a0Slidbaneindikator<\\/h3>\\r\\n<p>TWI er angivet 6 steder rundt p\\u00e5 d\\u00e6kket og viser hvor slidindikatorerne findes i bunden af m\\u00f8nsteret.<\\/p>\\r\\n<h3>18. Mud and snow<\\/h3>\\r\\n<p>P\\u00e5 d\\u00e6ksiden kan der yderligere v\\u00e6re p\\u00e5f\\u00f8rt \\"M+S\\", hvilket st\\u00e5r for \\"Mud and snow\\" eller p\\u00e5 dansk \\"Mudder og sne\\". Dette indikerer at d\\u00e6kket er et vinterd\\u00e6k eller et hel\\u00e5rsd\\u00e6k.<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-11 11:56:09","created_by":"401","created_by_alias":"","modified":"2015-05-11 12:04:15","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-11 12:03:16","publish_up":"2015-05-11 11:56:09","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"1","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(8, 3, 1, '', '2015-05-12 13:49:56', 401, 7965, '338a339a19a0bbd5f0b01de4bc6491411dbc0c6f', '{"id":3,"asset_id":60,"title":"Teknisk info \\u2013 F\\u00e6lge","alias":"teknisk-info-faelge","introtext":"<h1>Teknisk info - F\\u00e6lge<\\/h1>\\r\\n<p>Der er to hovedtyper af f\\u00e6lge, st\\u00e5lf\\u00e6lge og letmetalsf\\u00e6lge (s\\u00e5kaldte aluf\\u00e6lge). St\\u00e5f\\u00e6lgen er den mest almindelige og er monteret som standard p\\u00e5 de fleste k\\u00f8ret\\u00f8jer. Letmetalsf\\u00e6lge er blevet meget almindelig idag, og er monteret som orginal p\\u00e5 mange k\\u00f8ret\\u00f8jer. Ofte anvendes de til at opn\\u00e5 \\u00e6rlige egenskaber, fordi de er lidt lettere og mere b\\u00e6redygtige. Den mest almindelig \\u00e5rsag til at skifte til letmetalsf\\u00e6lge er imidlertid, det rent \\u00e6stetiske. Du kan nemt bytte din st\\u00e5lf\\u00e6lg ud med en letmetalsf\\u00e6lg hvis du tager h\\u00f8jde for f\\u00e6lgens ET og boltcirkel.<\\/p>\\r\\n<h2>F\\u00e6lgens indpresningsdybde, ET-m\\u00e5l<\\/h2>\\r\\n<p>F\\u00e6lgens indpresningsdybde, eller ET-m\\u00e5l, viser, hvor langt inde eller ude f\\u00e6lgen sidder i forhold til f\\u00e6lgens midtpunkt.<\\/p>\\r\\n<p>Det er vigtigt at have den rigtige indpresningsdybde, da forkert indpresningsdybde kan f\\u00e5 hjulet til at r\\u00f8re ved sk\\u00e6rmens yderkant eller fjedre\\/st\\u00f8dd\\u00e6mpere. Hvilken indpr\\u00e6sningsdybde, du skal have, afh\\u00e6nger af hvor brede dine f\\u00e6lge er og hvor tore d\\u00e6kkene er, og naturligvis hvilken bil du har. Normalt st\\u00e5r indpresningsdybden stemplet p\\u00e5 f\\u00e6lgen. Jo h\\u00f8jere m\\u00e5l, desto dybere sidder f\\u00e6lgen.<\\/p>\\r\\n<h2>Boltcirkel<\\/h2>\\r\\n<p>Boltcirklen handler om hvor mange bolthul f\\u00e6lgen har og dens diameter. Boltcirklen angives som fx 4x110, hvilket betyder 4 bolte med 110 mm cirkeldiameter. Cirkeldiameter er et m\\u00e5l mellem to bolte m\\u00e5lt henover centerhullet (fremh\\u00e6vet med r\\u00f8dt). P\\u00e5 en 4-bolt f\\u00e6lg m\\u00e5ler du fra dit bolthuls yderkant til bolthullets inderste kant p\\u00e5 tv\\u00e6r af centerhullet. Forskellige biler har forskellige boltcirkler, hviklet betyder at en f\\u00e6lg ikke passer til alle biler.<\\/p>\\r\\n<p>P\\u00e5 en 5-boltsf\\u00e6lg m\\u00e5ler man boltcirklen ved f\\u00f8lgende:<\\/p>\\r\\n<ul>\\r\\n<li>M\\u00e5l hele bolthullets diameter (A)<\\/li>\\r\\n<li>M\\u00e5l fra bolthullets kant til navhullets kant (B)<\\/li>\\r\\n<li>M\\u00e5l navhullets diameter (C)<\\/li>\\r\\n<\\/ul>\\r\\n<p>Boltcirklens diameter = A + Bx2 + C<\\/p>\\r\\n<h2>F\\u00e6lgdimensioner<\\/h2>\\r\\n<p>F\\u00e6lge findes i mange forskellige st\\u00f8rrelser og varianter. N\\u00e5r man m\\u00e5ler f\\u00e6lge g\\u00f8re det i tommer. Her er et eksempel p\\u00e5 hvordan det kan se ud:<\\/p>\\r\\n<p>8Jx17<\\/p>\\r\\n<ul>\\r\\n<li>8 st\\u00e5r for f\\u00e6lgens bredde<\\/li>\\r\\n<li>J er typen af f\\u00e6lghorn<\\/li>\\r\\n<li>17 er f\\u00e6lgdiameter m\\u00e5lt i tommer.<\\/li>\\r\\n<\\/ul>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p>N\\u00e5r man v\\u00e6lger aluf\\u00e6lge, skal man tage stilling til flere forskellige ting. Et af de f\\u00f8rste er, om f\\u00e6lgene skal v\\u00e6re st\\u00f8rre end de originale. Ved montering af f\\u00e6lge med st\\u00f8rre diameter, monterer man samtidig d\\u00e6k med en lavere profil. Det vil sige, at n\\u00e5r diameteren p\\u00e5 f\\u00e6lgen bliver st\\u00f8rre, mindsker man h\\u00f8jden p\\u00e5 d\\u00e6ksiden tilsvarende. Derved bevarer man samme omkreds p\\u00e5 hjulet.<\\/p>\\r\\n<p>Generelt kan man sige, at jo st\\u00f8rre f\\u00e6lgene er, jo bedre ser det ud p\\u00e5 bilen. Desv\\u00e6rre er det ogs\\u00e5 s\\u00e5dan, at prisen stiger sammen med f\\u00e6lgst\\u00f8rrelsen. Til en bestemt st\\u00f8rrelse f\\u00e6lge, er det tit muligt at montere d\\u00e6k med forskellig bredde. I valget af d\\u00e6kbredde indg\\u00e5r der flere overvejelser. F.eks. plads i hjulkassen, f\\u00e6lgbredde samt pris.<\\/p>\\r\\n<p>N\\u00e5r man monterer aluf\\u00e6lge p\\u00e5 sin bil, skal man v\\u00e6re opm\\u00e6rksom p\\u00e5, at der b\\u00e5de er fordele og ulemper i forhold til almindelige st\\u00e5lf\\u00e6lge<\\/p>\\r\\n<p><strong style=\\"margin: 0px; padding: 0px;\\">Fordele ved aluf\\u00e6lge<\\/strong>:<\\/p>\\r\\n<p>\\u2022 Det ser godt ud. Langt de fleste k\\u00f8ber aluf\\u00e6lge for at give bilen et flottere udseende<\\/p>\\r\\n<p>\\u2022 Der er mulighed for at montere bredere d\\u00e6k p\\u00e5 bilen<\\/p>\\r\\n<p>\\u2022 Der er mulighed for at montere st\\u00f8rre f\\u00e6lge og dermed lavere d\\u00e6k<\\/p>\\r\\n<p><strong style=\\"margin: 0px; padding: 0px;\\">Fordele ved st\\u00e5lf\\u00e6lge:<\\/strong><\\/p>\\r\\n<p>\\u2022 St\\u00e5lf\\u00e6lge kr\\u00e6ver lidt mindre reng\\u00f8ring end aluf\\u00e6lge<\\/p>\\r\\n<p>\\u2022 Med lavprofild\\u00e6k kan der v\\u00e6re fordele med st\\u00e5lf\\u00e6lge, idet aluf\\u00e6lge kan betyde en st\\u00f8rre risiko for at skrabe f\\u00e6lgkanterne med kantsten<\\/p>\\r\\n<p>Ved montering af aluf\\u00e6lge, skal man huske at eftersp\\u00e6nde dem efter 50 - 100 km. og igen efter 400 - 500 km. Dette er is\\u00e6r vigtigt ved helt nye f\\u00e6lge, da det nye aluminium godt kan \\"arbejde\\" lidt. Hjulboltene skal sp\\u00e6ndes krydsvis med et moment p\\u00e5 100 nm. (g\\u00e6lder for de fleste biler). Har du k\\u00f8bt aluf\\u00e6lge hos os, kan du naturligvis bare komme forbi, s\\u00e5 eftersp\\u00e6nder vi hjulene.<\\/p>\\r\\n<p>N\\u00e5r man monterer andre f\\u00e6lge p\\u00e5 en bil, er der nogle krav, som skal v\\u00e6re opfyldt, for at det er lovligt<\\/p>\\r\\n<p>Sporvidde I Danmark er det lovligt, uden nogen form for dokumentation, at for\\u00f8ge en bil''s sporvidde med 20 mm (10 mm. pr. side). Man skal dog v\\u00e6re opm\\u00e6rksom p\\u00e5, at man regner ud fra den mindste sporvidde, som er anf\\u00f8rt p\\u00e5 bilens standardtypegodkendelsesattest. Dvs. at bilen kan v\\u00e6re godkendt med flere forskellige f\\u00e6lge, som hver is\\u00e6r giver bilen forskellige sporvidder. Her benytter man s\\u00e5 f\\u00e6lgen med den mindste sporvidde som udgangspunkt. Hvis en given f\\u00e6lg giver en endnu st\\u00f8rre sporviddefor\\u00f8gelse, eller hvis sporvidden formindskes, kan f\\u00e6lgen stadig godt v\\u00e6re lovlig, hvis der foreligger en T\\u00dcV-attest som dokumentation.<\\/p>\\r\\n<p>Udover sporvidden, skal de nye hjul ogs\\u00e5 overholde sk\\u00e6rmreglementet for at v\\u00e6re lovlige. Det betyder, at hele hjulet skal v\\u00e6re indenfor sk\\u00e6rmen inkl. d\\u00e6ksidens runding. Hvis dette ikke er opfyldt, vil hjulet ikke v\\u00e6re lovligt, uanset om de er lovlige med hensyn til sporvidde. Vores ekspedienter vil kunne vejlede dig omkring reglerne i forhold til netop din bil.<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 13:49:56","created_by":"401","created_by_alias":"","modified":"2015-05-12 13:49:56","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 13:49:56","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(9, 3, 1, '', '2015-05-12 14:41:59', 401, 7945, '4c61682ae728c2b0d4bf2516f9d6b8fb58a1b678', '{"id":3,"asset_id":"60","title":"Teknisk info \\u2013 F\\u00e6lge","alias":"teknisk-info-faelge","introtext":"<p>Der er to hovedtyper af f\\u00e6lge, st\\u00e5lf\\u00e6lge og letmetalsf\\u00e6lge (s\\u00e5kaldte aluf\\u00e6lge). St\\u00e5f\\u00e6lgen er den mest almindelige og er monteret som standard p\\u00e5 de fleste k\\u00f8ret\\u00f8jer. Letmetalsf\\u00e6lge er blevet meget almindelig idag, og er monteret som orginal p\\u00e5 mange k\\u00f8ret\\u00f8jer. Ofte anvendes de til at opn\\u00e5 \\u00e6rlige egenskaber, fordi de er lidt lettere og mere b\\u00e6redygtige. Den mest almindelig \\u00e5rsag til at skifte til letmetalsf\\u00e6lge er imidlertid, det rent \\u00e6stetiske. Du kan nemt bytte din st\\u00e5lf\\u00e6lg ud med en letmetalsf\\u00e6lg hvis du tager h\\u00f8jde for f\\u00e6lgens ET og boltcirkel.<\\/p>\\r\\n<h2>F\\u00e6lgens indpresningsdybde, ET-m\\u00e5l<\\/h2>\\r\\n<p>F\\u00e6lgens indpresningsdybde, eller ET-m\\u00e5l, viser, hvor langt inde eller ude f\\u00e6lgen sidder i forhold til f\\u00e6lgens midtpunkt.<\\/p>\\r\\n<p>Det er vigtigt at have den rigtige indpresningsdybde, da forkert indpresningsdybde kan f\\u00e5 hjulet til at r\\u00f8re ved sk\\u00e6rmens yderkant eller fjedre\\/st\\u00f8dd\\u00e6mpere. Hvilken indpr\\u00e6sningsdybde, du skal have, afh\\u00e6nger af hvor brede dine f\\u00e6lge er og hvor tore d\\u00e6kkene er, og naturligvis hvilken bil du har. Normalt st\\u00e5r indpresningsdybden stemplet p\\u00e5 f\\u00e6lgen. Jo h\\u00f8jere m\\u00e5l, desto dybere sidder f\\u00e6lgen.<\\/p>\\r\\n<h2>Boltcirkel<\\/h2>\\r\\n<p>Boltcirklen handler om hvor mange bolthul f\\u00e6lgen har og dens diameter. Boltcirklen angives som fx 4x110, hvilket betyder 4 bolte med 110 mm cirkeldiameter. Cirkeldiameter er et m\\u00e5l mellem to bolte m\\u00e5lt henover centerhullet (fremh\\u00e6vet med r\\u00f8dt). P\\u00e5 en 4-bolt f\\u00e6lg m\\u00e5ler du fra dit bolthuls yderkant til bolthullets inderste kant p\\u00e5 tv\\u00e6r af centerhullet. Forskellige biler har forskellige boltcirkler, hviklet betyder at en f\\u00e6lg ikke passer til alle biler.<\\/p>\\r\\n<p>P\\u00e5 en 5-boltsf\\u00e6lg m\\u00e5ler man boltcirklen ved f\\u00f8lgende:<\\/p>\\r\\n<ul>\\r\\n<li>M\\u00e5l hele bolthullets diameter (A)<\\/li>\\r\\n<li>M\\u00e5l fra bolthullets kant til navhullets kant (B)<\\/li>\\r\\n<li>M\\u00e5l navhullets diameter (C)<\\/li>\\r\\n<\\/ul>\\r\\n<p>Boltcirklens diameter = A + Bx2 + C<\\/p>\\r\\n<h2>F\\u00e6lgdimensioner<\\/h2>\\r\\n<p>F\\u00e6lge findes i mange forskellige st\\u00f8rrelser og varianter. N\\u00e5r man m\\u00e5ler f\\u00e6lge g\\u00f8re det i tommer. Her er et eksempel p\\u00e5 hvordan det kan se ud:<\\/p>\\r\\n<p>8Jx17<\\/p>\\r\\n<ul>\\r\\n<li>8 st\\u00e5r for f\\u00e6lgens bredde<\\/li>\\r\\n<li>J er typen af f\\u00e6lghorn<\\/li>\\r\\n<li>17 er f\\u00e6lgdiameter m\\u00e5lt i tommer.<\\/li>\\r\\n<\\/ul>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p>N\\u00e5r man v\\u00e6lger aluf\\u00e6lge, skal man tage stilling til flere forskellige ting. Et af de f\\u00f8rste er, om f\\u00e6lgene skal v\\u00e6re st\\u00f8rre end de originale. Ved montering af f\\u00e6lge med st\\u00f8rre diameter, monterer man samtidig d\\u00e6k med en lavere profil. Det vil sige, at n\\u00e5r diameteren p\\u00e5 f\\u00e6lgen bliver st\\u00f8rre, mindsker man h\\u00f8jden p\\u00e5 d\\u00e6ksiden tilsvarende. Derved bevarer man samme omkreds p\\u00e5 hjulet.<\\/p>\\r\\n<p>Generelt kan man sige, at jo st\\u00f8rre f\\u00e6lgene er, jo bedre ser det ud p\\u00e5 bilen. Desv\\u00e6rre er det ogs\\u00e5 s\\u00e5dan, at prisen stiger sammen med f\\u00e6lgst\\u00f8rrelsen. Til en bestemt st\\u00f8rrelse f\\u00e6lge, er det tit muligt at montere d\\u00e6k med forskellig bredde. I valget af d\\u00e6kbredde indg\\u00e5r der flere overvejelser. F.eks. plads i hjulkassen, f\\u00e6lgbredde samt pris.<\\/p>\\r\\n<p>N\\u00e5r man monterer aluf\\u00e6lge p\\u00e5 sin bil, skal man v\\u00e6re opm\\u00e6rksom p\\u00e5, at der b\\u00e5de er fordele og ulemper i forhold til almindelige st\\u00e5lf\\u00e6lge<\\/p>\\r\\n<p><strong style=\\"margin: 0px; padding: 0px;\\">Fordele ved aluf\\u00e6lge<\\/strong>:<\\/p>\\r\\n<p>\\u2022 Det ser godt ud. Langt de fleste k\\u00f8ber aluf\\u00e6lge for at give bilen et flottere udseende<\\/p>\\r\\n<p>\\u2022 Der er mulighed for at montere bredere d\\u00e6k p\\u00e5 bilen<\\/p>\\r\\n<p>\\u2022 Der er mulighed for at montere st\\u00f8rre f\\u00e6lge og dermed lavere d\\u00e6k<\\/p>\\r\\n<p><strong style=\\"margin: 0px; padding: 0px;\\">Fordele ved st\\u00e5lf\\u00e6lge:<\\/strong><\\/p>\\r\\n<p>\\u2022 St\\u00e5lf\\u00e6lge kr\\u00e6ver lidt mindre reng\\u00f8ring end aluf\\u00e6lge<\\/p>\\r\\n<p>\\u2022 Med lavprofild\\u00e6k kan der v\\u00e6re fordele med st\\u00e5lf\\u00e6lge, idet aluf\\u00e6lge kan betyde en st\\u00f8rre risiko for at skrabe f\\u00e6lgkanterne med kantsten<\\/p>\\r\\n<p>Ved montering af aluf\\u00e6lge, skal man huske at eftersp\\u00e6nde dem efter 50 - 100 km. og igen efter 400 - 500 km. Dette er is\\u00e6r vigtigt ved helt nye f\\u00e6lge, da det nye aluminium godt kan \\"arbejde\\" lidt. Hjulboltene skal sp\\u00e6ndes krydsvis med et moment p\\u00e5 100 nm. (g\\u00e6lder for de fleste biler). Har du k\\u00f8bt aluf\\u00e6lge hos os, kan du naturligvis bare komme forbi, s\\u00e5 eftersp\\u00e6nder vi hjulene.<\\/p>\\r\\n<p>N\\u00e5r man monterer andre f\\u00e6lge p\\u00e5 en bil, er der nogle krav, som skal v\\u00e6re opfyldt, for at det er lovligt<\\/p>\\r\\n<p>Sporvidde I Danmark er det lovligt, uden nogen form for dokumentation, at for\\u00f8ge en bil''s sporvidde med 20 mm (10 mm. pr. side). Man skal dog v\\u00e6re opm\\u00e6rksom p\\u00e5, at man regner ud fra den mindste sporvidde, som er anf\\u00f8rt p\\u00e5 bilens standardtypegodkendelsesattest. Dvs. at bilen kan v\\u00e6re godkendt med flere forskellige f\\u00e6lge, som hver is\\u00e6r giver bilen forskellige sporvidder. Her benytter man s\\u00e5 f\\u00e6lgen med den mindste sporvidde som udgangspunkt. Hvis en given f\\u00e6lg giver en endnu st\\u00f8rre sporviddefor\\u00f8gelse, eller hvis sporvidden formindskes, kan f\\u00e6lgen stadig godt v\\u00e6re lovlig, hvis der foreligger en T\\u00dcV-attest som dokumentation.<\\/p>\\r\\n<p>Udover sporvidden, skal de nye hjul ogs\\u00e5 overholde sk\\u00e6rmreglementet for at v\\u00e6re lovlige. Det betyder, at hele hjulet skal v\\u00e6re indenfor sk\\u00e6rmen inkl. d\\u00e6ksidens runding. Hvis dette ikke er opfyldt, vil hjulet ikke v\\u00e6re lovligt, uanset om de er lovlige med hensyn til sporvidde. Vores ekspedienter vil kunne vejlede dig omkring reglerne i forhold til netop din bil.<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 13:49:56","created_by":"401","created_by_alias":"","modified":"2015-05-12 14:41:59","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-12 14:41:49","publish_up":"2015-05-12 13:49:56","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"1","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0);
INSERT INTO `g2q6h_ucm_history` (`version_id`, `ucm_item_id`, `ucm_type_id`, `version_note`, `save_date`, `editor_user_id`, `character_count`, `sha1_hash`, `version_data`, `keep_forever`) VALUES
(10, 4, 1, '', '2015-05-12 14:44:10', 401, 4705, '9b8a39563fc9ea1e3796cbf2e694f3b860e218c3', '{"id":4,"asset_id":61,"title":"Teknisk info - Hjul","alias":"teknisk-info-hjul","introtext":"<div class=\\"article\\">\\r\\n<p>D\\u00e6kket og f\\u00e6lgen bliver til hjul - en samlet enhed. Den rigtige f\\u00e6lg og det rigtige d\\u00e6k er vigtigt for at give bilen de rigtige egenkaber.<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>D\\u00e6k og f\\u00e6lgdimension kan erstattes hvis hjulet ikke rager ud over k\\u00e6rmen efter \\u00e6ndringen eller hvis den ikke rammer nogle chassisdel ved fuld uspension eller i noget drejningmoment. \\u00c6ndringer, der g\\u00f8r v\\u00e6sentlige \\u00e6ndringer ved k\\u00f8relsdynamikken g\\u00f8r \\u00e6ndringen ulovlig. Holder man sig til f\\u00e6lg og d\\u00e6k dimensioner i n\\u00e6rheden af det der orginalt var monteret p\\u00e5 k\\u00f8ret\\u00f8jet, b\\u00f8r \\u00e6ndringen ikke give nogle problemer.<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<h2>Hjulet diameter<\\/h2>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>S\\u00f8rg for at hjuldiameter ikke \\u00e6ndrer sig, n\\u00e5r du skifter d\\u00e6k\\/f\\u00e6lg. Med st\\u00f8rre hjul kan du ramme sk\\u00e6rmkanter eller st\\u00f8dd\\u00e6mpere, fjerdre el.<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>Hjulets h\\u00f8jde er f\\u00e6lgens st\\u00f8rrelse plus det dobbelte af d\\u00e6kprofilen.<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>Fx: D\\u00e6kst\\u00f8rrelse 225\\/45-17<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<ul>\\r\\n<li>225 er d\\u00e6kket bredde i mm<\\/li>\\r\\n<li>45 er h\\u00f8jden p\\u00e5 d\\u00e6kkets profil i % af bredden<\\/li>\\r\\n<li>17 er d\\u00e6kkets st\\u00f8rrelse (inderdiameter) i tommer<\\/li>\\r\\n<\\/ul>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>Formularen for eksemplet herover bliver (17*25,4)+(2*0,45)), hvilket giver en diameter p\\u00e5 634 mm.<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<h2>Rulningsomkreds<\\/h2>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>Rulningsomkredsen p\\u00e5 d\\u00e6kket er lig med den str\\u00e6kning hjulet ruller p\\u00e5 \\u00e9n rotation.Vi anbefaler ikke d\\u00e6k eller f\\u00e6lg n\\u00e5r rulningomkredsen forandres mere end \\u00b15% sammenlignet med rulningsomkredsen p\\u00e5 hjulet som bilen er godkendt til.<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>Fx:<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<ul>\\r\\n<li>D\\u00e6kst\\u00f8rrelse 225\\/45-17<\\/li>\\r\\n<li>Diameteren i eksemplet er 634 mm<\\/li>\\r\\n<li>Rlningsomkredsen er 634 mm multipliceret med pi (3,141592) og f\\u00e5r 1992 mm.<\\/li>\\r\\n<\\/ul>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>Hvis 224\\/45-17 er den oprindelige st\\u00f8rrelse, betyder dette at du kan skifte til andre d\\u00e6k s\\u00e5 l\\u00e6nge rulningsomkredsen er indenfor \\u00b15%, hvilket vil sige mindst 1892 mm og h\\u00f8jst 2092.<\\/p>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<h2>For\\u00f8gelse af st\\u00f8rrelse<\\/h2>\\r\\n<p align=\\"left\\">\\u00a0<\\/p>\\r\\n<p>N\\u00e5r der skiftes til st\\u00f8rre f\\u00e6lg end bilens orginale er det vigtigt at hjulets rulningsomkreds ikke \\u00f8ges. Dette kompenserer man ved at have en lavere profil p\\u00e5 d\\u00e6kket.<span style=\\"font-family: Arial; font-size: 10pt;\\"><br \\/><\\/span><span style=\\"font-family: Arial; font-size: 10pt;\\"><br \\/><\\/span><\\/p>\\r\\n<\\/div>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 14:44:10","created_by":"401","created_by_alias":"","modified":"2015-05-12 14:44:10","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 14:44:10","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(11, 5, 1, '', '2015-05-12 14:51:28', 401, 8301, '339d6209c643111227a855d6dae1654f2964df85', '{"id":5,"asset_id":62,"title":"EU-m\\u00e6rkning af d\\u00e6k","alias":"eu-maerkning-af-daek","introtext":"<p>Der vil blive indf\\u00f8rt en ny d\\u00e6km\\u00e6rkning i EU i 2012. N\\u00e6sten alle d\\u00e6k, der produceres efter juni 2012 og s\\u00e6lges fra november 2012 inden for EU skal b\\u00e6re et m\\u00e6rkat eller ledsages af et m\\u00e6rke i henhold til forordningen EC 1222\\/2009. Denne forordning vil, sammen med andre faktorer der normalt tages i betragtning, n\\u00e5r man beslutter sig for et k\\u00f8b, give slutbrugeren mulighed for at fortage et bedre valg, n\\u00e5r de k\\u00f8ber nye d\\u00e6k.<\\/p>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\">\\r\\n<p><img style=\\"margin-right: 20px; float: left;\\" src=\\"..\\/images\\/eu_m\\u00e6rke.png\\" alt=\\"eu m\\u00e6rke\\" width=\\"280\\" height=\\"411\\" \\/><\\/p>\\r\\n<\\/td>\\r\\n<td>\\r\\n<p>Et eksempel p\\u00e5 det nye EU-m\\u00e6rkat kan ses til venstre. Dette m\\u00e6rkat svarer til den almindeligt brugte m\\u00e6rkning af husholdningsartikler, s\\u00e5som vaskemaskiner og opvaskemaskiner.<\\/p>\\r\\n<p>M\\u00e5let med m\\u00e6rkningen er at g\\u00f8re vejtransporten sikrere og \\u00f8ge dens \\u00f8konomiske og milj\\u00f8m\\u00e6ssige effektivitet ved at fremme sikre og brandstofbesparende d\\u00e6k med lave st\\u00f8jniveauer. M\\u00e6rkningen opstiller ogs\\u00e5 rammerne for formidling af harmoniserede oplysninger om nogle d\\u00e6kparametre i hele branchen.<\\/p>\\r\\n<p>M\\u00e6rkningen er obligatorisk for:<\\/p>\\r\\n<ul>\\r\\n<li>D\\u00e6k til biler og SUV''er<\\/li>\\r\\n<li>D\\u00e6k til lette erhvervsk\\u00f8ret\\u00f8jer<\\/li>\\r\\n<li>Lastvognsd\\u00e6k<\\/li>\\r\\n<\\/ul>\\r\\n<p>M\\u00e6rkningen g\\u00e6lder dog ikke for:<\\/p>\\r\\n<ul>\\r\\n<li>Regummiering<\\/li>\\r\\n<li>Professionelle offroad d\\u00e6k<\\/li>\\r\\n<li>D\\u00e6k, der ikke er tilladte p\\u00e5 offentlige veje, s\\u00e5som racerd\\u00e6k<\\/li>\\r\\n<li>Type T reserved\\u00e6k til midlertidig brug<\\/li>\\r\\n<li>D\\u00e6k til veteranbiler<\\/li>\\r\\n<li>D\\u00e6k, hvis hastighedskode er under 80 km\\/t<\\/li>\\r\\n<li>D\\u00e6k med en nominel f\\u00e6lgdiameter p\\u00e5 h\\u00f8jst 254 mm eller p\\u00e5 mindst 635 mm<\\/li>\\r\\n<li>D\\u00e6k med funktioner, der forbedrer vejgrebet (s\\u00e5som pigd\\u00e6k)<\\/li>\\r\\n<\\/ul>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<h2>D\\u00e6kleverand\\u00f8rernes (producenter og import\\u00f8rer) ansvar<\\/h2>\\r\\n<p>N\\u00e5r d\\u00e6k leveres til en kunde, skal de ledsages af et m\\u00e6rkat for hver d\\u00e6kst\\u00f8rrelse og type i leverancen svarende til det m\\u00e6rkat, der vises til venstre. Dette krav kan ogs\\u00e5 opfyldes ved at s\\u00e6tte et m\\u00e6rkat p\\u00e5 hvert d\\u00e6k.<\\/p>\\r\\n<p>Alt reklamemateriale og teknisk og teknisk materiale skal vise m\\u00e6rkatv\\u00e6rdierne for hvert d\\u00e6k p\\u00e5 en forst\\u00e5elig m\\u00e5de. Producentens og forhandlerens hjemmesider skal ligeledes vise m\\u00e6rkatoplysninger for de d\\u00e6k, der tilbydes.<\\/p>\\r\\n<h2>D\\u00e6kforhandlernes ansvar (dem der s\\u00e6lger d\\u00e6k til slutbrugere)<\\/h2>\\r\\n<p>De skal for d\\u00e6k til personvogne og lette erhvervsk\\u00f8ret\\u00f8jer sikre, at hvert d\\u00e6k b\\u00e6rer et m\\u00e6rkat p\\u00e5 et klart synligt sted eller inden d\\u00e6kket s\\u00e6lges, forevise m\\u00e6rkatets oplsyninger for slutbrugeren, og et m\\u00e6rkat skal v\\u00e6re klart synligt i umiddelbar n\\u00e6rhed af d\\u00e6kket.<\\/p>\\r\\n<p>M\\u00e6rkatets oplysninger skal ligeledes gives, n\\u00e5r d\\u00e6k, der udbydes til salg, ikke er synlig for kunden.<\\/p>\\r\\n<p>Distribut\\u00f8rerne skal for samtlige d\\u00e6k (personbiler, lette erhvervsk\\u00f8ret\\u00f8jer, lastbiler og busser) sikre, at m\\u00e6rkatets v\\u00e6rdier for samtlige k\\u00f8bte d\\u00e6k ligeledes er anf\\u00f8rt p\\u00e5 kundens regning eller udleveres sammen med denne.<\\/p>\\r\\n<h2>Hvordan afl\\u00e6ses m\\u00e6rkatet?<\\/h2>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td><img src=\\"..\\/images\\/eu_m\\u00e6rke_1.png\\" alt=\\"eu m\\u00e6rke 1\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>Effektiv udnyttelse af br\\u00e6ndstoffet er vigtigt b\\u00e5de for at reducere CO\\u00b2 udledningen og k\\u00f8rselsomkostningerne. Kategorierne er indelt fra A (gr\\u00f8n) til G(r\\u00f8d). Kategori D benyttes ikke her. Forskellen mellem hver kategori indikerer en besparelse eller \\u00f8gning af br\\u00e6ndstofforbruget p\\u00e5 mellem 0,10 og 0,15 liter per 100 km for en bil der k\\u00f8rer ca. 15 km\\/liter. Forskellen mellem klasse G og klasse A for et komplet d\\u00e6ks\\u00e6t kan, afh\\u00e6ngig af k\\u00f8ret\\u00f8j og k\\u00f8rselsforhold, reducere br\\u00e6ndstofforbruget med op til 7,5%.<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td><img src=\\"..\\/images\\/eu_m\\u00e6rke_2.png\\" alt=\\"eu m\\u00e6rke 2\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>\\r\\n<p>Vejgreb p\\u00e5 v\\u00e5d vej er en afg\\u00f8rende faktor for sikkerheden, og indikerer d\\u00e6kkenes evne til at standse bilen hurtigt p\\u00e5 v\\u00e5de veje, og kan forklares ved hj\\u00e6lp af br\\u00e6msel\\u00e6ngder. Kategorierne er A til G, hvor D og G ikke benyttes. Effekten kan variere afh\\u00e6ngigt af k\\u00f8ret\\u00f8jet og k\\u00f8rselsforholdende, men forskellen mellem hver kategori svarer til en bremsel\\u00e6ngde p\\u00e5 mellem en og to bill\\u00e6ngder (eller mellem 3 og 6 meter) n\\u00e5r der bremses ved en hastighed p\\u00e5 80 km\\/t. Forskellen mellem klasse F og A for et s\\u00e6t best\\u00e5ende af fire identiske d\\u00e6k afkorte bremsel\\u00e6ngden med 30% (fx kan dette reducere bremsel\\u00e6ngden med 18 meter for en almindelig bil der k\\u00f8rer 80 km\\/t.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td><img src=\\"..\\/images\\/eu_m\\u00e6rke_3.png\\" alt=\\"eu m\\u00e6rke 3\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>\\r\\n<p>Her er der tale om st\\u00f8jniveauet fra d\\u00e6kkene udenfor kabinen. Det eksterne st\\u00f8jniveau inddeles i tre kategorier og m\\u00e5les i decibel (dB) sammenlignet med de nye europ\\u00e6iske niveauer for st\\u00f8j afgivet til omgivelserne, som skal introduceres frem til 2016.\\u00a0 Jo flere rammer, der er udfyldt med sort p\\u00e5 m\\u00e6rkaten, jo mere st\\u00f8jer d\\u00e6kkene.<\\/p>\\r\\n<ul>\\r\\n<li><b>1 sort lydb\\u00f8lge<\\/b>: d\\u00e6k med lav udvendig st\\u00f8j. 3 dB mindre end den kommende strammere europ\\u00e6iske gr\\u00e6nse<\\/li>\\r\\n<li><b>2 sorte lydb\\u00f8lger<\\/b>: d\\u00e6k med gennemsnitlig udvendig st\\u00f8j. D\\u00e6kket opfylder allerede den kommende europ\\u00e6iske gr\\u00e6nse.<\\/li>\\r\\n<li><b>3 sorte lydb\\u00f8lger<\\/b>: d\\u00e6k med h\\u00f8j udvendig st\\u00f8j. D\\u00e6kket opfylder den aktuelle europ\\u00e6iske gr\\u00e6nse, med er h\\u00f8jere end den kommende gr\\u00e6nse.<\\/li>\\r\\n<\\/ul>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 14:51:28","created_by":"401","created_by_alias":"","modified":"2015-05-12 14:51:28","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 14:51:28","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(12, 5, 1, '', '2015-05-12 14:51:47', 401, 8273, 'e162f1a1785ba894796519f01f7fa71f9d8a528b', '{"id":5,"asset_id":"62","title":"EU-m\\u00e6rkning af d\\u00e6k","alias":"eu-maerkning-af-daek","introtext":"<p>Der vil blive indf\\u00f8rt en ny d\\u00e6km\\u00e6rkning i EU i 2012. N\\u00e6sten alle d\\u00e6k, der produceres efter juni 2012 og s\\u00e6lges fra november 2012 inden for EU skal b\\u00e6re et m\\u00e6rkat eller ledsages af et m\\u00e6rke i henhold til forordningen EC 1222\\/2009. Denne forordning vil, sammen med andre faktorer der normalt tages i betragtning, n\\u00e5r man beslutter sig for et k\\u00f8b, give slutbrugeren mulighed for at fortage et bedre valg, n\\u00e5r de k\\u00f8ber nye d\\u00e6k.<\\/p>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\">\\r\\n<p><img src=\\"images\\/eu_m\\u00e6rke.png\\" alt=\\"eu m\\u00e6rke\\" width=\\"280\\" height=\\"411\\" \\/><\\/p>\\r\\n<\\/td>\\r\\n<td>\\r\\n<p>Et eksempel p\\u00e5 det nye EU-m\\u00e6rkat kan ses til venstre. Dette m\\u00e6rkat svarer til den almindeligt brugte m\\u00e6rkning af husholdningsartikler, s\\u00e5som vaskemaskiner og opvaskemaskiner.<\\/p>\\r\\n<p>M\\u00e5let med m\\u00e6rkningen er at g\\u00f8re vejtransporten sikrere og \\u00f8ge dens \\u00f8konomiske og milj\\u00f8m\\u00e6ssige effektivitet ved at fremme sikre og brandstofbesparende d\\u00e6k med lave st\\u00f8jniveauer. M\\u00e6rkningen opstiller ogs\\u00e5 rammerne for formidling af harmoniserede oplysninger om nogle d\\u00e6kparametre i hele branchen.<\\/p>\\r\\n<p>M\\u00e6rkningen er obligatorisk for:<\\/p>\\r\\n<ul>\\r\\n<li>D\\u00e6k til biler og SUV''er<\\/li>\\r\\n<li>D\\u00e6k til lette erhvervsk\\u00f8ret\\u00f8jer<\\/li>\\r\\n<li>Lastvognsd\\u00e6k<\\/li>\\r\\n<\\/ul>\\r\\n<p>M\\u00e6rkningen g\\u00e6lder dog ikke for:<\\/p>\\r\\n<ul>\\r\\n<li>Regummiering<\\/li>\\r\\n<li>Professionelle offroad d\\u00e6k<\\/li>\\r\\n<li>D\\u00e6k, der ikke er tilladte p\\u00e5 offentlige veje, s\\u00e5som racerd\\u00e6k<\\/li>\\r\\n<li>Type T reserved\\u00e6k til midlertidig brug<\\/li>\\r\\n<li>D\\u00e6k til veteranbiler<\\/li>\\r\\n<li>D\\u00e6k, hvis hastighedskode er under 80 km\\/t<\\/li>\\r\\n<li>D\\u00e6k med en nominel f\\u00e6lgdiameter p\\u00e5 h\\u00f8jst 254 mm eller p\\u00e5 mindst 635 mm<\\/li>\\r\\n<li>D\\u00e6k med funktioner, der forbedrer vejgrebet (s\\u00e5som pigd\\u00e6k)<\\/li>\\r\\n<\\/ul>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<h2>D\\u00e6kleverand\\u00f8rernes (producenter og import\\u00f8rer) ansvar<\\/h2>\\r\\n<p>N\\u00e5r d\\u00e6k leveres til en kunde, skal de ledsages af et m\\u00e6rkat for hver d\\u00e6kst\\u00f8rrelse og type i leverancen svarende til det m\\u00e6rkat, der vises til venstre. Dette krav kan ogs\\u00e5 opfyldes ved at s\\u00e6tte et m\\u00e6rkat p\\u00e5 hvert d\\u00e6k.<\\/p>\\r\\n<p>Alt reklamemateriale og teknisk og teknisk materiale skal vise m\\u00e6rkatv\\u00e6rdierne for hvert d\\u00e6k p\\u00e5 en forst\\u00e5elig m\\u00e5de. Producentens og forhandlerens hjemmesider skal ligeledes vise m\\u00e6rkatoplysninger for de d\\u00e6k, der tilbydes.<\\/p>\\r\\n<h2>D\\u00e6kforhandlernes ansvar (dem der s\\u00e6lger d\\u00e6k til slutbrugere)<\\/h2>\\r\\n<p>De skal for d\\u00e6k til personvogne og lette erhvervsk\\u00f8ret\\u00f8jer sikre, at hvert d\\u00e6k b\\u00e6rer et m\\u00e6rkat p\\u00e5 et klart synligt sted eller inden d\\u00e6kket s\\u00e6lges, forevise m\\u00e6rkatets oplsyninger for slutbrugeren, og et m\\u00e6rkat skal v\\u00e6re klart synligt i umiddelbar n\\u00e6rhed af d\\u00e6kket.<\\/p>\\r\\n<p>M\\u00e6rkatets oplysninger skal ligeledes gives, n\\u00e5r d\\u00e6k, der udbydes til salg, ikke er synlig for kunden.<\\/p>\\r\\n<p>Distribut\\u00f8rerne skal for samtlige d\\u00e6k (personbiler, lette erhvervsk\\u00f8ret\\u00f8jer, lastbiler og busser) sikre, at m\\u00e6rkatets v\\u00e6rdier for samtlige k\\u00f8bte d\\u00e6k ligeledes er anf\\u00f8rt p\\u00e5 kundens regning eller udleveres sammen med denne.<\\/p>\\r\\n<h2>Hvordan afl\\u00e6ses m\\u00e6rkatet?<\\/h2>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td><img src=\\"..\\/images\\/eu_m\\u00e6rke_1.png\\" alt=\\"eu m\\u00e6rke 1\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>Effektiv udnyttelse af br\\u00e6ndstoffet er vigtigt b\\u00e5de for at reducere CO\\u00b2 udledningen og k\\u00f8rselsomkostningerne. Kategorierne er indelt fra A (gr\\u00f8n) til G(r\\u00f8d). Kategori D benyttes ikke her. Forskellen mellem hver kategori indikerer en besparelse eller \\u00f8gning af br\\u00e6ndstofforbruget p\\u00e5 mellem 0,10 og 0,15 liter per 100 km for en bil der k\\u00f8rer ca. 15 km\\/liter. Forskellen mellem klasse G og klasse A for et komplet d\\u00e6ks\\u00e6t kan, afh\\u00e6ngig af k\\u00f8ret\\u00f8j og k\\u00f8rselsforhold, reducere br\\u00e6ndstofforbruget med op til 7,5%.<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td><img src=\\"..\\/images\\/eu_m\\u00e6rke_2.png\\" alt=\\"eu m\\u00e6rke 2\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>\\r\\n<p>Vejgreb p\\u00e5 v\\u00e5d vej er en afg\\u00f8rende faktor for sikkerheden, og indikerer d\\u00e6kkenes evne til at standse bilen hurtigt p\\u00e5 v\\u00e5de veje, og kan forklares ved hj\\u00e6lp af br\\u00e6msel\\u00e6ngder. Kategorierne er A til G, hvor D og G ikke benyttes. Effekten kan variere afh\\u00e6ngigt af k\\u00f8ret\\u00f8jet og k\\u00f8rselsforholdende, men forskellen mellem hver kategori svarer til en bremsel\\u00e6ngde p\\u00e5 mellem en og to bill\\u00e6ngder (eller mellem 3 og 6 meter) n\\u00e5r der bremses ved en hastighed p\\u00e5 80 km\\/t. Forskellen mellem klasse F og A for et s\\u00e6t best\\u00e5ende af fire identiske d\\u00e6k afkorte bremsel\\u00e6ngden med 30% (fx kan dette reducere bremsel\\u00e6ngden med 18 meter for en almindelig bil der k\\u00f8rer 80 km\\/t.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td><img src=\\"..\\/images\\/eu_m\\u00e6rke_3.png\\" alt=\\"eu m\\u00e6rke 3\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>\\r\\n<p>Her er der tale om st\\u00f8jniveauet fra d\\u00e6kkene udenfor kabinen. Det eksterne st\\u00f8jniveau inddeles i tre kategorier og m\\u00e5les i decibel (dB) sammenlignet med de nye europ\\u00e6iske niveauer for st\\u00f8j afgivet til omgivelserne, som skal introduceres frem til 2016.\\u00a0 Jo flere rammer, der er udfyldt med sort p\\u00e5 m\\u00e6rkaten, jo mere st\\u00f8jer d\\u00e6kkene.<\\/p>\\r\\n<ul>\\r\\n<li><b>1 sort lydb\\u00f8lge<\\/b>: d\\u00e6k med lav udvendig st\\u00f8j. 3 dB mindre end den kommende strammere europ\\u00e6iske gr\\u00e6nse<\\/li>\\r\\n<li><b>2 sorte lydb\\u00f8lger<\\/b>: d\\u00e6k med gennemsnitlig udvendig st\\u00f8j. D\\u00e6kket opfylder allerede den kommende europ\\u00e6iske gr\\u00e6nse.<\\/li>\\r\\n<li><b>3 sorte lydb\\u00f8lger<\\/b>: d\\u00e6k med h\\u00f8j udvendig st\\u00f8j. D\\u00e6kket opfylder den aktuelle europ\\u00e6iske gr\\u00e6nse, med er h\\u00f8jere end den kommende gr\\u00e6nse.<\\/li>\\r\\n<\\/ul>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 14:51:28","created_by":"401","created_by_alias":"","modified":"2015-05-12 14:51:47","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-12 14:51:33","publish_up":"2015-05-12 14:51:28","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(13, 5, 1, '', '2015-05-12 14:57:08', 401, 8261, 'a20c159cbc0b49ad3cfa4f7e01f284cd764771a5', '{"id":5,"asset_id":"62","title":"EU-m\\u00e6rkning af d\\u00e6k","alias":"eu-maerkning-af-daek","introtext":"<p>Der vil blive indf\\u00f8rt en ny d\\u00e6km\\u00e6rkning i EU i 2012. N\\u00e6sten alle d\\u00e6k, der produceres efter juni 2012 og s\\u00e6lges fra november 2012 inden for EU skal b\\u00e6re et m\\u00e6rkat eller ledsages af et m\\u00e6rke i henhold til forordningen EC 1222\\/2009. Denne forordning vil, sammen med andre faktorer der normalt tages i betragtning, n\\u00e5r man beslutter sig for et k\\u00f8b, give slutbrugeren mulighed for at fortage et bedre valg, n\\u00e5r de k\\u00f8ber nye d\\u00e6k.<\\/p>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\">\\r\\n<p><img src=\\"images\\/eu_m\\u00e6rke.png\\" alt=\\"eu m\\u00e6rke\\" width=\\"280\\" height=\\"411\\" \\/><\\/p>\\r\\n<\\/td>\\r\\n<td>\\r\\n<p>Et eksempel p\\u00e5 det nye EU-m\\u00e6rkat kan ses til venstre. Dette m\\u00e6rkat svarer til den almindeligt brugte m\\u00e6rkning af husholdningsartikler, s\\u00e5som vaskemaskiner og opvaskemaskiner.<\\/p>\\r\\n<p>M\\u00e5let med m\\u00e6rkningen er at g\\u00f8re vejtransporten sikrere og \\u00f8ge dens \\u00f8konomiske og milj\\u00f8m\\u00e6ssige effektivitet ved at fremme sikre og brandstofbesparende d\\u00e6k med lave st\\u00f8jniveauer. M\\u00e6rkningen opstiller ogs\\u00e5 rammerne for formidling af harmoniserede oplysninger om nogle d\\u00e6kparametre i hele branchen.<\\/p>\\r\\n<p>M\\u00e6rkningen er obligatorisk for:<\\/p>\\r\\n<ul>\\r\\n<li>D\\u00e6k til biler og SUV''er<\\/li>\\r\\n<li>D\\u00e6k til lette erhvervsk\\u00f8ret\\u00f8jer<\\/li>\\r\\n<li>Lastvognsd\\u00e6k<\\/li>\\r\\n<\\/ul>\\r\\n<p>M\\u00e6rkningen g\\u00e6lder dog ikke for:<\\/p>\\r\\n<ul>\\r\\n<li>Regummiering<\\/li>\\r\\n<li>Professionelle offroad d\\u00e6k<\\/li>\\r\\n<li>D\\u00e6k, der ikke er tilladte p\\u00e5 offentlige veje, s\\u00e5som racerd\\u00e6k<\\/li>\\r\\n<li>Type T reserved\\u00e6k til midlertidig brug<\\/li>\\r\\n<li>D\\u00e6k til veteranbiler<\\/li>\\r\\n<li>D\\u00e6k, hvis hastighedskode er under 80 km\\/t<\\/li>\\r\\n<li>D\\u00e6k med en nominel f\\u00e6lgdiameter p\\u00e5 h\\u00f8jst 254 mm eller p\\u00e5 mindst 635 mm<\\/li>\\r\\n<li>D\\u00e6k med funktioner, der forbedrer vejgrebet (s\\u00e5som pigd\\u00e6k)<\\/li>\\r\\n<\\/ul>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<h2>D\\u00e6kleverand\\u00f8rernes (producenter og import\\u00f8rer) ansvar<\\/h2>\\r\\n<p>N\\u00e5r d\\u00e6k leveres til en kunde, skal de ledsages af et m\\u00e6rkat for hver d\\u00e6kst\\u00f8rrelse og type i leverancen svarende til det m\\u00e6rkat, der vises til venstre. Dette krav kan ogs\\u00e5 opfyldes ved at s\\u00e6tte et m\\u00e6rkat p\\u00e5 hvert d\\u00e6k.<\\/p>\\r\\n<p>Alt reklamemateriale og teknisk og teknisk materiale skal vise m\\u00e6rkatv\\u00e6rdierne for hvert d\\u00e6k p\\u00e5 en forst\\u00e5elig m\\u00e5de. Producentens og forhandlerens hjemmesider skal ligeledes vise m\\u00e6rkatoplysninger for de d\\u00e6k, der tilbydes.<\\/p>\\r\\n<h2>D\\u00e6kforhandlernes ansvar (dem der s\\u00e6lger d\\u00e6k til slutbrugere)<\\/h2>\\r\\n<p>De skal for d\\u00e6k til personvogne og lette erhvervsk\\u00f8ret\\u00f8jer sikre, at hvert d\\u00e6k b\\u00e6rer et m\\u00e6rkat p\\u00e5 et klart synligt sted eller inden d\\u00e6kket s\\u00e6lges, forevise m\\u00e6rkatets oplsyninger for slutbrugeren, og et m\\u00e6rkat skal v\\u00e6re klart synligt i umiddelbar n\\u00e6rhed af d\\u00e6kket.<\\/p>\\r\\n<p>M\\u00e6rkatets oplysninger skal ligeledes gives, n\\u00e5r d\\u00e6k, der udbydes til salg, ikke er synlig for kunden.<\\/p>\\r\\n<p>Distribut\\u00f8rerne skal for samtlige d\\u00e6k (personbiler, lette erhvervsk\\u00f8ret\\u00f8jer, lastbiler og busser) sikre, at m\\u00e6rkatets v\\u00e6rdier for samtlige k\\u00f8bte d\\u00e6k ligeledes er anf\\u00f8rt p\\u00e5 kundens regning eller udleveres sammen med denne.<\\/p>\\r\\n<h2>Hvordan afl\\u00e6ses m\\u00e6rkatet?<\\/h2>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td><img src=\\"images\\/eu_m\\u00e6rke_1.png\\" alt=\\"eu m\\u00e6rke 1\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>Effektiv udnyttelse af br\\u00e6ndstoffet er vigtigt b\\u00e5de for at reducere CO\\u00b2 udledningen og k\\u00f8rselsomkostningerne. Kategorierne er indelt fra A (gr\\u00f8n) til G(r\\u00f8d). Kategori D benyttes ikke her. Forskellen mellem hver kategori indikerer en besparelse eller \\u00f8gning af br\\u00e6ndstofforbruget p\\u00e5 mellem 0,10 og 0,15 liter per 100 km for en bil der k\\u00f8rer ca. 15 km\\/liter. Forskellen mellem klasse G og klasse A for et komplet d\\u00e6ks\\u00e6t kan, afh\\u00e6ngig af k\\u00f8ret\\u00f8j og k\\u00f8rselsforhold, reducere br\\u00e6ndstofforbruget med op til 7,5%.<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td><img src=\\"images\\/eu_m\\u00e6rke_2.png\\" alt=\\"eu m\\u00e6rke 2\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>\\r\\n<p>Vejgreb p\\u00e5 v\\u00e5d vej er en afg\\u00f8rende faktor for sikkerheden, og indikerer d\\u00e6kkenes evne til at standse bilen hurtigt p\\u00e5 v\\u00e5de veje, og kan forklares ved hj\\u00e6lp af br\\u00e6msel\\u00e6ngder. Kategorierne er A til G, hvor D og G ikke benyttes. Effekten kan variere afh\\u00e6ngigt af k\\u00f8ret\\u00f8jet og k\\u00f8rselsforholdende, men forskellen mellem hver kategori svarer til en bremsel\\u00e6ngde p\\u00e5 mellem en og to bill\\u00e6ngder (eller mellem 3 og 6 meter) n\\u00e5r der bremses ved en hastighed p\\u00e5 80 km\\/t. Forskellen mellem klasse F og A for et s\\u00e6t best\\u00e5ende af fire identiske d\\u00e6k afkorte bremsel\\u00e6ngden med 30% (fx kan dette reducere bremsel\\u00e6ngden med 18 meter for en almindelig bil der k\\u00f8rer 80 km\\/t.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td><img src=\\"images\\/eu_m\\u00e6rke_3.png\\" alt=\\"eu m\\u00e6rke 3\\" width=\\"250\\" height=\\"208\\" \\/><\\/td>\\r\\n<td>\\r\\n<p>Her er der tale om st\\u00f8jniveauet fra d\\u00e6kkene udenfor kabinen. Det eksterne st\\u00f8jniveau inddeles i tre kategorier og m\\u00e5les i decibel (dB) sammenlignet med de nye europ\\u00e6iske niveauer for st\\u00f8j afgivet til omgivelserne, som skal introduceres frem til 2016.\\u00a0 Jo flere rammer, der er udfyldt med sort p\\u00e5 m\\u00e6rkaten, jo mere st\\u00f8jer d\\u00e6kkene.<\\/p>\\r\\n<ul>\\r\\n<li><b>1 sort lydb\\u00f8lge<\\/b>: d\\u00e6k med lav udvendig st\\u00f8j. 3 dB mindre end den kommende strammere europ\\u00e6iske gr\\u00e6nse<\\/li>\\r\\n<li><b>2 sorte lydb\\u00f8lger<\\/b>: d\\u00e6k med gennemsnitlig udvendig st\\u00f8j. D\\u00e6kket opfylder allerede den kommende europ\\u00e6iske gr\\u00e6nse.<\\/li>\\r\\n<li><b>3 sorte lydb\\u00f8lger<\\/b>: d\\u00e6k med h\\u00f8j udvendig st\\u00f8j. D\\u00e6kket opfylder den aktuelle europ\\u00e6iske gr\\u00e6nse, med er h\\u00f8jere end den kommende gr\\u00e6nse.<\\/li>\\r\\n<\\/ul>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 14:51:28","created_by":"401","created_by_alias":"","modified":"2015-05-12 14:57:08","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-12 14:56:32","publish_up":"2015-05-12 14:51:28","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":3,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"1","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0);
INSERT INTO `g2q6h_ucm_history` (`version_id`, `ucm_item_id`, `ucm_type_id`, `version_note`, `save_date`, `editor_user_id`, `character_count`, `sha1_hash`, `version_data`, `keep_forever`) VALUES
(14, 6, 1, '', '2015-05-12 15:20:15', 401, 18806, 'dcc6ff33e10c9d6ee69e42c8cf515b7aca6cfaac', '{"id":6,"asset_id":63,"title":"Vedligeholdelsesguide D\\u00e6k","alias":"vedligeholdelsesguide-daek","introtext":"<p>Du kan forl\\u00e6nge levetiden p\\u00e5 d\\u00e6k, hvis du s\\u00f8rger for en passende vedligeholdelse. Der er mange faktorer, der p\\u00e5virker holdbarheden af d\\u00e6k og i nedenst\\u00e5ende gennemg\\u00e5r vi f\\u00f8lgende faktorer:<\\/p>\\r\\n<ol>\\r\\n<li>Opbevaring af d\\u00e6k<\\/li>\\r\\n<li>Kontrol af d\\u00e6ktryk<\\/li>\\r\\n<li>D\\u00e6kslitage<\\/li>\\r\\n<li>Monteringsregler<\\/li>\\r\\n<\\/ol>\\r\\n<h2>1. Opbevaring af d\\u00e6k<\\/h2>\\r\\n<p>Hvis dine d\\u00e6k skal bevare deres egenskaber, skal de opbevares rigtigt.<\\/p>\\r\\n<p>F\\u00f8r du skifter dine d\\u00e6k, b\\u00f8r du markere retningen p\\u00e5 d\\u00e6kket med et stykke kridt samt markere hvor d\\u00e6kkene har v\\u00e6ret monteret (f.eks. vf =venstre forhjul, hb =h\\u00f8jre baghjul. G\\u00f8r derefter d\\u00e6kkene rene, og fjern grus og lignende. N\\u00e5r du reng\\u00f8rer din bil eller f\\u00e6lge skal du v\\u00e6re opm\\u00e6rksom p\\u00e5, at d\\u00e6kkene ikke kan t\\u00e5le \\"skrappe\\" reng\\u00f8ringsmidler eller silikone. Vask dine d\\u00e6k med vand og almindelig bilshampoo.<\\/p>\\r\\n<p>N\\u00e5r gummi \\u00e6ldes, bliver det h\\u00e5rdt og revner, hvis det ikke opbevares rigtigt. For at holde d\\u00e6kkene i god stand mellem to s\\u00e6soner, skal visse regler f\\u00f8lges.<\\/p>\\r\\n<h3>Temperatur<\\/h3>\\r\\n<p>Temperaturen i det lokale d\\u00e6kkene opbevares , b\\u00f8r ikke overstige +25\\u00b0. Lokalte skal helst v\\u00e6re m\\u00f8rkt, og temperaturen skal helst ligge rundt de 15\\u00b0. Hvis temperaturen er over +25\\u00b0 eller under 0\\u00b0kan gummiets egenskaber egenskaber forandres, og dette kan forkorte d\\u00e6kkets levetid.<\\/p>\\r\\n<h3>Fugtighed<\\/h3>\\r\\n<p>D\\u00e6k b\\u00f8r ikke opbevares p\\u00e5 alt for fugtige steder. Fugtigheden b\\u00f8r ikke v\\u00e6re s\\u00e5 h\\u00f8j, at d\\u00e6kkene ser fugtige ud. D\\u00e6k b\\u00f8r heller ikke ligge ude i regn.<\\/p>\\r\\n<h3>Lys<\\/h3>\\r\\n<p>D\\u00e6k b\\u00f8r beskyttes mod lys, specielt mod direkte sollys og mod st\\u00e6rkt lampelys med h\\u00f8j UV-faktor.<\\/p>\\r\\n<h3>Kemikalier<\\/h3>\\r\\n<p>S\\u00f8rg for at d\\u00e6k ikke kommer i n\\u00e6rheden af kemikalier, opl\\u00f8sningsmidler eller kulbrinter, som kan forringe d\\u00e6kkets egenskaber. I det rum, hvor d\\u00e6kkene opbevares, m\\u00e5 der ikke opbevares apparater som genererer ozon, fx fluor- eller kviks\\u00f8lvdampe, h\\u00f8jsp\\u00e6ndte elektriske apparate, el-motorer eller andre former for el-apparater som kan afgive gnister eller str\\u00f8mudladning. D\\u00e6k m\\u00e5 specielt beskyttes mod kontakt med l\\u00f8semidler, olie og fedt. Selv kortvarig kontakt med s\\u00e5danne stoffer, kan give skade.<\\/p>\\r\\n<h3>Formforandring<\\/h3>\\r\\n<p>Om muligt b\\u00f8r d\\u00e6k opbeares p\\u00e5 en s\\u00e5dan m\\u00e5de, at de ikke ligger under pres, sp\\u00e6nding eller vridning. Kraftige formforandringer under opbevaring kan medf\\u00f8re defekt, n\\u00e5r man \\u00f8ger lufttrykket i d\\u00e6kket.<\\/p>\\r\\n<h3>D\\u00e6kh\\u00e5ndtering<\\/h3>\\r\\n<p>Du m\\u00e5 aldrig slippe d\\u00e6k ned fra st\\u00f8rre h\\u00f8jder en 1,5 meter, da dette kan skade d\\u00e6kket i bead-omr\\u00e5det. En typisk konsekvens kan v\\u00e6re b\\u00f8jet bead. Et d\\u00e6k med b\\u00f8jet bead, m\\u00e5 ikke monteres p\\u00e5 en f\\u00e6lg.<\\/p>\\r\\n<p>D\\u00e6k p\\u00e5 f\\u00e6lge skal aldrig opbevares st\\u00e5ende p\\u00e5 gulvet - de skal h\\u00e6nges op eller stakkes liggende (ideelt p\\u00e5 en tr\\u00e6palle). D\\u00e6k uden f\\u00e6lge skal derimod opbevares st\\u00e5ende. For at udg\\u00e5 at d\\u00e6km\\u00e6rker opst\\u00e5r, b\\u00f8r de drejes lidt hver fjerde uge. De m\\u00e5 ikke h\\u00e6nges op eller stakkes.<\\/p>\\r\\n<p><img src=\\"images\\/d\\u00e6kop.png\\" alt=\\"d\\u00e6kop\\" width=\\"336\\" height=\\"293\\" \\/><\\/p>\\r\\n<p>F\\u00f8r du s\\u00e6tter d\\u00e6kkene p\\u00e5 igen, skal du altid kontrollere dem for beskadigelse samt slitage, og kontrollere resterende d\\u00e6km\\u00f8nsterdybde og eventuel ubalance.<\\/p>\\r\\n<h2>2. D\\u00e6ktryk<\\/h2>\\r\\n<p>Det er luften i d\\u00e6kkene som b\\u00e6rer bilen, og det er meget vigtigt at d\\u00e6kkene har det korrekte lufttryk for at opn\\u00e5 optimale styre- og bremseevner samt den bedste br\\u00e6ndstof\\u00f8konomi.<\\/p>\\r\\n<h3>Anbefalet d\\u00e6ktryk<\\/h3>\\r\\n<p>Det\\u00a0 anbefalede d\\u00e6ktryk fremg\\u00e5r af bilens instruktionsbog og\\/elleren m\\u00e6rkat, der som regel er fatkl\\u00e6bet i venstre ford\\u00f8rs\\u00e5bning, benzind\\u00e6kslet eller i handskerummet. Overhold dette tryk! Det er fremkommet efter en lang r\\u00e6kke tests udf\\u00f8rt af d\\u00e6kfabrikanten og bilproducenten. Bem\\u00e6rk at der kan v\\u00e6re forskel mellem for- og bagd\\u00e6k samt s\\u00e6rlige krav til d\\u00e6ktryk ved k\\u00f8rsel med tungt l\\u00e6s, h\\u00f8j hastighed eller campingvogn.<\\/p>\\r\\n<h3>Regelm\\u00e6ssigt tjek<\\/h3>\\r\\n<p>Husk regelm\\u00e6ssigt at tjekke d\\u00e6ktrykket. Mindst hver \\u00e9n gang om m\\u00e5neden og altid inden l\\u00e6ngere rejser, is\\u00e6r hvis du skal k\\u00f8re p\\u00e5 motorvej. Trykket skal m\\u00e5les med kolde d\\u00e6k (ikke lige efter k\\u00f8rsel med h\\u00f8j hastighed eller lang distance). Hvis du ikke kan vente, til de er kolde, l\\u00e6gges 0,3 bar til det anbefalede tryk. Luk aldrig luft ud af varme d\\u00e6k.<\\/p>\\r\\n<p>Lufttemperaturen p\\u00e5virker trykket i d\\u00e6kkene. Jo lavere temperatur, jo lavere er det m\\u00e5lte tryk. Derfor anbefales det at l\\u00e6gge 0,2 bar til referencetrykket om vinteren.<\\/p>\\r\\n<p>P\\u00e5 de fleste tankstationer findes d\\u00e6ktrykm\\u00e5lere, men en god ide er at investere i en d\\u00e6ktryksm\\u00e5ler og evt. kompressor, s\\u00e5 man kan tjekke trykket derhjemme.<\\/p>\\r\\n<p>Mister du en ventilh\\u00e6tte, eksempelvis n\\u00e5r du tjekker d\\u00e6ktrykket, er det vigtigt at du snarest k\\u00f8rer forbi et v\\u00e6rksted og k\\u00f8ber en ny. Hvis man k\\u00f8rer uden ventilh\\u00e6tte, vil der s\\u00e6tte sig skidt fra vejen i ventilen som derved kan blive ut\\u00e6t n\\u00e5r der n\\u00e6ste gang tjekkes tryk i d\\u00e6kket.<\\/p>\\r\\n<h3>Konsekvenser af forkert d\\u00e6ktryk<\\/h3>\\r\\n<p>Udover d\\u00e5rlig vejkontakt og br\\u00e6ndstof\\u00f8konomi vil forkert d\\u00e6ktryk ogs\\u00e5 for\\u00e5rsage unormalt slid p\\u00e5 d\\u00e6kket og vil medf\\u00f8re forkortet levetid. Ved k\\u00f8rsel med 1 bar for lavt tryk \\u00f8ges br\\u00e6ndstofforbruget med helt op til 15 %. Desuden kan for lavt d\\u00e6ktryk halvere d\\u00e6kkets levetid!<\\/p>\\r\\n<p><img src=\\"images\\/d\\u00e6ktryk.png\\" alt=\\"d\\u00e6ktryk\\" width=\\"300\\" height=\\"237\\" \\/><\\/p>\\r\\n<h4>For h\\u00f8jt tryk (+0,5 bar)<\\/h4>\\r\\n<p>Hvis d\\u00e6kkene er pumpet for h\\u00f8jt op, slides de hurtigere midt p\\u00e5, hvilket forkorter d\\u00e6kkets levetid. Desuden betyder en mindre kontaktflade med vejen et forringet vejgreb, som kan v\\u00e6re farligt i sving eller under bremsning.<\\/p>\\r\\n<h4>For lavt tryk (-0,5 til -1,5 bar)<\\/h4>\\r\\n<p>Hvis d\\u00e6kkene er pumpet utilstr\\u00e6kkeligt op (-0,5 bar), slides hurtigere ved skuldrene, hvilket ogs\\u00e5 forkorter d\\u00e6kkets levetid. Desuden \\u00f8ger det fladtrykkede d\\u00e6k br\\u00e6ndstofforbruget, og vandet ledes mindre effektivt v\\u00e6k. Hvis d\\u00e6kkene er pumpet helt utilstr\\u00e6kkeligt op (-1,5 bar), kan du k\\u00f8re galt. D\\u00e6kkene bliver overophedet og risikerer at springe.<\\/p>\\r\\n<h2>3. D\\u00e6kslitage<\\/h2>\\r\\n<p>S\\u00f8rg for regelm\\u00e6ssigt at tjekke m\\u00f8nsterdybden p\\u00e5 dine d\\u00e6k og udskift dem, n\\u00e5r de er slidte. Det garanterer maksimalt greb og forhindrer ubehagelige overraskelser. Udskift dien d\\u00e6k, f\\u00f8r m\\u00f8nsterdybden er slidt ned til den lovlige gr\\u00e6nse. Den lovlige slidgr\\u00e6nse er fastsat til 1,6 mm m\\u00f8nsterdybde, men d\\u00e6kkets ydelse formindskes efterh\\u00e5nden som slidbanen slides. Du m\\u00e5 derfor m\\u00e5le d\\u00e6kkenes slitage efter et vist antal kilometer. I almidelighed skal et d\\u00e6k af god kvalitet skiftes for hver 40.000-50.000 km og af en mindre god kvalitet for hver 10.000 km. Du kan kontrollere d\\u00e6kkenes slitage ved at unders\\u00f8ge dine d\\u00e6ks slidindikator.<\\/p>\\r\\n<p>Slidindikatoren er en lille 1,6 mm tyk gummiklods, som sidder i bunden af d\\u00e6km\\u00f8nsteret eller - rillerne. N\\u00e5r slidbanen kommer ned i plan med indikatoren, er d\\u00e6kkene slidt til den lovlige gr\\u00e6nse og skal skiftes. Hvis gr\\u00e6nserne overskrides, er d\\u00e6kkene ulovlige.<\\/p>\\r\\n<p>Der kan v\\u00e6re mange forskellige \\u00e5rsager til, at d\\u00e6k slides uens. Herunder kan man se en vejledning til, hvorfor d\\u00e6k slides som de g\\u00f8r.<\\/p>\\r\\n<p><img src=\\"images\\/slid.png\\" alt=\\"slid\\" width=\\"527\\" height=\\"711\\" \\/><\\/p>\\r\\n<h3>Byt rundt p\\u00e5 d\\u00e6kkene, s\\u00e5 slides de mindre<\\/h3>\\r\\n<p>Ved med j\\u00e6vne mellemrum at bytte rundt p\\u00e5 d\\u00e6kkene, kan du opn\\u00e5 mange fordele, du kanbl.a. forsinke d\\u00e6kslitage og opn\\u00e5 forbedringer i hjulenes ydeevne. Vi anbefaler, at d\\u00e6kkene byttes om mellem hver k\\u00f8rte 10.000 til 15.000 km. Du kan med fordel bytte rundt p\\u00e5 hjulene, n\\u00e5r bilen er inde til service eller olieskift og alligevel er hejst op. Dette kan ogs\\u00e5 v\\u00e6re et godt tidspunkt til at afbalancere dine hjul.<\\/p>\\r\\n<p>Selv om en bil er udstyret med 4 hjul, udf\\u00f8rer for- og baghjul vidt forskellige opgaver. Der vil v\\u00e6re forskellig grad og af slitage og forksellige slitage typer, alt efter hvilken af de fire positioner, hjulet sidder p\\u00e5. Du kan derfor forl\\u00e6nge hjulenes levetid, ved at bytte rundt p\\u00e5 d\\u00e6kkene.<\\/p>\\r\\n<p>Der er tre rotationsm\\u00f8nstre, som d\\u00e6kker de fleste k\\u00e6ret\\u00f8jer, som er udstyret med ikke-retningsbestemte d\\u00e6k og hjul af samme st\\u00f8rrelse og offset. Det f\\u00f8rste (figur A) er \\"Bagudrettet kryds\\", det andet (figur B) er\\u00a0 \\"Forudrettet kryds\\" og det tredje (figur C) er \\"X-m\\u00f8nster\\". X-m\\u00f8nsteret kan bruges som et alternativ til A og C.<\\/p>\\r\\n<p>Dagens performance d\\u00e6k og hjultrends har betydet et behov for to ekstra rotationsm\\u00f8nstre. \\"For-til-bag\\" (figur D) m\\u00f8nster kan bruges til k\\u00f8ret\\u00f8jer som er udstyret med samme st\\u00f8rrelse retningsbestemte d\\u00e6k. Et \\"Side-til-side\\" (figur E) m\\u00f8nster kan bruges af k\\u00f8ret\\u00f8jer, som er udstyret med ikke-retningsbestemte d\\u00e6k af forskellig st\\u00f8rrelse p\\u00e5 henholdvis for- og bagaksel.<\\/p>\\r\\n<p>Hvis de to sidste rotation m\\u00f8nstre ikke giver j\\u00e6vn slitage vil afmontering, montering og rebalancering v\\u00e6re n\\u00f8dvendigt for at rotere d\\u00e6kkene.<\\/p>\\r\\n<p>K\\u00f8ret\\u00f8jer, der bruger forskellige st\\u00f8rrelser retningsbestemte hjul og d\\u00e6k, og \\/ eller hjul med forskellig offset foran og bag og retningsbestemte d\\u00e6k vil kr\\u00e6ver afmontering, montering og afbalancering i forbindelse med rotation af hjulene.<\\/p>\\r\\n<h2>4. Monteringsregler<\\/h2>\\r\\n<p>Der findes nogle grundl\\u00e6ggende regler, som du b\\u00f8r kende, hvis du skal montere et ny d\\u00e6k p\\u00e5 din bil.<\\/p>\\r\\n<p>Generelt skal du sikre at bilproducentens anbefaling overholdes i forhold til opbygning, d\\u00e6kst\\u00f8rrelse (bredde, h\\u00f8jde, diameter), hastigheds- og belastningsindeks. Derudover skal du sikre, at d\\u00e6kkene efterses indvendig og udvendig for eventuelle fejl. Endvidere skal fremgangsm\\u00e5den for m\\u00e5ntering overholdes - dvs. afmontering, afbalancering og oppumpning af d\\u00e6kket, udskiftning af ventil, overholdelse af monteringsanvisningerne p\\u00e5 d\\u00e6kket (oml\\u00f8bsretning eller monteringsretning).<\\/p>\\r\\n<p>Bland aldrig radiald\\u00e6k og ikke-radiald\\u00e6k p\\u00e5 et k\\u00f8ret\\u00f8j. Hvis det er uundg\\u00e5eligt at blande d\\u00e6k, s\\u00e5 bland aldrig radiald\\u00e6k og ikke-radiald\\u00e6k p\\u00e5 samme aksel. Hvis to radiald\\u00e6k og to ikke-radiald\\u00e6k monteres p\\u00e5 et k\\u00f8ret\\u00f8j, skal de to radiald\\u00e6k monteres p\\u00e5 bagakselen p\\u00e5 bagakselen og de to ikke-radiald\\u00e6k p\\u00e5 forakselen.<\\/p>\\r\\n<h3>Hvis du kun skifter et d\\u00e6k<\\/h3>\\r\\n<p>Hvis du kun skifter et d\\u00e6k, skal du sikre, at dette d\\u00e6k har samme slidbanem\\u00f8nster (fx retningsbestemt, asymmetrisk), samme m\\u00e5l og samme belastnings- og hastighedsindeks som, det d\\u00e6k der udskiftes. Derudover skal du sikre dig, at forskellen i slitage i forhold til d\\u00e6kket p\\u00e5 samme aksel er under 5 mm.<\\/p>\\r\\n<h3>Hvis du skifter to d\\u00e6k<\\/h3>\\r\\n<p>Hvis du skifter to d\\u00e6k, skal disse monteres p\\u00e5 bagakselen. For selv om ford\\u00e6kkene slides hurtigere end bagd\\u00e6kkene, viser adskillelige test, at det er lettere at kontrollere forakselen end bagakselen. Hvis de nye d\\u00e6k monteres p\\u00e5 bagakselen, opn\\u00e5r du bedre k\\u00f8reegenskaber i kurver p\\u00e5 v\\u00e5dt underlag og \\u00f8get sikkerhed.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p>Det er nemt at glemme, at d\\u00e6kkene er den eneste kontaktflade mellem k\\u00f8ret\\u00f8jet og vejbanen. Det er derfor, det er utrolig vigtigt at bevare dine d\\u00e6ks gode kvaliteter og egenskaber for at garantere b\\u00e5de din sikkerhed og din mobilitet. For at g\\u00f8re dette anbefaler vi, at du overholder f\\u00f8lgende sikkerhedsanbefalinger.<\\/p>\\r\\n<p class=\\"section-heading first-child\\">1. Kontaktflade<\\/p>\\r\\n<p><strong>ET STORT JOB FOR EN LILLE OVERFLADE<br \\/><\\/strong>Den del af dit d\\u00e6k, som rent faktisk er i kontakt med vejbanen, er ikke st\\u00f8rre end din h\\u00e5nd. Din sikkerhed, komfort og br\\u00e6ndstof\\u00f8konomi afh\\u00e6nger ogs\\u00e5 af denne meget lille overflade. Derfor skal du sikre dig, at du ikke bare v\\u00e6lger det rigtige d\\u00e6k, men ogs\\u00e5 regelm\\u00e6ssigt vedligeholde dem korrekt. Det er vigtigt, eftersom dine d\\u00e6k:<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<ul>\\r\\n<li class=\\"first-child\\">Er den eneste forbindelse mellem dit k\\u00f8ret\\u00f8j og vejbanen<\\/li>\\r\\n<li>B\\u00e6rer hele bilens v\\u00e6gt, en belastning op til 50 gange dets egen v\\u00e6gt<\\/li>\\r\\n<li>Reagerer p\\u00e5 f\\u00f8rerens krav s\\u00e5som styring, acceleration og opbremsning<\\/li>\\r\\n<li class=\\"last-child\\">Absorberer hver eneste forhindring p\\u00e5 vejen<\\/li>\\r\\n<\\/ul>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p class=\\"section-heading\\">2. M\\u00f8nsterdybde og slitage<\\/p>\\r\\n<p><strong>EN HURTIG OG ENKEL SIKKERHEDSFORANSTALTNING<\\/strong><br \\/>S\\u00f8rg for regelm\\u00e6ssigt at tjekke m\\u00f8nsterdybden p\\u00e5 dine d\\u00e6k og udskifte dem, n\\u00e5r de er slidte. Det garanterer maksimalt greb og forhindrer ubehagelige overraskelser. Udskift dine d\\u00e6k, f\\u00f8r m\\u00f8nsterdybden er slidt ned til 1,6 mm. Michelins d\\u00e6k har slidindikatorer, som sidder nede i bunden af d\\u00e6km\\u00f8nsteret i en h\\u00f8jde af cirka 1,6 mm. Din sikkerhed og mobilitet afh\\u00e6nger af en lovlig m\\u00f8nsterdybde eftersom:<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<ul>\\r\\n<li class=\\"first-child\\">M\\u00f8nstersporene dr\\u00e6ner vandet under d\\u00e6kkene v\\u00e6k, s\\u00e5 du kan bevare kontrollen<\\/li>\\r\\n<li>Jo mere m\\u00f8nsterdybde, der er tilbage p\\u00e5 dine d\\u00e6k, jo mere vand kan du dr\\u00e6ne v\\u00e6k og dermed reducere risikoen for akvaplaning<\\/li>\\r\\n<li>Korrekt lufttryk s\\u00e5vel som regelm\\u00e6ssig vedligeholdelse af k\\u00f8ret\\u00f8jet sikrer, at dine d\\u00e6ks pr\\u00e6stationer er optimale i l\\u00e6ngst mulig tid<\\/li>\\r\\n<li class=\\"last-child\\">D\\u00e6km\\u00f8nsteret griber fat i vejen og har betydning for din bremsel\\u00e6ngde<\\/li>\\r\\n<\\/ul>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<p class=\\"section-heading\\">3. Lufttryk<\\/p>\\r\\n<p><strong>KONTROLL\\u00c9R LUFTTRYKKET EN GANG OM M\\u00c5NEDEN<\\/strong><\\/p>\\r\\n<p>Korrekt lufttryk reducerer risikoen for at miste kontrollen over k\\u00f8ret\\u00f8jet. Det beskytter ogs\\u00e5 dine d\\u00e6k mod for tidlig slitage og uoprettelig indvendig skade. Lufttrykket kan falde p\\u00e5 grund af sm\\u00e5 perforeringer, naturligt udslip af luft gennem d\\u00e6kkets bestanddele eller fra skiftende temperaturer. Kontroll\\u00e9r lufttrykket i dine d\\u00e6k, inklusive reservehjulet, en gang om m\\u00e5neden og helst p\\u00e5 kolde d\\u00e6k (som ikke har k\\u00f8rt i mindst 2 timer, eller som kun har k\\u00f8rt meget en meget kort str\\u00e6kning ved lav hastighed). Hvis d\\u00e6kkene kontrolleres, n\\u00e5r de er varme, skal der l\\u00e6gges 0,2 bar til det anbefalede lufttryk. Det er vigtigt at kontrollere lufttrykket en gang om m\\u00e5neden fordi:<\\/p>\\r\\n<ul>\\r\\n<li class=\\"last-child first-child\\">\\r\\n<p>Lavt lufttryk \\u00f8ger risikoen for skader p\\u00e5 d\\u00e6kket<\\/p>\\r\\n<\\/li>\\r\\n<li class=\\"first-child\\">\\r\\n<p>Et 20 % for h\\u00f8jt lufttryk reducerer d\\u00e6kkets levetid med omkring 10.000 km.<\\/p>\\r\\n<\\/li>\\r\\n<li>\\r\\n<p>Korrekt lufttryk sparer br\\u00e6ndstof<\\/p>\\r\\n<\\/li>\\r\\n<li>\\r\\n<p>Det anbefalede lufttryk er IKKE findes p\\u00e5 d\\u00e6kket. Det lufttryk, som er angivet p\\u00e5 d\\u00e6ksiden, er kun det maksimale lufttryk, d\\u00e6kket kan t\\u00e5le. Det anbefalede lufttryk kan findes:<\\/p>\\r\\n<\\/li>\\r\\n<li>\\r\\n<p>I dit k\\u00f8ret\\u00f8js instruktionsbog<\\/p>\\r\\n<\\/li>\\r\\n<li>\\r\\n<p>P\\u00e5 m\\u00e6rkaterne p\\u00e5 indersiden af ford\\u00f8ren i f\\u00f8rerens side<\\/p>\\r\\n<\\/li>\\r\\n<li>\\r\\n<p>I opbevaringsrummet t\\u00e6t ved f\\u00f8rers\\u00e6det<\\/p>\\r\\n<\\/li>\\r\\n<li class=\\"last-child\\">\\r\\n<p>P\\u00e5 indersiden af tankklappen<\\/p>\\r\\n<\\/li>\\r\\n<\\/ul>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 15:20:15","created_by":"401","created_by_alias":"","modified":"2015-05-12 15:20:15","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 15:20:15","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(15, 7, 1, '', '2015-05-12 15:21:57', 401, 5299, 'd6326d02d5b3381a5b9e87f51a670f9c733f5c25', '{"id":7,"asset_id":64,"title":"Udskiftning af d\\u00e6k","alias":"udskiftning-af-daek","introtext":"<p>Det er ikke muligt at bestemme et d\\u00e6ks levetid, eftersom der er mange faktorer, som spiller ind, fx k\\u00f8restil, vejr og opbevaring.<\\/p>\\r\\n<p>Vi har herunder opstillet en liste over 6 grunde til at udskifte dine d\\u00e6k.<\\/p>\\r\\n<h2>1. Hvis du punkterer<\\/h2>\\r\\n<p>Moderne d\\u00e6k er meget robuste og kan klare de fleste ting. Punkteringer kan dog stadig ske. En specialist b\\u00f8r altid tjekke dine d\\u00e6k efter en punktering for at opdage skjulte skader, som kan betyde, at d\\u00e6kket ikke kan repareres.<\\/p>\\r\\n<h2>2. Hvis d\\u00e6kkene er slidt<\\/h2>\\r\\n<p>Det er altid klogt at kontrollere dine d\\u00e6ks slitage regelm\\u00e6ssigt. Hvis dine d\\u00e6k er slidt ned til lovens minimumskrav p\\u00e5 1,6 millimeter, skal d\\u00e6kkene skiftes. De fleste d\\u00e6k har indst\\u00f8bte slidindikatorer i bunden af d\\u00e6kkets d\\u00e6km\\u00f8nster. Hvis m\\u00f8nsteret er slidt ned til det niveau, s\\u00e5 du kan se et gummim\\u00e6rke p\\u00e5 tv\\u00e6rs af slidbanen, er det p\\u00e5 tide at f\\u00e5 skiftet dine d\\u00e6k.<\\/p>\\r\\n<h2>3. Hvis dine d\\u00e6k viser tegn p\\u00e5 \\u00e6ldning<\\/h2>\\r\\n<p>D\\u00e6k har ikke en forudsigelig holdbarhed. Det betyder ikke noget, hvorn\\u00e5r d\\u00e6kkene blev produceret. D\\u00e6k \\u00e6ldes, selv n\\u00e5r de ikke bruges, eller hvis de kun bruges lejlighedsvis. Der er mange faktorer, som vil p\\u00e5virke d\\u00e6kkets liv, herunder temperatur, vedligeholdelse, forhhold under opbevaring og brug, belastning, hastighed, lufttryk s\\u00e5vel som k\\u00f8restil. Disse faktorer har stor indvirkning p\\u00e5 l\\u00e6ngden af den brugstid, du kan forvente af dine d\\u00e6k.<\\/p>\\r\\n<p>Det er derfor vigtigt at du holder \\u00f8je med d\\u00e6kkenes udvendige udseende for at opdage tydelige tegn p\\u00e5 \\u00e6ldning eller tr\\u00e6rhed. Det kan v\\u00e6re krakeleringer i gummiet p\\u00e5 m\\u00f8nsteret udvendigt, skulder og kant samt deformation mm. Uds\\u00e6dvanlig kraftig \\u00e6ldning af d\\u00e6k kan f\\u00f8re til tab af greb.<\\/p>\\r\\n<h2>4. Hvis dit d\\u00e6k er beskadiget<\\/h2>\\r\\n<p>Dit d\\u00e6k kan blive alvorligt beskadiget, hvis det st\\u00f8der sammen med en solid genstand p\\u00e5 vejen, fx en kantesten, et hul i vejen eller en skarp genstand. Alle synlige perforeringer, snit eller deformationer skal kontrolleres grundigt af en d\\u00e6kspecialist. Kun en fagmand kan sige, om d\\u00e6kket skal repareres, eller om det skal udskiftes. Husk alrdig at bruge beskadigede d\\u00e6lk, eller s\\u00e6k som har k\\u00f8rt uden luft.<\\/p>\\r\\n<h2>5. Hvis du identificerer unormal slitage<\\/h2>\\r\\n<p>Un\\u00f8rmal, uj\\u00e6vn d\\u00e6kslitage, indikerer ofte et mekanisk problem s\\u00e5som forkert hjulsporing eller et problem med afbalancering, hjuloph\\u00e6ng eller gear. Det kan ogs\\u00e5 skyldes at du k\\u00f8rer med forkert d\\u00e6ktryk. Hvis du observerer unormal slitage, skal du kontakte en fagmand.<\\/p>\\r\\n<p>For at undg\\u00e5 uj\\u00e6vn slitage skal du have hjulene sporet og afbalanceret hvert halve \\u00e5r. Det vil ogs\\u00e5 forl\\u00e6nge slidbanens levetid og give dig en mere j\\u00e6vn k\\u00f8rsel. En anden m\\u00e5de at holde slidbanen j\\u00e6vn er ved regelm\\u00e6ssigt at rotere hjulene.<\\/p>\\r\\n<h2>6. Hvis d\\u00e6kkene ikke egner sig til dit k\\u00f8ret\\u00f8j<\\/h2>\\r\\n<p>For at opn\\u00e5 de bedste pr\\u00e6stationer samlet s\\u00e6t, b\\u00f8r du altid bruge de samme d\\u00e6k p\\u00e5 alle hjul. D\\u00e6k med forskellige dimensioner, opbygning og slidgrad kan p\\u00e5virke k\\u00f8ret\\u00f8jets man\\u00f8vrering og stabilitet.<\\/p>\\r\\n<p>Du m\\u00e5 heller ikke blande radial og ikke-radial d\\u00e6k p\\u00e5 et k\\u00f8ret\\u00f8j.<\\/p>\\r\\n<p>\\u00a0<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 15:21:57","created_by":"401","created_by_alias":"","modified":"2015-05-12 15:21:57","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 15:21:57","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(16, 8, 1, '', '2015-05-12 15:27:55', 401, 14354, 'a09e56c75265b94113178e504f0712ed8020cb60', '{"id":8,"asset_id":65,"title":"Europ\\u00e6iske vinterd\\u00e6kregler","alias":"europaeiske-vinterdaekregler","introtext":"<p><img src=\\"images\\/vinter.png\\" alt=\\"vinter\\" width=\\"334\\" height=\\"220\\" \\/><br \\/><br \\/>N\\u00e5r vinteren og skiferien kommer t\\u00e6ttere p\\u00e5, er det tid til at f\\u00e5 styr p\\u00e5 reglerne for vinterd\\u00e6k og vinterudstyr i de lande, man skal bes\\u00f8ge i l\\u00f8beet af vinteren.\\u00a0D\\u00e6kcenter.nu har derfor lavet en oversigt, hvor du kan se reglerne for de mest popul\\u00e6re vinterferiedestinationer: Sverige, Norge, Tyskland, \\u00d8strig, Schweiz, Frankrig og Italien.<\\/p>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\"><img src=\\"images\\/sverige.gif\\" alt=\\"sverige\\" width=\\"164\\" height=\\"101\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Sverige - Vinterd\\u00e6k regler Sverige<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>For k\\u00f8ret\\u00f8jer med en tilladt totalv\\u00e6gt p\\u00e5 under 3500 kg er vinterd\\u00e6k obligatorisk mellem 1. december og 31. marts i tilf\\u00e6lde af vintervej. Dvs. sne eller is p\\u00e5 vejen eller en v\\u00e5d vejoverflade kombineret med temperaturer omkring eller under 0\\u00baC. Dette g\\u00e6lder ogs\\u00e5 for anh\\u00e6ngere. D\\u00e6kkene skal have en m\\u00f8nsterdybde p\\u00e5 minimum 3 mm.<\\/p>\\r\\n<p>Politiet tager den endelig beslutning om, hvorn\\u00e5r der er tale om vintervejr p\\u00e5 specifikke veje. Er der ikke tale om vintervejr p\\u00e5 vejene, m\\u00e5 man principielt gerne k\\u00f8re med sommerd\\u00e6k i perioden mellem mellem 1. december og 31. marts, selvom dette dog ikke anbefales.<\\/p>\\r\\n<p>B\\u00f8den for ikke at k\\u00f8re med vinterd\\u00e6k i vintervejr er 1200 SEK.<\\/p>\\r\\n<p>Reglerne for vinterd\\u00e6k g\\u00e6lder ikke k\\u00f8ret\\u00f8jer med en totalv\\u00e6gt over 3500 kg. S\\u00e5danne k\\u00f8ret\\u00f8jer m\\u00e5 selv i vintervejr k\\u00f8re med sommerd\\u00e6k. I s\\u00e5 fald skal d\\u00e6kkene v\\u00e6re mindst 5 mm dybe.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Pigd\\u00e6k er tilladt mellem 1. oktober og 15. april. Hvis vejr- og vejforholdene kr\\u00e6ver det, er de ogs\\u00e5 tilladt uden for denne periode. Dette vil oftest v\\u00e6re tilf\\u00e6ldet i den nordlige del af landet. Benyttes pigd\\u00e6k, skal de monteres p\\u00e5 alle 4 hjul. For biler med pigd\\u00e6k, der tr\\u00e6kker en anh\\u00e6nger, er det kun n\\u00f8dvendigt at montere pigd\\u00e6k p\\u00e5 anh\\u00e6ngeren, s\\u00e5fremt man k\\u00f8rer p\\u00e5 sne- eller isd\\u00e6kkede veje. Bem\\u00e6rk, at der kan v\\u00e6re enkelte lokale restriktioner for k\\u00f8rsel med pigd\\u00e6k. F.eks. er pigd\\u00e6k ikke tilladt p\\u00e5 Hornsgatan i Stockholm.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Det er tilladt at benytte snek\\u00e6der p\\u00e5 alle typer biler i Sverige, hvis vejr- og vejforhold kr\\u00e6ver det. Der er ingen s\\u00e6rlige fartgr\\u00e6nser for k\\u00f8ret\\u00f8jer med snek\\u00e6der. Det er ikke muligt at leje snek\\u00e6der i Sverige, men de kan k\\u00f8bes.<\\/p>\\r\\n<h3>Andet udstyr<\\/h3>\\r\\n<p>Det er n\\u00f8dvendigt, at bilen har sprinklerv\\u00e6ske med antifrost, ligesom man skal medbringe en skovl til at fjerne sne. Det anbefales ogs\\u00e5 at medbringe et reb, startkabler og sikkerhedsvest.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td style=\\"text-align: justify;\\"><img src=\\"images\\/norge.gif\\" alt=\\"norge\\" width=\\"165\\" height=\\"120\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Norge - Vinterd\\u00e6k regler Norge<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>I den norske f\\u00e6rdselslov st\\u00e5r der: \\"N\\u00e5r f\\u00f8ret g\\u00f8r det n\\u00f8dvendigt, m\\u00e5 et motork\\u00f8ret\\u00f8j ikke bruges, uden at hjulene er sikret tilstr\\u00e6kkeligt vejgreb ved hj\\u00e6lp af pigge, snek\\u00e6der eller lignende\\". Det betyder i praksis, at man om vinteren skal k\\u00f8re med vinterd\\u00e6k eller pigd\\u00e6k. Vinterd\\u00e6k skal monteres p\\u00e5 alle 4 hjul og have en minimumdybde p\\u00e5 3 mm.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Det er tilladt at k\\u00f8re med pigd\\u00e6k fra 1. nov. til f\\u00f8rste s\\u00f8ndag i den f\\u00f8lgende p\\u00e5ske. I de nordlige provinser (Nordland, Troms og Finnmark) er det dog tilladt at k\\u00f8re med pigd\\u00e6k fra 15. okt. til 1. april. Pigd\\u00e6k skal monteres p\\u00e5 alle fire hjul, n\\u00e5r de benyttes. Nogle byer har indf\\u00f8rt afgift for at k\\u00f8re med pigd\\u00e6k.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Man skal medbringe snek\\u00e6der ved k\\u00f8rsel i Norge, da man kan komme i situationer, hvor vinterd\\u00e6k ikke er nok, og da vil lovgivningen kr\\u00e6ve, at man benytter snek\\u00e6der.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\"><img src=\\"images\\/Tyskland.gif\\" alt=\\"Tyskland\\" width=\\"165\\" height=\\"99\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Tyskland - Vinterd\\u00e6k regler Tyskland<\\/strong>\\u00a0<\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>If\\u00f8lge loven skal biler i Tyskland v\\u00e6re udstyret med vinterd\\u00e6k, n\\u00e5r der er sne, snesjap, frost eller is p\\u00e5 vejene. D\\u00e6kkene skal v\\u00e6re vinterd\\u00e6k m\\u00e6rket med M+S og et snefnugssymbol eller v\\u00e6re hel\\u00e5rsd\\u00e6k m\\u00e6rket M+S. Derudover skal man s\\u00f8rge for, at sprinklerv\\u00e6sken er med antifrost. Er bilen ikke udstyret med d\\u00e6k, der passer til vejrforholdene, kan man f\\u00e5 en b\\u00f8de p\\u00e5 40 euro. Hindrer bilen trafikken, fordi den ikke er udstyret med de rigtige d\\u00e6k, kan b\\u00f8den v\\u00e6re 80 euro. Der er ikke s\\u00e6rskilt krav om vinterd\\u00e6k p\\u00e5 anh\\u00e6ngere, men det anbefales.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Det er ikke tilladt at k\\u00f8re med pigd\\u00e6k i Tyskland.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Det er tilladt at benytte snek\\u00e6der. I s\\u00e5 fald er der en fartgr\\u00e6nse p\\u00e5 50 km\\/t. I bjergomr\\u00e5der vil der i vintervejr v\\u00e6re skilte, hvis snek\\u00e6der er p\\u00e5kr\\u00e6vet.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td><img src=\\"images\\/oestrig.gif\\" alt=\\"oestrig\\" width=\\"166\\" height=\\"111\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>\\u00d8strig - Vinterd\\u00e6k regler \\u00d8strig<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>Fra den 1. november til den 15. april skal der v\\u00e6re vinterd\\u00e6k p\\u00e5 bilen, n\\u00e5r det er vinterf\\u00f8re. Det vil sige, n\\u00e5r vejene er d\\u00e6kket af sne, slud eller is. Vinterd\\u00e6kkene skal monteres p\\u00e5 alle 4 hjul, og de skal v\\u00e6re m\\u00e6rket med M+S og have en dybde p\\u00e5 minimum 4 mm. K\\u00f8rsel med sommerd\\u00e6k kan dog accepteres, s\\u00e5fremt man har monteret snek\\u00e6der p\\u00e5 de tr\\u00e6kkende hjul. I s\\u00e5 fald er den anbefalede makshastighed 50 km\\/t. Det er i \\u00f8vrigt f\\u00f8rerens ansvar, at bilen er udstyret med det n\\u00f8dvendige vinterudstyr. Hvis man lejer en bil, skal man derfor selv huske at tjekke, om det p\\u00e5kr\\u00e6vede vinterudstyr forefindes.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Pigd\\u00e6k er tilladt fra 1. oktober til 31. maj, dog kun p\\u00e5 k\\u00f8ret\\u00f8jer op til 3.500 kg. Der skal i s\\u00e5 fald v\\u00e6re pigd\\u00e6k p\\u00e5 alle 4 hjul samt p\\u00e5 en evt. anh\\u00e6nger. Maks. hastighed med pigd\\u00e6k er p\\u00e5 motorvej 100 km\\/t og p\\u00e5 landevej 80 km\\/t.<br \\/>N\\u00e5r man k\\u00f8rer med pigd\\u00e6k, skal der desuden i bagruden p\\u00e5s\\u00e6ttes en \\"pigd\\u00e6ksm\\u00e6rkat\\". Denne kan k\\u00f8bes hos FDMs s\\u00f8sterklub <a class=\\"  \\" href=\\"http:\\/\\/www.oeamtc.at\\/\\" target=\\"_blank\\">\\u00d6AMTC<\\/a>, p\\u00e5 tankstationer mv.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Snek\\u00e6der er tilladt i \\u00d8strig. K\\u00f8rer man med snek\\u00e6der, er den anbefalede maksimumhastighed 50 km\\/t. K\\u00e6der skal have godkendelsen \\u00d6NORM V 5117 for mindre k\\u00f8ret\\u00f8jer og \\u00d6NORM V 5119 for st\\u00f8rre k\\u00f8ret\\u00f8jer.\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0<\\/p>\\r\\n<p>Man kan k\\u00f8be eller l\\u00e5ne snek\\u00e6der p\\u00e5 <a class=\\"  \\" href=\\"http:\\/\\/www.oeamtc.at\\/\\" target=\\"_blank\\">\\u00d6AMTCs<\\/a> kontorer, eller man man leje dem ved alle st\\u00f8rre gr\\u00e6nseovergange.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Specielt for tunge k\\u00f8ret\\u00f8jer<\\/h3>\\r\\n<p>Fra 15. november til 15. marts skal alle k\\u00f8ret\\u00f8jer over 3500 kg k\\u00f8re med vinterd\\u00e6k p\\u00e5 mindst en af k\\u00f8reakslerne og medbringe snek\\u00e6der - uanset om der er sne p\\u00e5 vejen eller ej. Vinterd\\u00e6kkene skal v\\u00e6re m\\u00e6rket M+S, og radiald\\u00e6k skal v\\u00e6re mindst 5 mm dybe, mens diagonald\\u00e6k skal v\\u00e6re mindst 6 mm dybe. Det er obligatorisk at k\\u00f8re med snek\\u00e6der, n\\u00e5r skiltningen indikerer det.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\"><img src=\\"images\\/schweiz.gif\\" alt=\\"schweiz\\" width=\\"165\\" height=\\"165\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Schweiz - Vinterd\\u00e6k regler Schweiz<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>Vinterd\\u00e6k er ikke p\\u00e5budt, men k\\u00f8ret\\u00f8jer, der ikke er udrustet til at k\\u00f8re i vintervejr, kan id\\u00f8mmes b\\u00f8der. I praksis betyder det, at man skal k\\u00f8re med vinterd\\u00e6k og medbringe snek\\u00e6der.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Pigd\\u00e6k er tilladt i perioden fra 1. november til 30. april p\\u00e5 k\\u00f8ret\\u00f8jer under 7500 kg samt p\\u00e5 evt. anh\\u00e6ngere. Piggene p\\u00e5 maks v\\u00e6re 1,5 mm. Det er dog forbudt at k\\u00f8re med pigd\\u00e6k p\\u00e5 motor- og motortrafikveje med undtagelse af San Bernardino- og St. Gotthard-vejtunnelerne, hvor pigd\\u00e6k er tilladt. K\\u00f8ret\\u00f8jer med pigd\\u00e6k m\\u00e5 maks k\\u00f8re 80 km\\/t, hvilket skal angives p\\u00e5 bilen i form af et fartklisterm\\u00e6rke.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Snek\\u00e6der er obligatoriske i omr\\u00e5der, hvor der er skiltet med det. Snek\\u00e6der monteres som minimum p\\u00e5 de tr\\u00e6kkende hjul.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td><img src=\\"images\\/frankrig.gif\\" alt=\\"frankrig\\" width=\\"165\\" height=\\"110\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Frankrig - Vinterd\\u00e6k regler Frankrig<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>Det er ikke obligatorisk at k\\u00f8re med vinterd\\u00e6k i Frankrig, men det anbefales, n\\u00e5r der er sne eller is p\\u00e5 vejene. D\\u00e6km\\u00f8nsteret skal minimum v\\u00e6re 3,5 mm.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Brugen af pigd\\u00e6k er tilladt fra l\\u00f8rdagen f\\u00f8r 1. november til den sidste s\\u00f8ndag i marts p\\u00e5 biler under 3500 kg samt kommercielle passagerk\\u00f8ret\\u00f8jer. Max hastighed ved k\\u00f8rsel med pigd\\u00e6k er 90 km\\/t. Hvis vejrforholdene kr\\u00e6ver det, kan myndighederne udvide perioden for brug af pigd\\u00e6k.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Snek\\u00e6der skal benyttes, n\\u00e5r skiltningen indikerer det. Der kan udstedes b\\u00f8de, hvis man ikke overholder dette. K\\u00f8ret\\u00f8jer med snek\\u00e6der m\\u00e5 ikke k\\u00f8re hurtigere end 50 km\\/t.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\"><img src=\\"images\\/italie.gif\\" alt=\\"italie\\" width=\\"164\\" height=\\"110\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Italien - Vinterd\\u00e6k regler Italien<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>I Aostadalen skal bilen v\\u00e6re udstyret med vinterd\\u00e6k, eller man skal medbringe snek\\u00e6der i perioden 15\\/10 til 15\\/4.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Pigd\\u00e6k er tilladt fra 15\\/11 til 15\\/3 for k\\u00f8ret\\u00f8jer under 3500 kg. Makshastighed p\\u00e5 motorvej er 120 km\\/t, p\\u00e5 landevej 90 km\\/t. K\\u00f8rer man med pigd\\u00e6k skal alle k\\u00f8ret\\u00f8jets hjul v\\u00e6re udstyret med pigd\\u00e6k - ogs\\u00e5 en evt. anh\\u00e6nger. Desuden anbefales st\\u00e6nklapper.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Ved skiltning omkring snek\\u00e6der accepteres b\\u00e5de k\\u00f8rsel med snek\\u00e6der og med vinterd\\u00e6k. Biler udstyret med snek\\u00e6der m\\u00e5 maks k\\u00f8re 50 km\\/t.<\\/p>\\r\\n<h3>\\u00a0<\\/h3>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 15:27:55","created_by":"401","created_by_alias":"","modified":"2015-05-12 15:27:55","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 15:27:55","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0);
INSERT INTO `g2q6h_ucm_history` (`version_id`, `ucm_item_id`, `ucm_type_id`, `version_note`, `save_date`, `editor_user_id`, `character_count`, `sha1_hash`, `version_data`, `keep_forever`) VALUES
(17, 8, 1, '', '2015-05-12 15:29:07', 401, 14408, '6a3d23c83f8249b4ed3066825dd35fd6cce25413', '{"id":8,"asset_id":"65","title":"Vinterd\\u00e6k regler","alias":"europaeiske-vinterdaekregler","introtext":"<h1>Europ\\u00e6iske vinterd\\u00e6kregler<\\/h1>\\r\\n<p><img src=\\"images\\/vinter.png\\" alt=\\"vinter\\" width=\\"334\\" height=\\"220\\" \\/><br \\/><br \\/>N\\u00e5r vinteren og skiferien kommer t\\u00e6ttere p\\u00e5, er det tid til at f\\u00e5 styr p\\u00e5 reglerne for vinterd\\u00e6k og vinterudstyr i de lande, man skal bes\\u00f8ge i l\\u00f8beet af vinteren.\\u00a0D\\u00e6kcenter.nu har derfor lavet en oversigt, hvor du kan se reglerne for de mest popul\\u00e6re vinterferiedestinationer: Sverige, Norge, Tyskland, \\u00d8strig, Schweiz, Frankrig og Italien.<\\/p>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\"><img src=\\"images\\/sverige.gif\\" alt=\\"sverige\\" width=\\"164\\" height=\\"101\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Sverige - Vinterd\\u00e6k regler Sverige<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>For k\\u00f8ret\\u00f8jer med en tilladt totalv\\u00e6gt p\\u00e5 under 3500 kg er vinterd\\u00e6k obligatorisk mellem 1. december og 31. marts i tilf\\u00e6lde af vintervej. Dvs. sne eller is p\\u00e5 vejen eller en v\\u00e5d vejoverflade kombineret med temperaturer omkring eller under 0\\u00baC. Dette g\\u00e6lder ogs\\u00e5 for anh\\u00e6ngere. D\\u00e6kkene skal have en m\\u00f8nsterdybde p\\u00e5 minimum 3 mm.<\\/p>\\r\\n<p>Politiet tager den endelig beslutning om, hvorn\\u00e5r der er tale om vintervejr p\\u00e5 specifikke veje. Er der ikke tale om vintervejr p\\u00e5 vejene, m\\u00e5 man principielt gerne k\\u00f8re med sommerd\\u00e6k i perioden mellem mellem 1. december og 31. marts, selvom dette dog ikke anbefales.<\\/p>\\r\\n<p>B\\u00f8den for ikke at k\\u00f8re med vinterd\\u00e6k i vintervejr er 1200 SEK.<\\/p>\\r\\n<p>Reglerne for vinterd\\u00e6k g\\u00e6lder ikke k\\u00f8ret\\u00f8jer med en totalv\\u00e6gt over 3500 kg. S\\u00e5danne k\\u00f8ret\\u00f8jer m\\u00e5 selv i vintervejr k\\u00f8re med sommerd\\u00e6k. I s\\u00e5 fald skal d\\u00e6kkene v\\u00e6re mindst 5 mm dybe.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Pigd\\u00e6k er tilladt mellem 1. oktober og 15. april. Hvis vejr- og vejforholdene kr\\u00e6ver det, er de ogs\\u00e5 tilladt uden for denne periode. Dette vil oftest v\\u00e6re tilf\\u00e6ldet i den nordlige del af landet. Benyttes pigd\\u00e6k, skal de monteres p\\u00e5 alle 4 hjul. For biler med pigd\\u00e6k, der tr\\u00e6kker en anh\\u00e6nger, er det kun n\\u00f8dvendigt at montere pigd\\u00e6k p\\u00e5 anh\\u00e6ngeren, s\\u00e5fremt man k\\u00f8rer p\\u00e5 sne- eller isd\\u00e6kkede veje. Bem\\u00e6rk, at der kan v\\u00e6re enkelte lokale restriktioner for k\\u00f8rsel med pigd\\u00e6k. F.eks. er pigd\\u00e6k ikke tilladt p\\u00e5 Hornsgatan i Stockholm.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Det er tilladt at benytte snek\\u00e6der p\\u00e5 alle typer biler i Sverige, hvis vejr- og vejforhold kr\\u00e6ver det. Der er ingen s\\u00e6rlige fartgr\\u00e6nser for k\\u00f8ret\\u00f8jer med snek\\u00e6der. Det er ikke muligt at leje snek\\u00e6der i Sverige, men de kan k\\u00f8bes.<\\/p>\\r\\n<h3>Andet udstyr<\\/h3>\\r\\n<p>Det er n\\u00f8dvendigt, at bilen har sprinklerv\\u00e6ske med antifrost, ligesom man skal medbringe en skovl til at fjerne sne. Det anbefales ogs\\u00e5 at medbringe et reb, startkabler og sikkerhedsvest.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td style=\\"text-align: justify;\\"><img src=\\"images\\/norge.gif\\" alt=\\"norge\\" width=\\"165\\" height=\\"120\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Norge - Vinterd\\u00e6k regler Norge<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>I den norske f\\u00e6rdselslov st\\u00e5r der: \\"N\\u00e5r f\\u00f8ret g\\u00f8r det n\\u00f8dvendigt, m\\u00e5 et motork\\u00f8ret\\u00f8j ikke bruges, uden at hjulene er sikret tilstr\\u00e6kkeligt vejgreb ved hj\\u00e6lp af pigge, snek\\u00e6der eller lignende\\". Det betyder i praksis, at man om vinteren skal k\\u00f8re med vinterd\\u00e6k eller pigd\\u00e6k. Vinterd\\u00e6k skal monteres p\\u00e5 alle 4 hjul og have en minimumdybde p\\u00e5 3 mm.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Det er tilladt at k\\u00f8re med pigd\\u00e6k fra 1. nov. til f\\u00f8rste s\\u00f8ndag i den f\\u00f8lgende p\\u00e5ske. I de nordlige provinser (Nordland, Troms og Finnmark) er det dog tilladt at k\\u00f8re med pigd\\u00e6k fra 15. okt. til 1. april. Pigd\\u00e6k skal monteres p\\u00e5 alle fire hjul, n\\u00e5r de benyttes. Nogle byer har indf\\u00f8rt afgift for at k\\u00f8re med pigd\\u00e6k.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Man skal medbringe snek\\u00e6der ved k\\u00f8rsel i Norge, da man kan komme i situationer, hvor vinterd\\u00e6k ikke er nok, og da vil lovgivningen kr\\u00e6ve, at man benytter snek\\u00e6der.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\"><img src=\\"images\\/Tyskland.gif\\" alt=\\"Tyskland\\" width=\\"165\\" height=\\"99\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Tyskland - Vinterd\\u00e6k regler Tyskland<\\/strong>\\u00a0<\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>If\\u00f8lge loven skal biler i Tyskland v\\u00e6re udstyret med vinterd\\u00e6k, n\\u00e5r der er sne, snesjap, frost eller is p\\u00e5 vejene. D\\u00e6kkene skal v\\u00e6re vinterd\\u00e6k m\\u00e6rket med M+S og et snefnugssymbol eller v\\u00e6re hel\\u00e5rsd\\u00e6k m\\u00e6rket M+S. Derudover skal man s\\u00f8rge for, at sprinklerv\\u00e6sken er med antifrost. Er bilen ikke udstyret med d\\u00e6k, der passer til vejrforholdene, kan man f\\u00e5 en b\\u00f8de p\\u00e5 40 euro. Hindrer bilen trafikken, fordi den ikke er udstyret med de rigtige d\\u00e6k, kan b\\u00f8den v\\u00e6re 80 euro. Der er ikke s\\u00e6rskilt krav om vinterd\\u00e6k p\\u00e5 anh\\u00e6ngere, men det anbefales.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Det er ikke tilladt at k\\u00f8re med pigd\\u00e6k i Tyskland.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Det er tilladt at benytte snek\\u00e6der. I s\\u00e5 fald er der en fartgr\\u00e6nse p\\u00e5 50 km\\/t. I bjergomr\\u00e5der vil der i vintervejr v\\u00e6re skilte, hvis snek\\u00e6der er p\\u00e5kr\\u00e6vet.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td><img src=\\"images\\/oestrig.gif\\" alt=\\"oestrig\\" width=\\"166\\" height=\\"111\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>\\u00d8strig - Vinterd\\u00e6k regler \\u00d8strig<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>Fra den 1. november til den 15. april skal der v\\u00e6re vinterd\\u00e6k p\\u00e5 bilen, n\\u00e5r det er vinterf\\u00f8re. Det vil sige, n\\u00e5r vejene er d\\u00e6kket af sne, slud eller is. Vinterd\\u00e6kkene skal monteres p\\u00e5 alle 4 hjul, og de skal v\\u00e6re m\\u00e6rket med M+S og have en dybde p\\u00e5 minimum 4 mm. K\\u00f8rsel med sommerd\\u00e6k kan dog accepteres, s\\u00e5fremt man har monteret snek\\u00e6der p\\u00e5 de tr\\u00e6kkende hjul. I s\\u00e5 fald er den anbefalede makshastighed 50 km\\/t. Det er i \\u00f8vrigt f\\u00f8rerens ansvar, at bilen er udstyret med det n\\u00f8dvendige vinterudstyr. Hvis man lejer en bil, skal man derfor selv huske at tjekke, om det p\\u00e5kr\\u00e6vede vinterudstyr forefindes.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Pigd\\u00e6k er tilladt fra 1. oktober til 31. maj, dog kun p\\u00e5 k\\u00f8ret\\u00f8jer op til 3.500 kg. Der skal i s\\u00e5 fald v\\u00e6re pigd\\u00e6k p\\u00e5 alle 4 hjul samt p\\u00e5 en evt. anh\\u00e6nger. Maks. hastighed med pigd\\u00e6k er p\\u00e5 motorvej 100 km\\/t og p\\u00e5 landevej 80 km\\/t.<br \\/>N\\u00e5r man k\\u00f8rer med pigd\\u00e6k, skal der desuden i bagruden p\\u00e5s\\u00e6ttes en \\"pigd\\u00e6ksm\\u00e6rkat\\". Denne kan k\\u00f8bes hos FDMs s\\u00f8sterklub <a class=\\"  \\" href=\\"http:\\/\\/www.oeamtc.at\\/\\" target=\\"_blank\\">\\u00d6AMTC<\\/a>, p\\u00e5 tankstationer mv.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Snek\\u00e6der er tilladt i \\u00d8strig. K\\u00f8rer man med snek\\u00e6der, er den anbefalede maksimumhastighed 50 km\\/t. K\\u00e6der skal have godkendelsen \\u00d6NORM V 5117 for mindre k\\u00f8ret\\u00f8jer og \\u00d6NORM V 5119 for st\\u00f8rre k\\u00f8ret\\u00f8jer.\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0\\u00a0<\\/p>\\r\\n<p>Man kan k\\u00f8be eller l\\u00e5ne snek\\u00e6der p\\u00e5 <a class=\\"  \\" href=\\"http:\\/\\/www.oeamtc.at\\/\\" target=\\"_blank\\">\\u00d6AMTCs<\\/a> kontorer, eller man man leje dem ved alle st\\u00f8rre gr\\u00e6nseovergange.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Specielt for tunge k\\u00f8ret\\u00f8jer<\\/h3>\\r\\n<p>Fra 15. november til 15. marts skal alle k\\u00f8ret\\u00f8jer over 3500 kg k\\u00f8re med vinterd\\u00e6k p\\u00e5 mindst en af k\\u00f8reakslerne og medbringe snek\\u00e6der - uanset om der er sne p\\u00e5 vejen eller ej. Vinterd\\u00e6kkene skal v\\u00e6re m\\u00e6rket M+S, og radiald\\u00e6k skal v\\u00e6re mindst 5 mm dybe, mens diagonald\\u00e6k skal v\\u00e6re mindst 6 mm dybe. Det er obligatorisk at k\\u00f8re med snek\\u00e6der, n\\u00e5r skiltningen indikerer det.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\"><img src=\\"images\\/schweiz.gif\\" alt=\\"schweiz\\" width=\\"165\\" height=\\"165\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Schweiz - Vinterd\\u00e6k regler Schweiz<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>Vinterd\\u00e6k er ikke p\\u00e5budt, men k\\u00f8ret\\u00f8jer, der ikke er udrustet til at k\\u00f8re i vintervejr, kan id\\u00f8mmes b\\u00f8der. I praksis betyder det, at man skal k\\u00f8re med vinterd\\u00e6k og medbringe snek\\u00e6der.<\\/p>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Pigd\\u00e6k er tilladt i perioden fra 1. november til 30. april p\\u00e5 k\\u00f8ret\\u00f8jer under 7500 kg samt p\\u00e5 evt. anh\\u00e6ngere. Piggene p\\u00e5 maks v\\u00e6re 1,5 mm. Det er dog forbudt at k\\u00f8re med pigd\\u00e6k p\\u00e5 motor- og motortrafikveje med undtagelse af San Bernardino- og St. Gotthard-vejtunnelerne, hvor pigd\\u00e6k er tilladt. K\\u00f8ret\\u00f8jer med pigd\\u00e6k m\\u00e5 maks k\\u00f8re 80 km\\/t, hvilket skal angives p\\u00e5 bilen i form af et fartklisterm\\u00e6rke.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Snek\\u00e6der er obligatoriske i omr\\u00e5der, hvor der er skiltet med det. Snek\\u00e6der monteres som minimum p\\u00e5 de tr\\u00e6kkende hjul.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td><img src=\\"images\\/frankrig.gif\\" alt=\\"frankrig\\" width=\\"165\\" height=\\"110\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Frankrig - Vinterd\\u00e6k regler Frankrig<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>Det er ikke obligatorisk at k\\u00f8re med vinterd\\u00e6k i Frankrig, men det anbefales, n\\u00e5r der er sne eller is p\\u00e5 vejene. D\\u00e6km\\u00f8nsteret skal minimum v\\u00e6re 3,5 mm.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Brugen af pigd\\u00e6k er tilladt fra l\\u00f8rdagen f\\u00f8r 1. november til den sidste s\\u00f8ndag i marts p\\u00e5 biler under 3500 kg samt kommercielle passagerk\\u00f8ret\\u00f8jer. Max hastighed ved k\\u00f8rsel med pigd\\u00e6k er 90 km\\/t. Hvis vejrforholdene kr\\u00e6ver det, kan myndighederne udvide perioden for brug af pigd\\u00e6k.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Snek\\u00e6der skal benyttes, n\\u00e5r skiltningen indikerer det. Der kan udstedes b\\u00f8de, hvis man ikke overholder dette. K\\u00f8ret\\u00f8jer med snek\\u00e6der m\\u00e5 ikke k\\u00f8re hurtigere end 50 km\\/t.<\\/p>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<table style=\\"width: 100%;\\" border=\\"0\\" cellspacing=\\"0\\" cellpadding=\\"0\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td valign=\\"top\\"><img src=\\"images\\/italie.gif\\" alt=\\"italie\\" width=\\"164\\" height=\\"110\\" \\/><\\/td>\\r\\n<td>\\r\\n<h2><strong>Italien - Vinterd\\u00e6k regler Italien<\\/strong><\\/h2>\\r\\n<p>\\u00a0<\\/p>\\r\\n<h3>Vinterd\\u00e6k<\\/h3>\\r\\n<p>I Aostadalen skal bilen v\\u00e6re udstyret med vinterd\\u00e6k, eller man skal medbringe snek\\u00e6der i perioden 15\\/10 til 15\\/4.<\\/p>\\r\\n<h3>Pigd\\u00e6k<\\/h3>\\r\\n<p>Pigd\\u00e6k er tilladt fra 15\\/11 til 15\\/3 for k\\u00f8ret\\u00f8jer under 3500 kg. Makshastighed p\\u00e5 motorvej er 120 km\\/t, p\\u00e5 landevej 90 km\\/t. K\\u00f8rer man med pigd\\u00e6k skal alle k\\u00f8ret\\u00f8jets hjul v\\u00e6re udstyret med pigd\\u00e6k - ogs\\u00e5 en evt. anh\\u00e6nger. Desuden anbefales st\\u00e6nklapper.<\\/p>\\r\\n<h3>Snek\\u00e6der<\\/h3>\\r\\n<p>Ved skiltning omkring snek\\u00e6der accepteres b\\u00e5de k\\u00f8rsel med snek\\u00e6der og med vinterd\\u00e6k. Biler udstyret med snek\\u00e6der m\\u00e5 maks k\\u00f8re 50 km\\/t.<\\/p>\\r\\n<h3>\\u00a0<\\/h3>\\r\\n<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 15:27:55","created_by":"401","created_by_alias":"","modified":"2015-05-12 15:29:07","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-12 15:28:41","publish_up":"2015-05-12 15:27:55","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(18, 9, 1, '', '2015-05-12 17:17:46', 401, 3599, '21c0b73d794486eb0205ccab49022e198be167a7', '{"id":9,"asset_id":66,"title":"Bliv forhandler","alias":"bliv-forhandler","introtext":"<h1>VI HAR ET PAR SP\\u00d8RGSM\\u00c5L DER KAN \\u00c6NDRE DIN BUTIK...<\\/h1>\\r\\n<ul>\\r\\n<li>S\\u00e6lger du d\\u00e6k, men kunne du t\\u00e6nke dig at s\\u00e6lge mange d\\u00e6k ?<\\/li>\\r\\n<li>Og kunne du t\\u00e6nke dig et system, som g\\u00f8r det nemt, enkelt og ensartet hver gang ?<\\/li>\\r\\n<li>Vil du have adgang til en af Danmarks st\\u00f8rste d\\u00e6k leverand\\u00f8rer med mere end 40 d\\u00e6km\\u00e6rker ? se alle m\\u00e6rker <a href=\\"..\\/index.php?option=com_content&amp;view=category&amp;layout=daek-faelge&amp;id=11&amp;Itemid=27\\">HER<\\/a><\\/li>\\r\\n<li>Og samtidig blive synlig for dine kunder ?<\\/li>\\r\\n<li>Intet gebyr, ingen binding, ingen risiko.<\\/li>\\r\\n<li>Kick Back p\\u00e5 dit \\u00e5rs k\\u00f8b<\\/li>\\r\\n<\\/ul>\\r\\n<h2>Noget af det vi tit h\\u00f8rer i d\\u00e6kbranchen er:<\\/h2>\\r\\n<ul>\\r\\n<li>Vi skal altid regne tilbud ud til kunder... \\u2013 DET TAGER TID!!!!<\\/li>\\r\\n<li>Vores kunder kan ikke se hvilke d\\u00e6k m\\u00e6rker vi har p\\u00e5 lager...<\\/li>\\r\\n<li>For at f\\u00e5 en god rabat, skal vi k\\u00f8be et stort d\\u00e6k lager hjem... Kapital binding!!!!<\\/li>\\r\\n<li>Vi har ikke plads til et d\\u00e6k lager...<\\/li>\\r\\n<li>Vi har ikke tid til at lave en lagerstyring, og vedligeholde den...<\\/li>\\r\\n<li>Vi er ikke synlige som d\\u00e6kcenter...<\\/li>\\r\\n<li>Er vi med i en d\\u00e6kk\\u00e6de, skal andre bestemme vores pris...<\\/li>\\r\\n<\\/ul>\\r\\n<p>Kunne du t\\u00e6nke dig at blive D\\u00c6KCENTER, med de fordele vi kan tilbyde, og helt selv kunne bestemme over dit \\u201dD\\u00c6KCENTER\\u201d ?<\\/p>\\r\\n<p>Vel og m\\u00e6rke uden at skulle bruge penge p\\u00e5 opstart, k\\u00f8b af system, bruge tid p\\u00e5 vedligeholdelse \\u2013 blot bruge kr\\u00e6fterne p\\u00e5 at s\\u00e6lge d\\u00e6k, og derved f\\u00e5 nye og flere kunder i butikken ?<\\/p>\\r\\n<p>Hvis du siger ja til dette, s\\u00e5 er D\\u00c6KCENTER noget for dig! Kontakt os p\\u00e5 <a href=\\"mailto:info@daekcenter.nu\\">info@daekcenter.nu<\\/a><\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 17:17:46","created_by":"401","created_by_alias":"","modified":"2015-05-12 17:17:46","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 17:17:46","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(19, 10, 1, '', '2015-05-12 17:24:36', 401, 5849, 'effa049bd923d7494466e831d53345bee014196f', '{"id":10,"asset_id":67,"title":"F\\u00c5 KREDIT - RENTEFRIT","alias":"fa-kredit-rentefrit","introtext":"<h1>F\\u00c5 KREDIT - RENTEFRIT<\\/h1>\\r\\n<img class=\\"mt20\\" src=\\"images\\/D\\u00e6kcenter_kort.jpg\\" alt=\\"\\" width=\\"667\\" height=\\"422\\" \\/>\\r\\n<h3>MED ET D\\u00c6KCENTER KORT HAR DU ALTID L\\u00d8BENDE M\\u00c5NED +30 DAGES OMKOSTNINGSFRI KREDIT OG MULIGHED FOR OP TIL 12 M\\u00c5NEDERS RENTEFRI KREDIT<\\/h3>\\r\\n<h4>TILBUD FRA 7\\/4 - 31\\/5 - K\\u00d8B NU OG BETAL 1. SEPTEMBER 2015 - SEND PENGEPUNGEN P\\u00c5 FERIE OG VENT MED AT BETALE DIN REGNING - S\\u00d8G ONLINE<\\/h4>\\r\\n<p>D\\u00c6KCENTER tilbyder - i samarbejde med Resurs Bank - muligheden for et D\\u00c6KCENTER KORT - SOM KAN BRUGES TIL ALT - D\\u00c6K-F\\u00c6LGE-SERVICE-REPARATION MM<\\/p>\\r\\n<p>D\\u00c6KCENTER KORT er et fleksibelt alternativ til dig, som selv \\u00f8nsker at bestemme, hvordan du vil betale. Med D\\u00c6KCENTER KORT har du altid l\\u00f8bende m\\u00e5ned + 30 dages kredit p\\u00e5 dine k\\u00f8b, og f\\u00f8rst derefter beslutter du dig for, hvorvidt du \\u00f8nsker at indbetale hele saldoen eller om du vil dele betalingen yderligere op. Med valg af l\\u00f8betid op til 12 m\\u00e5neder tilskrives der ingen renter. Dine muligheder for betaling oplyses sammen med det f\\u00f8rste indbetalingskort, som du modtager m\\u00e5neden efter dit k\\u00f8b. V\\u00e6lger du at indbetale hele bel\\u00f8bet, till\\u00e6gges der ingen renter eller gebyrer.<\\/p>\\r\\n<a class=\\"btn btnCredit\\" href=\\"https:\\/\\/apponline.resurs.com\\/form\\/dk29500\\" target=\\"_blank\\">S\\u00d8G RENTEFRI KREDIT<\\/a> <a class=\\"btn btnCredit\\" href=\\"https:\\/\\/secure.resurs.se\\/priceinfo\\/prisskyltning.html?countryCode=DK&amp;representativeId=29500&amp;authorizedBankproductId=DC155069&amp;creditAmount=10000\\" target=\\"_blank\\">Beregn hvad det koster<\\/a>\\r\\n<p class=\\"mt20\\">I tabellen herunder kan du se eksempler p\\u00e5, hvad de m\\u00e5nedlige omkostninger bliver med forskellige betalingsperioder. Den m\\u00e5nedlige mindstebetaling skal dog minimum altid udg\\u00f8re kr. 150,00<\\/p>\\r\\n<div class=\\"table-responsive\\">\\r\\n<table class=\\"table table-bordered table3\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td>Omkostninger<\\/td>\\r\\n<td>L\\u00f8bende md.<br \\/><br \\/>+ 1 md.<\\/td>\\r\\n<td>6 mdr.<\\/td>\\r\\n<td>12 mdr.<\\/td>\\r\\n<td>24 mdr.<\\/td>\\r\\n<td>36 mdr.<\\/td>\\r\\n<td>48 mdr.<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>Debitorrente<\\/td>\\r\\n<td>0 %<\\/td>\\r\\n<td>0 %<\\/td>\\r\\n<td>0 %<\\/td>\\r\\n<td>9,96 %<\\/td>\\r\\n<td>12,96 %<\\/td>\\r\\n<td>16,96 %<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>Adm. afgift\\/md<\\/td>\\r\\n<td>Kr. 0,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>Oprettelse<\\/td>\\r\\n<td>Kr. 0,00<\\/td>\\r\\n<td>Kr. 195,00<\\/td>\\r\\n<td>Kr. 395,00<\\/td>\\r\\n<td>Kr. 395,00<\\/td>\\r\\n<td>Kr. 395,00<\\/td>\\r\\n<td>Kr. 395,00<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<\\/div>\\r\\n<p>Kreditramme kr. 1.000 - kr. 40.000<br \\/> Evt. oprettelsesgebyr tilskrives saldoen i m\\u00e5ned 2 efter valg af betalingsperiode.<\\/p>\\r\\n<p>Repr\\u00e6sentativt eksempel<br \\/> Kreditbel\\u00f8b: kr. 15 000,-<br \\/> Kredittid og afdragsperiode: 24 mdr.<\\/p>\\r\\n<div class=\\"table-responsive\\">\\r\\n<table class=\\"table table3 table-bordered\\">\\r\\n<thead>\\r\\n<tr><th>Debitorrente<\\/th><th>Samlet kreditbel\\u00f8b<\\/th><th>\\u00c5OP<\\/th><th>Kreditomkostninger<\\/th><th>M\\u00e5nedlig ydelse<\\/th><th>Totalbel\\u00f8b.<\\/th><\\/tr>\\r\\n<\\/thead>\\r\\n<tbody>\\r\\n<tr>\\r\\n<td>9,96 %<\\/td>\\r\\n<td>Kr. 15.000<\\/td>\\r\\n<td>17,2 %<\\/td>\\r\\n<td>Kr. 2.724<\\/td>\\r\\n<td>Kr. 745<\\/td>\\r\\n<td>Kr. 17.724<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<\\/div>\\r\\n<p>Sp\\u00f8rgsm\\u00e5l vedr. finansiering?<br \\/> Kontakt Resurs Banks kundeservice p\\u00e5 telefon 33 32 43 60 eller <a href=\\"mailto:kundservice@resurs.dk\\">kundservice@resurs.dk<\\/a><br \\/> Standardiserede europ\\u00e6iske forbrugerkreditoplysning (SEF), tryk <a class=\\"underline\\" href=\\"https:\\/\\/documenthandler.resurs.com\\/Dokument.pdf?kedja=29500&amp;land=DK&amp;language=da&amp;bankprodukt=DC155069\\">her<\\/a><br \\/> Almindelige kontobetingelser, tryk <a class=\\"underline\\" href=\\"https:\\/\\/secure.resurs.se\\/documenthandler\\/Dokument.pdf?customerType=natural&amp;docType=commonTerms&amp;land=DK&amp;language=da\\">her<\\/a><\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 17:24:36","created_by":"401","created_by_alias":"","modified":"2015-05-12 17:24:36","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 17:24:36","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(20, 10, 1, '', '2015-05-12 17:25:48', 401, 5828, '3d1c2f80c495016c0e8ee57664eb2baf592edd06', '{"id":10,"asset_id":"67","title":"F\\u00c5 KREDIT - RENTEFRIT","alias":"fa-kredit-rentefrit","introtext":"<img class=\\"mt20\\" src=\\"images\\/D\\u00e6kcenter_kort.jpg\\" alt=\\"\\" width=\\"667\\" height=\\"422\\" \\/>\\r\\n<h3>MED ET D\\u00c6KCENTER KORT HAR DU ALTID L\\u00d8BENDE M\\u00c5NED +30 DAGES OMKOSTNINGSFRI KREDIT OG MULIGHED FOR OP TIL 12 M\\u00c5NEDERS RENTEFRI KREDIT<\\/h3>\\r\\n<h4>TILBUD FRA 7\\/4 - 31\\/5 - K\\u00d8B NU OG BETAL 1. SEPTEMBER 2015 - SEND PENGEPUNGEN P\\u00c5 FERIE OG VENT MED AT BETALE DIN REGNING - S\\u00d8G ONLINE<\\/h4>\\r\\n<p>D\\u00c6KCENTER tilbyder - i samarbejde med Resurs Bank - muligheden for et D\\u00c6KCENTER KORT - SOM KAN BRUGES TIL ALT - D\\u00c6K-F\\u00c6LGE-SERVICE-REPARATION MM<\\/p>\\r\\n<p>D\\u00c6KCENTER KORT er et fleksibelt alternativ til dig, som selv \\u00f8nsker at bestemme, hvordan du vil betale. Med D\\u00c6KCENTER KORT har du altid l\\u00f8bende m\\u00e5ned + 30 dages kredit p\\u00e5 dine k\\u00f8b, og f\\u00f8rst derefter beslutter du dig for, hvorvidt du \\u00f8nsker at indbetale hele saldoen eller om du vil dele betalingen yderligere op. Med valg af l\\u00f8betid op til 12 m\\u00e5neder tilskrives der ingen renter. Dine muligheder for betaling oplyses sammen med det f\\u00f8rste indbetalingskort, som du modtager m\\u00e5neden efter dit k\\u00f8b. V\\u00e6lger du at indbetale hele bel\\u00f8bet, till\\u00e6gges der ingen renter eller gebyrer.<\\/p>\\r\\n<a class=\\"btn btnCredit\\" href=\\"https:\\/\\/apponline.resurs.com\\/form\\/dk29500\\" target=\\"_blank\\">S\\u00d8G RENTEFRI KREDIT<\\/a> <a class=\\"btn btnCredit\\" href=\\"https:\\/\\/secure.resurs.se\\/priceinfo\\/prisskyltning.html?countryCode=DK&amp;representativeId=29500&amp;authorizedBankproductId=DC155069&amp;creditAmount=10000\\" target=\\"_blank\\">Beregn hvad det koster<\\/a>\\r\\n<p class=\\"mt20\\">I tabellen herunder kan du se eksempler p\\u00e5, hvad de m\\u00e5nedlige omkostninger bliver med forskellige betalingsperioder. Den m\\u00e5nedlige mindstebetaling skal dog minimum altid udg\\u00f8re kr. 150,00<\\/p>\\r\\n<div class=\\"table-responsive\\">\\r\\n<table class=\\"table table-bordered table3\\">\\r\\n<tbody>\\r\\n<tr>\\r\\n<td>Omkostninger<\\/td>\\r\\n<td>L\\u00f8bende md.<br \\/><br \\/>+ 1 md.<\\/td>\\r\\n<td>6 mdr.<\\/td>\\r\\n<td>12 mdr.<\\/td>\\r\\n<td>24 mdr.<\\/td>\\r\\n<td>36 mdr.<\\/td>\\r\\n<td>48 mdr.<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>Debitorrente<\\/td>\\r\\n<td>0 %<\\/td>\\r\\n<td>0 %<\\/td>\\r\\n<td>0 %<\\/td>\\r\\n<td>9,96 %<\\/td>\\r\\n<td>12,96 %<\\/td>\\r\\n<td>16,96 %<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>Adm. afgift\\/md<\\/td>\\r\\n<td>Kr. 0,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<td>Kr. 35,00<\\/td>\\r\\n<\\/tr>\\r\\n<tr>\\r\\n<td>Oprettelse<\\/td>\\r\\n<td>Kr. 0,00<\\/td>\\r\\n<td>Kr. 195,00<\\/td>\\r\\n<td>Kr. 395,00<\\/td>\\r\\n<td>Kr. 395,00<\\/td>\\r\\n<td>Kr. 395,00<\\/td>\\r\\n<td>Kr. 395,00<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<\\/div>\\r\\n<p>Kreditramme kr. 1.000 - kr. 40.000<br \\/> Evt. oprettelsesgebyr tilskrives saldoen i m\\u00e5ned 2 efter valg af betalingsperiode.<\\/p>\\r\\n<p>Repr\\u00e6sentativt eksempel<br \\/> Kreditbel\\u00f8b: kr. 15 000,-<br \\/> Kredittid og afdragsperiode: 24 mdr.<\\/p>\\r\\n<div class=\\"table-responsive\\">\\r\\n<table class=\\"table table3 table-bordered\\">\\r\\n<thead>\\r\\n<tr><th>Debitorrente<\\/th><th>Samlet kreditbel\\u00f8b<\\/th><th>\\u00c5OP<\\/th><th>Kreditomkostninger<\\/th><th>M\\u00e5nedlig ydelse<\\/th><th>Totalbel\\u00f8b.<\\/th><\\/tr>\\r\\n<\\/thead>\\r\\n<tbody>\\r\\n<tr>\\r\\n<td>9,96 %<\\/td>\\r\\n<td>Kr. 15.000<\\/td>\\r\\n<td>17,2 %<\\/td>\\r\\n<td>Kr. 2.724<\\/td>\\r\\n<td>Kr. 745<\\/td>\\r\\n<td>Kr. 17.724<\\/td>\\r\\n<\\/tr>\\r\\n<\\/tbody>\\r\\n<\\/table>\\r\\n<\\/div>\\r\\n<p>Sp\\u00f8rgsm\\u00e5l vedr. finansiering?<br \\/> Kontakt Resurs Banks kundeservice p\\u00e5 telefon 33 32 43 60 eller <a href=\\"mailto:kundservice@resurs.dk\\">kundservice@resurs.dk<\\/a><br \\/> Standardiserede europ\\u00e6iske forbrugerkreditoplysning (SEF), tryk <a class=\\"underline\\" href=\\"https:\\/\\/documenthandler.resurs.com\\/Dokument.pdf?kedja=29500&amp;land=DK&amp;language=da&amp;bankprodukt=DC155069\\">her<\\/a><br \\/> Almindelige kontobetingelser, tryk <a class=\\"underline\\" href=\\"https:\\/\\/secure.resurs.se\\/documenthandler\\/Dokument.pdf?customerType=natural&amp;docType=commonTerms&amp;land=DK&amp;language=da\\">her<\\/a><\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-05-12 17:24:36","created_by":"401","created_by_alias":"","modified":"2015-05-12 17:25:48","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-12 17:25:35","publish_up":"2015-05-12 17:24:36","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"1","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(21, 8, 5, '', '2015-05-12 17:36:23', 401, 547, '7725c3210a150efb506dda245da4d895bc91ed09', '{"id":8,"asset_id":68,"parent_id":"1","lft":"11","rgt":12,"level":1,"path":null,"extension":"com_content","title":"Store","alias":"store","note":"","description":"","published":"1","checked_out":null,"checked_out_time":null,"access":"1","params":"{\\"category_layout\\":\\"\\",\\"image\\":\\"\\",\\"image_alt\\":\\"\\"}","metadesc":"","metakey":"","metadata":"{\\"author\\":\\"\\",\\"robots\\":\\"\\"}","created_user_id":"401","created_time":"2015-05-12 17:36:23","modified_user_id":null,"modified_time":"2015-05-12 17:36:23","hits":"0","language":"*","version":null}', 0),
(22, 9, 5, '', '2015-05-12 17:36:49', 401, 551, 'ce33c4f326e1ebec82fb0e73df551cc3bace2719', '{"id":9,"asset_id":69,"parent_id":"8","lft":"12","rgt":13,"level":2,"path":null,"extension":"com_content","title":"JYLLAND","alias":"jylland","note":"","description":"","published":"1","checked_out":null,"checked_out_time":null,"access":"1","params":"{\\"category_layout\\":\\"\\",\\"image\\":\\"\\",\\"image_alt\\":\\"\\"}","metadesc":"","metakey":"","metadata":"{\\"author\\":\\"\\",\\"robots\\":\\"\\"}","created_user_id":"401","created_time":"2015-05-12 17:36:49","modified_user_id":null,"modified_time":"2015-05-12 17:36:49","hits":"0","language":"*","version":null}', 0),
(23, 11, 1, '', '2015-05-12 17:43:31', 401, 1881, 'a3d13da866b9748fdac080b5038f02e932187a0f', '{"id":11,"asset_id":70,"title":"Aalestrup","alias":"aalestrup","introtext":"Elmeg\\u00e5rdsvej 1 <br \\/>9620 Aalestrup<br \\/> Tlf. 98 64 23 33<br \\/> <a href=\\"http:\\/\\/www.3s-biler.dk\\/\\">www.3s-biler.dk\\/<\\/a>","fulltext":"\\u00c5bningstider:\\r\\n<p>Mandag - torsdag: 8.00 - 16.30 <br \\/>Fredag: 8.00 - 14.45<\\/p>","state":1,"catid":"2","created":"2015-05-12 17:43:31","created_by":"401","created_by_alias":"","modified":"2015-05-12 17:43:31","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-05-12 17:43:31","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(24, 11, 1, '', '2015-05-12 17:43:44', 401, 1900, 'c8a776ecfedbe5296fee69a27dff443c689677ea', '{"id":11,"asset_id":"70","title":"Aalestrup","alias":"aalestrup","introtext":"Elmeg\\u00e5rdsvej 1 <br \\/>9620 Aalestrup<br \\/> Tlf. 98 64 23 33<br \\/> <a href=\\"http:\\/\\/www.3s-biler.dk\\/\\">www.3s-biler.dk\\/<\\/a>","fulltext":"\\u00c5bningstider:\\r\\n<p>Mandag - torsdag: 8.00 - 16.30 <br \\/>Fredag: 8.00 - 14.45<\\/p>","state":1,"catid":"9","created":"2015-05-12 17:43:31","created_by":"401","created_by_alias":"","modified":"2015-05-12 17:43:44","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-12 17:43:38","publish_up":"2015-05-12 17:43:31","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(25, 11, 1, '', '2015-05-12 17:48:27', 401, 1934, 'c899eb270b9535c7fe4f1bd49b34a87100118510', '{"id":11,"asset_id":"70","title":"Aalestrup","alias":"aalestrup","introtext":"<h3>3S Biler<\\/h3>\\r\\n<p>Elmeg\\u00e5rdsvej 1 <br \\/>9620 Aalestrup<br \\/> Tlf. 98 64 23 33<br \\/> <a href=\\"http:\\/\\/www.3s-biler.dk\\/\\">www.3s-biler.dk\\/<\\/a><\\/p>\\r\\n","fulltext":"\\u00c5bningstider:\\r\\n<p>Mandag - torsdag: 8.00 - 16.30 <br \\/>Fredag: 8.00 - 14.45<\\/p>","state":1,"catid":"9","created":"2015-05-12 17:43:31","created_by":"401","created_by_alias":"","modified":"2015-05-12 17:48:27","modified_by":"401","checked_out":"401","checked_out_time":"2015-05-12 17:47:50","publish_up":"2015-05-12 17:43:31","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":3,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_updates`
--

CREATE TABLE IF NOT EXISTS `g2q6h_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  `extra_query` varchar(1000) DEFAULT '',
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Available Updates' AUTO_INCREMENT=60 ;

--
-- Dumping data for table `g2q6h_updates`
--

INSERT INTO `g2q6h_updates` (`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`, `extra_query`) VALUES
(1, 3, 0, 'Malay', '', 'pkg_ms-MY', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/ms-MY_details.xml', '', ''),
(2, 3, 0, 'Romanian', '', 'pkg_ro-RO', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/ro-RO_details.xml', '', ''),
(3, 3, 0, 'Flemish', '', 'pkg_nl-BE', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/nl-BE_details.xml', '', ''),
(4, 3, 0, 'Chinese Traditional', '', 'pkg_zh-TW', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/zh-TW_details.xml', '', ''),
(5, 3, 0, 'French', '', 'pkg_fr-FR', 'package', '', 0, '3.4.1.2', '', 'http://update.joomla.org/language/details3/fr-FR_details.xml', '', ''),
(6, 3, 0, 'Galician', '', 'pkg_gl-ES', 'package', '', 0, '3.3.1.2', '', 'http://update.joomla.org/language/details3/gl-ES_details.xml', '', ''),
(7, 3, 0, 'German', '', 'pkg_de-DE', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/de-DE_details.xml', '', ''),
(8, 3, 0, 'Greek', '', 'pkg_el-GR', 'package', '', 0, '3.3.3.1', '', 'http://update.joomla.org/language/details3/el-GR_details.xml', '', ''),
(9, 3, 0, 'Japanese', '', 'pkg_ja-JP', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/ja-JP_details.xml', '', ''),
(10, 3, 0, 'Hebrew', '', 'pkg_he-IL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/he-IL_details.xml', '', ''),
(11, 3, 0, 'EnglishAU', '', 'pkg_en-AU', 'package', '', 0, '3.3.1.1', '', 'http://update.joomla.org/language/details3/en-AU_details.xml', '', ''),
(12, 3, 0, 'EnglishUS', '', 'pkg_en-US', 'package', '', 0, '3.3.1.1', '', 'http://update.joomla.org/language/details3/en-US_details.xml', '', ''),
(13, 3, 0, 'Hungarian', '', 'pkg_hu-HU', 'package', '', 0, '3.3.3.1', '', 'http://update.joomla.org/language/details3/hu-HU_details.xml', '', ''),
(14, 3, 0, 'Afrikaans', '', 'pkg_af-ZA', 'package', '', 0, '3.2.0.2', '', 'http://update.joomla.org/language/details3/af-ZA_details.xml', '', ''),
(15, 3, 0, 'Arabic Unitag', '', 'pkg_ar-AA', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/ar-AA_details.xml', '', ''),
(16, 3, 0, 'Belarusian', '', 'pkg_be-BY', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/be-BY_details.xml', '', ''),
(17, 3, 0, 'Bulgarian', '', 'pkg_bg-BG', 'package', '', 0, '3.3.0.1', '', 'http://update.joomla.org/language/details3/bg-BG_details.xml', '', ''),
(18, 3, 0, 'Catalan', '', 'pkg_ca-ES', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/ca-ES_details.xml', '', ''),
(19, 3, 0, 'Chinese Simplified', '', 'pkg_zh-CN', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/zh-CN_details.xml', '', ''),
(20, 3, 0, 'Croatian', '', 'pkg_hr-HR', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/hr-HR_details.xml', '', ''),
(21, 3, 0, 'Czech', '', 'pkg_cs-CZ', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/cs-CZ_details.xml', '', ''),
(22, 3, 0, 'Danish', '', 'pkg_da-DK', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/da-DK_details.xml', '', ''),
(23, 3, 0, 'Dutch', '', 'pkg_nl-NL', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/nl-NL_details.xml', '', ''),
(24, 3, 0, 'Estonian', '', 'pkg_et-EE', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/et-EE_details.xml', '', ''),
(25, 3, 0, 'Italian', '', 'pkg_it-IT', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/it-IT_details.xml', '', ''),
(26, 3, 0, 'Korean', '', 'pkg_ko-KR', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/ko-KR_details.xml', '', ''),
(27, 3, 0, 'Latvian', '', 'pkg_lv-LV', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/lv-LV_details.xml', '', ''),
(28, 3, 0, 'Macedonian', '', 'pkg_mk-MK', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/mk-MK_details.xml', '', ''),
(29, 3, 0, 'Norwegian Bokmal', '', 'pkg_nb-NO', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/nb-NO_details.xml', '', ''),
(30, 3, 0, 'Norwegian Nynorsk', '', 'pkg_nn-NO', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/nn-NO_details.xml', '', ''),
(31, 3, 0, 'Persian', '', 'pkg_fa-IR', 'package', '', 0, '3.4.1.2', '', 'http://update.joomla.org/language/details3/fa-IR_details.xml', '', ''),
(32, 3, 0, 'Polish', '', 'pkg_pl-PL', 'package', '', 0, '3.4.1.2', '', 'http://update.joomla.org/language/details3/pl-PL_details.xml', '', ''),
(33, 3, 0, 'Portuguese', '', 'pkg_pt-PT', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/pt-PT_details.xml', '', ''),
(34, 3, 0, 'Russian', '', 'pkg_ru-RU', 'package', '', 0, '3.4.1.2', '', 'http://update.joomla.org/language/details3/ru-RU_details.xml', '', ''),
(35, 3, 0, 'Slovak', '', 'pkg_sk-SK', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/sk-SK_details.xml', '', ''),
(36, 3, 0, 'Swedish', '', 'pkg_sv-SE', 'package', '', 0, '3.4.1.3', '', 'http://update.joomla.org/language/details3/sv-SE_details.xml', '', ''),
(37, 3, 0, 'Syriac', '', 'pkg_sy-IQ', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/sy-IQ_details.xml', '', ''),
(38, 3, 0, 'Tamil', '', 'pkg_ta-IN', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/ta-IN_details.xml', '', ''),
(39, 3, 0, 'Thai', '', 'pkg_th-TH', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/th-TH_details.xml', '', ''),
(40, 3, 0, 'Turkish', '', 'pkg_tr-TR', 'package', '', 0, '3.4.1.2', '', 'http://update.joomla.org/language/details3/tr-TR_details.xml', '', ''),
(41, 3, 0, 'Ukrainian', '', 'pkg_uk-UA', 'package', '', 0, '3.3.3.15', '', 'http://update.joomla.org/language/details3/uk-UA_details.xml', '', ''),
(42, 3, 0, 'Uyghur', '', 'pkg_ug-CN', 'package', '', 0, '3.3.0.1', '', 'http://update.joomla.org/language/details3/ug-CN_details.xml', '', ''),
(43, 3, 0, 'Albanian', '', 'pkg_sq-AL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/sq-AL_details.xml', '', ''),
(44, 3, 0, 'Hindi', '', 'pkg_hi-IN', 'package', '', 0, '3.3.6.1', '', 'http://update.joomla.org/language/details3/hi-IN_details.xml', '', ''),
(45, 3, 0, 'Portuguese Brazil', '', 'pkg_pt-BR', 'package', '', 0, '3.4.1.3', '', 'http://update.joomla.org/language/details3/pt-BR_details.xml', '', ''),
(46, 3, 0, 'Serbian Latin', '', 'pkg_sr-YU', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/sr-YU_details.xml', '', ''),
(47, 3, 0, 'Spanish', '', 'pkg_es-ES', 'package', '', 0, '3.4.1.2', '', 'http://update.joomla.org/language/details3/es-ES_details.xml', '', ''),
(48, 3, 0, 'Bosnian', '', 'pkg_bs-BA', 'package', '', 0, '3.4.0.1', '', 'http://update.joomla.org/language/details3/bs-BA_details.xml', '', ''),
(49, 3, 0, 'Serbian Cyrillic', '', 'pkg_sr-RS', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/sr-RS_details.xml', '', ''),
(50, 3, 0, 'Vietnamese', '', 'pkg_vi-VN', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/vi-VN_details.xml', '', ''),
(51, 3, 0, 'Bahasa Indonesia', '', 'pkg_id-ID', 'package', '', 0, '3.3.0.2', '', 'http://update.joomla.org/language/details3/id-ID_details.xml', '', ''),
(52, 3, 0, 'Finnish', '', 'pkg_fi-FI', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/fi-FI_details.xml', '', ''),
(53, 3, 0, 'Swahili', '', 'pkg_sw-KE', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/sw-KE_details.xml', '', ''),
(54, 3, 0, 'Montenegrin', '', 'pkg_srp-ME', 'package', '', 0, '3.3.1.1', '', 'http://update.joomla.org/language/details3/srp-ME_details.xml', '', ''),
(55, 3, 0, 'EnglishCA', '', 'pkg_en-CA', 'package', '', 0, '3.3.6.1', '', 'http://update.joomla.org/language/details3/en-CA_details.xml', '', ''),
(56, 3, 0, 'FrenchCA', '', 'pkg_fr-CA', 'package', '', 0, '3.3.6.1', '', 'http://update.joomla.org/language/details3/fr-CA_details.xml', '', ''),
(57, 3, 0, 'Welsh', '', 'pkg_cy-GB', 'package', '', 0, '3.3.0.1', '', 'http://update.joomla.org/language/details3/cy-GB_details.xml', '', ''),
(58, 3, 0, 'Sinhala', '', 'pkg_si-LK', 'package', '', 0, '3.3.1.1', '', 'http://update.joomla.org/language/details3/si-LK_details.xml', '', ''),
(59, 11, 0, 'Geocode Factory 5 - Joomla Content - Gateway plugin', 'Geocode Factory 5 - Gateway plugin', 'plg_geofactory_content_jc30', 'plugin', '', 0, '5.15.0415', '', 'http://myjoom.com/myjoom-updater/geofactory-updater-jc_gw_30.xml', 'http://www.myjoom.com/index.php/products/geocode-factory-5', '');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_update_sites`
--

CREATE TABLE IF NOT EXISTS `g2q6h_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) DEFAULT '',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Update Sites' AUTO_INCREMENT=13 ;

--
-- Dumping data for table `g2q6h_update_sites`
--

INSERT INTO `g2q6h_update_sites` (`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`, `extra_query`) VALUES
(1, 'Joomla! Core', 'collection', 'http://update.joomla.org/core/list.xml', 1, 1431407983, ''),
(2, 'Joomla! Extension Directory', 'collection', 'http://update.joomla.org/jed/list.xml', 1, 1431407983, ''),
(3, 'Accredited Joomla! Translations', 'collection', 'http://update.joomla.org/language/translationlist_3.xml', 1, 1431407981, ''),
(4, 'Joomla! Update Component Update Site', 'extension', 'http://update.joomla.org/core/extensions/com_joomlaupdate.xml', 1, 1431407981, ''),
(5, 'NoNumber Modules Anywhere', 'extension', 'http://download.nonumber.nl/updates.php?e=modulesanywhere&type=.zip', 1, 1431407981, ''),
(6, 'NoNumber Articles Anywhere', 'extension', 'http://download.nonumber.nl/updates.php?e=articlesanywhere&type=.zip', 1, 1431407981, ''),
(7, 'GeocodeFactoryCore', 'extension', 'http://myjoom.com/myjoom-updater/geofactory-updater-core.xml', 1, 1431407981, ''),
(8, 'GeocodeFactoryModule', 'extension', 'http://myjoom.com/myjoom-updater/geofactory-updater-map-mod.xml', 1, 1431407981, ''),
(9, 'GeocodeFactoryButtonJc30', 'extension', 'http://myjoom.com/myjoom-updater/geofactory-updater-jc_button_30.xml', 1, 1431407981, ''),
(10, 'GeocodeFactoryContentJc30', 'extension', 'http://myjoom.com/myjoom-updater/geofactory-updater-jc_content_30.xml', 1, 1431407981, ''),
(11, 'GeocodeFactoryGatewayJc30', 'extension', 'http://myjoom.com/myjoom-updater/geofactory-updater-jc_gw_30.xml', 1, 1431407981, ''),
(12, 'GeocodeFactoryPlgLoadMap', 'extension', 'http://myjoom.com/myjoom-updater/geofactory-updater-plg_load_map.xml', 1, 1431407981, '');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_update_sites_extensions`
--

CREATE TABLE IF NOT EXISTS `g2q6h_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';

--
-- Dumping data for table `g2q6h_update_sites_extensions`
--

INSERT INTO `g2q6h_update_sites_extensions` (`update_site_id`, `extension_id`) VALUES
(1, 700),
(2, 700),
(3, 600),
(4, 28),
(7, 10005),
(8, 10006),
(9, 10008),
(10, 10009),
(11, 10010),
(12, 10011);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_usergroups`
--

CREATE TABLE IF NOT EXISTS `g2q6h_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `g2q6h_usergroups`
--

INSERT INTO `g2q6h_usergroups` (`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES
(1, 0, 1, 18, 'Public'),
(2, 1, 8, 15, 'Registered'),
(3, 2, 9, 14, 'Author'),
(4, 3, 10, 13, 'Editor'),
(5, 4, 11, 12, 'Publisher'),
(6, 1, 4, 7, 'Manager'),
(7, 6, 5, 6, 'Administrator'),
(8, 1, 16, 17, 'Super Users'),
(9, 1, 2, 3, 'Guest');

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_users`
--

CREATE TABLE IF NOT EXISTS `g2q6h_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  `requireReset` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Require user to reset password on next login',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=402 ;

--
-- Dumping data for table `g2q6h_users`
--

INSERT INTO `g2q6h_users` (`id`, `name`, `username`, `email`, `password`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`, `otpKey`, `otep`, `requireReset`) VALUES
(401, 'Super User', 'admin', 'trung@istamps.dk', '$2y$10$n4EErWdvX.GtXBp98jq3t.bArhW.4etBb12fFCUTU77HNOaa2083O', 0, 1, '2015-05-08 04:07:14', '2015-05-12 11:37:08', '0', '', '0000-00-00 00:00:00', 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_user_keys`
--

CREATE TABLE IF NOT EXISTS `g2q6h_user_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `series` varchar(255) NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) NOT NULL,
  `uastring` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `series` (`series`),
  UNIQUE KEY `series_2` (`series`),
  UNIQUE KEY `series_3` (`series`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_user_notes`
--

CREATE TABLE IF NOT EXISTS `g2q6h_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_user_profiles`
--

CREATE TABLE IF NOT EXISTS `g2q6h_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_user_usergroup_map`
--

CREATE TABLE IF NOT EXISTS `g2q6h_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `g2q6h_user_usergroup_map`
--

INSERT INTO `g2q6h_user_usergroup_map` (`user_id`, `group_id`) VALUES
(401, 8);

-- --------------------------------------------------------

--
-- Table structure for table `g2q6h_viewlevels`
--

CREATE TABLE IF NOT EXISTS `g2q6h_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `g2q6h_viewlevels`
--

INSERT INTO `g2q6h_viewlevels` (`id`, `title`, `ordering`, `rules`) VALUES
(1, 'Public', 0, '[1]'),
(2, 'Registered', 2, '[6,2,8]'),
(3, 'Special', 3, '[6,3,8]'),
(5, 'Guest', 1, '[9]'),
(6, 'Super Users', 4, '[8]');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
